
/*
格式：
const xxx={
    description: {
    //index和对象名相同，用来索引
        index:"xxx"
        name: "xxx",
        //type决定显示方式
        type: "showSelection",
        //title是菜单标题
        title: Text.black('『配装菜单』'),
        //左按钮
        leftButton: {
        //按钮的图标对应物
            icon: 'createdeco:decal_left',
            iconNbt: {
                display: {
                    Name: '{"text":"xxx","color":"gold","italic":"false"}',
                    Lore: ['{"text":"yyy","color":"white","italic":"false"}'],
                }
            },
            //点击物品的行为
            leftClickAction: {
            //type决定点击之后的结果
                type: "exit",
            }
        },
        rightButton: {
            icon: 'minecraft:diamond_sword',
            iconNbt: {
                display: {
                    Name: '{"text":"xxx","color":"gold","italic":"false"}',
                    Lore: ['{"text":"yyy","color":"white","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "deploy"
            },
        }
    },
    aaa: {
        index:""
        icon: "",
        iconNbt: {
                display: {
                    Name: '{"text":"aa","color":"gold","italic":"false"}',
                    Lore: ['{"text":"bb","color":"white","italic":"false"}'],
                }
            },
        //location的x取值1-7，y取值1-4，是物品在
        菜单的位置
        location: {
            x: 1,
            y: 2
        },
        leftClickAction: {
        //changeMenu必须接它接下来去的菜单界面
            type: "changeMenu",
            get nextMenu() {
                return mainWeapons
            }
        },
    },
    bbb: {
        index:""
        icon: "",
        iconNbt: {
                display: {
                    Name: '{"text":"cc","color":"gold","italic":"false"}',
                    Lore: ['{"text":"dd","color":"white","italic":"false"}'],
                }
            },
        location: {
            x: 3,
            y: 2
        },
        leftClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return subWeapons
            }
        }
    },
}
*/

const mainWeaponsRED = {
    description: {
        index: "mainWeaponsRED",
        type: "conductSelect",
        maxSelect: 1,
        title: Text.black('『主武器菜单』'),
        leftButton: {
            icon: 'createdeco:decal_left',
            iconNbt: {
                display: {
                    Name: '{"text":"返回","color":"gold","italic":"false"}',
                    Lore: ['{"text":"回到上一界面","color":"white","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "changeMenu",
                get nextMenu() {
                    return menuItemsRED
                }
            }
        },
        rightTopButton: {
            icon: 'book',
            iconNbt: {
                display: {
                    Name: '{"text":"注意事项","color":"gold","italic":"false"}',
                    Lore: ['{"text":"右键点击物品可以进入配件菜单。","color":"aqua","italic":"false"}', '{"text":"如果没反应就是没有配件。","color":"gray","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "none",
            }
        },
        leftTopButton: {
            icon: 'createdeco:decal_warning',
            iconNbt: {
                display: {
                    Name: '{"text":"重置","color":"red","italic":"false"}',
                    Lore: ['{"text":"重置当前页面下的选择","color":"white","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "reset"
            },
        }
    },
    //----------------------------步枪
    qbz191: {
        index: "qbz191",
        icon: 'tacz:modern_kinetic_gun',
        iconNbt: {
            GunId: "ccrp:qbz_191"
        },
        location: {
            x: 1,
            y: 1
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                gunItem: {
                    id: 'tacz:modern_kinetic_gun',
                    count: 1,
                    nbt: {
                        HasBulletInBarrel: true,
                        GunFireMode: "AUTO",
                        GunId: "ccrp:qbz_191",
                        GunCurrentAmmoCount: Integer.parseInt('30')
                    }
                },
                ammos: {
                    id: 'tacz:ammo_box',
                    count: 1,
                    nbt: {
                        Level: Integer.parseInt('1'),
                        AmmoCount: Integer.parseInt('120'),
                        AmmoId: "tacz:58x42"
                    }
                }

            }
        },
        rightClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return qbz191Attachments
            }
        }
    },
    qbz95: {
        index: "qbz95",
        icon: 'tacz:modern_kinetic_gun',
        iconNbt: {
            GunId: "suffuse:qbz951"
        },
        location: {
            x: 1,
            y: 2
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                gunItem: {
                    id: 'tacz:modern_kinetic_gun',
                    count: 1,
                    nbt: {
                        HasBulletInBarrel: true,
                        GunFireMode: "AUTO",
                        GunId: "suffuse:qbz951",
                        GunCurrentAmmoCount: Integer.parseInt('30')
                    }
                },
                ammos: {
                    id: 'tacz:ammo_box',
                    count: 1,
                    nbt: {
                        Level: Integer.parseInt('1'),
                        AmmoCount: Integer.parseInt('120'),
                        AmmoId: "tacz:58x42"
                    }
                }

            }
        },
        rightClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return qbz95Attachments
            }
        }
    },
    /*     sks: {
            index: "sks",
            icon: 'tacz:modern_kinetic_gun',
            iconNbt: {
                GunId: "tacz:sks_tactical"
            },
            location: {
                x: 1,
                y: 2
            },
            leftClickAction: {
                type: "simpleSelect",
                items: {
                    type: "multiple",
                    gunItem: {
                        id: 'tacz:modern_kinetic_gun',
                        count: 1,
                        nbt: {
                            HasBulletInBarrel: true,
                            GunFireMode: "SEMI",
                            GunId: "tacz:sks_tactical",
                            GunCurrentAmmoCount: Integer.parseInt('10')
                        }
                    },
                    ammos: {
                        id: 'tacz:ammo_box',
                        count: 1,
                        nbt: {
                            Level: Integer.parseInt('1'),
                            AmmoCount: Integer.parseInt('120'),
                            AmmoId: "tacz:762x39"
                        }
                    }
    
                }
            },
            rightClickAction: {
                type: "changeMenu",
                get nextMenu() {
                    return sksAttachments
                }
            }
        }, */
    type88: {
        index: "type88",
        icon: 'tacz:modern_kinetic_gun',
        iconNbt: {
            GunId: "cib:882"
        },
        location: {
            x: 1,
            y: 3
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                gunItem: {
                    id: 'tacz:modern_kinetic_gun',
                    count: 1,
                    nbt: {
                        HasBulletInBarrel: true,
                        GunFireMode: "AUTO",
                        GunId: "cib:882",
                        GunCurrentAmmoCount: Integer.parseInt('100')
                    }
                },
                ammos: {
                    id: 'tacz:ammo_box',
                    count: 1,
                    nbt: {
                        Level: Integer.parseInt('1'),
                        AmmoCount: Integer.parseInt('100'),
                        AmmoId: "tacz:545x39"
                    }
                }

            }
        },
        rightClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return type88Attachments
            }
        }
    },
    ak74n: {
        index: "ak74n",
        icon: 'tacz:modern_kinetic_gun',
        iconNbt: {
            GunId: "mk16:ak74n"
        },
        location: {
            x: 1,
            y: 4
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                gunItem: {
                    id: 'tacz:modern_kinetic_gun',
                    count: 1,
                    nbt: {
                        HasBulletInBarrel: true,
                        GunFireMode: "AUTO",
                        GunId: "mk16:ak74n",
                        GunCurrentAmmoCount: Integer.parseInt('30')
                    }
                },
                ammos: {
                    id: 'tacz:ammo_box',
                    count: 1,
                    nbt: {
                        Level: Integer.parseInt('1'),
                        AmmoCount: Integer.parseInt('120'),
                        AmmoId: "tacz:545x39"
                    }
                }

            }
        },
        rightClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return ak74nAttachments
            }
        }
    },
    //----------------------------冲锋枪-短突击-霰弹
    /*     pp19: {
            index: "pp19",
            icon: 'tacz:modern_kinetic_gun',
            iconNbt: {
                GunId: "suffuse:pp19"
            },
            location: {
                x: 2,
                y: 1
            },
            leftClickAction: {
                type: "simpleSelect",
                items: {
                    type: "multiple",
                    gunItem: {
                        id: 'tacz:modern_kinetic_gun',
                        count: 1,
                        nbt: {
                            HasBulletInBarrel: true,
                            GunFireMode: "AUTO",
                            GunId: "suffuse:pp19",
                            GunCurrentAmmoCount: Integer.parseInt('64')
                        }
                    },
                    ammos: {
                        id: 'tacz:ammo_box',
                        count: 1,
                        nbt: {
                            Level: Integer.parseInt('1'),
                            AmmoCount: Integer.parseInt('256'),
                            AmmoId: "tacz:9mm"
                        }
                    }
    
                }
            },
            rightClickAction: {
                type: "changeMenu",
                get nextMenu() {
                    return pp19Attachments
                }
            }
        }, */
    SR3M: {
        index: "SR3M",
        icon: 'tacz:modern_kinetic_gun',
        iconNbt: {
            GunId: "ccrp:sr_3m"
        },
        location: {
            x: 2,
            y: 1
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                gunItem: {
                    id: 'tacz:modern_kinetic_gun',
                    count: 1,
                    nbt: {
                        HasBulletInBarrel: true,
                        GunFireMode: "AUTO",
                        GunId: "ccrp:sr_3m",
                        GunCurrentAmmoCount: Integer.parseInt('30')
                    }
                },
                ammos: {
                    id: 'tacz:ammo_box',
                    count: 1,
                    nbt: {
                        Level: Integer.parseInt('1'),
                        AmmoCount: Integer.parseInt('120'),
                        AmmoId: "tacz:9x39"
                    }
                }

            }
        },
        rightClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return SR3MAttachments
            }
        }
    },
    /* aks74u: {
        index: "aks74u",
        icon: 'tacz:modern_kinetic_gun',
        iconNbt: {
            GunId: "suffuse:aks74u"
        },
        location: {
            x: 2,
            y: 2
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                gunItem: {
                    id: 'tacz:modern_kinetic_gun',
                    count: 1,
                    nbt: {
                        HasBulletInBarrel: true,
                        GunFireMode: "AUTO",
                        GunId: "suffuse:aks74u",
                        GunCurrentAmmoCount: Integer.parseInt('30')
                    }
                },
                ammos: {
                    id: 'tacz:ammo_box',
                    count: 1,
                    nbt: {
                        Level: Integer.parseInt('1'),
                        AmmoCount: Integer.parseInt('240'),
                        AmmoId: "tacz:545x39"
                    }
                }

            }
        },
        rightClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return aks74uAttachments
            }
        }
    }, */
    qbz192: {
        index: "qbz192",
        icon: 'tacz:modern_kinetic_gun',
        iconNbt: {
            GunId: "classicr:qbz191_renewed"
        },
        location: {
            x: 2,
            y: 2
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                gunItem: {
                    id: 'tacz:modern_kinetic_gun',
                    count: 1,
                    nbt: {
                        HasBulletInBarrel: true,
                        GunFireMode: "AUTO",
                        GunId: "classicr:qbz191_renewed",
                        GunCurrentAmmoCount: Integer.parseInt('30')
                    }
                },
                ammos: {
                    id: 'tacz:ammo_box',
                    count: 1,
                    nbt: {
                        Level: Integer.parseInt('1'),
                        AmmoCount: Integer.parseInt('120'),
                        AmmoId: "tacz:58x42"
                    }
                }

            }
        },
        rightClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return qbz192Attachments
            }
        }
    },
    origin12: {
        index: "origin12",
        icon: 'tacz:modern_kinetic_gun',
        iconNbt: {
            GunId: "cib:origin12"
        },
        location: {
            x: 2,
            y: 3
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                gunItem: {
                    id: 'tacz:modern_kinetic_gun',
                    count: 1,
                    nbt: {
                        HasBulletInBarrel: true,
                        GunFireMode: "SEMI",
                        GunId: "cib:origin12",
                        GunCurrentAmmoCount: Integer.parseInt('8')
                    }
                },
                ammos: {
                    id: 'tacz:ammo_box',
                    count: 1,
                    nbt: {
                        Level: Integer.parseInt('1'),
                        AmmoCount: Integer.parseInt('56'),
                        AmmoId: "tacz:12g"
                    }
                }

            }
        },
        rightClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return origin12Attachments
            }
        }
    },
    /*     ash12: {
            index: "ash12",
            icon: 'tacz:modern_kinetic_gun',
            iconNbt: {
                GunId: "suffuse:ash12"
            },
            location: {
                x: 2,
                y: 3
            },
            leftClickAction: {
                type: "simpleSelect",
                items: {
                    type: "multiple",
                    gunItem: {
                        id: 'tacz:modern_kinetic_gun',
                        count: 1,
                        nbt: {
                            HasBulletInBarrel: true,
                            GunFireMode: "AUTO",
                            GunId: "suffuse:ash12",
                            GunCurrentAmmoCount: Integer.parseInt('10')
                        }
                    },
                    ammos: {
                        id: 'tacz:ammo_box',
                        count: 1,
                        nbt: {
                            Level: Integer.parseInt('1'),
                            AmmoCount: Integer.parseInt('40'),
                            AmmoId: "tacz:50bmg"
                        }
                    }
    
                }
            },
            rightClickAction: {
                type: "changeMenu",
                get nextMenu() {
                    return ash12Attachments
                }
            }
        }, */
    //------------------------------机枪
    qjb951: {
        index: "qjb951",
        icon: 'tacz:modern_kinetic_gun',
        iconNbt: {
            GunId: "ccrp:type_95_longbow"
        },
        location: {
            x: 3,
            y: 1
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                gunItem: {
                    id: 'tacz:modern_kinetic_gun',
                    count: 1,
                    nbt: {
                        HasBulletInBarrel: true,
                        GunFireMode: "AUTO",
                        GunId: "ccrp:type_95_longbow",
                        GunCurrentAmmoCount: Integer.parseInt('60')
                    }
                },
                ammos: {
                    id: 'tacz:ammo_box',
                    count: 1,
                    nbt: {
                        Level: Integer.parseInt('1'),
                        AmmoCount: Integer.parseInt('180'),
                        AmmoId: "tacz:58x42"
                    }
                }

            }
        },
        rightClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return qjb951Attachments
            }
        }
    },
    qjy88: {
        index: "qjy88",
        icon: 'tacz:modern_kinetic_gun',
        iconNbt: {
            GunId: "pla:qjy88"
        },
        location: {
            x: 3,
            y: 2
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                gunItem: {
                    id: 'tacz:modern_kinetic_gun',
                    count: 1,
                    nbt: {
                        HasBulletInBarrel: true,
                        GunFireMode: "AUTO",
                        GunId: "pla:qjy88",
                        GunCurrentAmmoCount: Integer.parseInt('60')
                    }
                },
                ammos: {
                    id: 'tacz:ammo_box',
                    count: 1,
                    nbt: {
                        Level: Integer.parseInt('1'),
                        AmmoCount: Integer.parseInt('200'),
                        AmmoId: "tacz:58x42"
                    }
                }

            }
        },
        rightClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return qjy88Attachments
            }
        }
    },
    /*     pkp: {
            index: "pkp",
            icon: 'tacz:modern_kinetic_gun',
            iconNbt: {
                GunId: "suffuse:pkp"
            },
            location: {
                x: 3,
                y: 2
            },
            leftClickAction: {
                type: "simpleSelect",
                items: {
                    type: "multiple",
                    gunItem: {
                        id: 'tacz:modern_kinetic_gun',
                        count: 1,
                        nbt: {
                            HasBulletInBarrel: true,
                            GunFireMode: "AUTO",
                            GunId: "suffuse:pkp",
                            GunCurrentAmmoCount: Integer.parseInt('120')
                        }
                    },
                    ammos: {
                        id: 'tacz:ammo_box',
                        count: 1,
                        nbt: {
                            Level: Integer.parseInt('1'),
                            AmmoCount: Integer.parseInt('360'),
                            AmmoId: "tacz:762x39"
                        }
                    }
    
                }
            },
            rightClickAction: {
                type: "changeMenu",
                get nextMenu() {
                    return pkpAttachments
                }
            }
        },
        rpd: {
            index: "rpd",
            icon: 'tacz:modern_kinetic_gun',
            iconNbt: {
                GunId: "rainforest:rpd"
            },
            location: {
                x: 3,
                y: 3
            },
            leftClickAction: {
                type: "simpleSelect",
                items: {
                    type: "multiple",
                    gunItem: {
                        id: 'tacz:modern_kinetic_gun',
                        count: 1,
                        nbt: {
                            HasBulletInBarrel: true,
                            GunFireMode: "AUTO",
                            GunId: "rainforest:rpd",
                            GunCurrentAmmoCount: Integer.parseInt('35')
                        }
                    },
                    ammos: {
                        id: 'tacz:ammo_box',
                        count: 1,
                        nbt: {
                            Level: Integer.parseInt('1'),
                            AmmoCount: Integer.parseInt('280'),
                            AmmoId: "tacz:762x39"
                        }
                    }
    
                }
            },
            rightClickAction: {
                type: "changeMenu",
                get nextMenu() {
                    return rpdAttachments
                }
            }
        }, */

    //-------------------连狙-狙击枪
    qbu191: {
        index: "qbu191",
        icon: 'tacz:modern_kinetic_gun',
        iconNbt: {
            GunId: "ccrp:qbu_191"
        },
        location: {
            x: 4,
            y: 1
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                gunItem: {
                    id: 'tacz:modern_kinetic_gun',
                    count: 1,
                    nbt: {
                        HasBulletInBarrel: true,
                        GunFireMode: "AUTO",
                        GunId: "ccrp:qbu_191",
                        GunCurrentAmmoCount: Integer.parseInt('30')
                    }
                },
                ammos: {
                    id: 'tacz:ammo_box',
                    count: 1,
                    nbt: {
                        Level: Integer.parseInt('1'),
                        AmmoCount: Integer.parseInt('90'),
                        AmmoId: "tacz:58x42"
                    }
                }

            }
        },
        rightClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return qbu191Attachments
            }
        }
    },
    qbu88: {
        index: "qbu88",
        icon: 'tacz:modern_kinetic_gun',
        iconNbt: {
            GunId: "cib:qbu88"
        },
        location: {
            x: 4,
            y: 2
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                gunItem: {
                    id: 'tacz:modern_kinetic_gun',
                    count: 1,
                    nbt: {
                        HasBulletInBarrel: true,
                        GunFireMode: "SEMI",
                        GunId: "cib:qbu88",
                        GunCurrentAmmoCount: Integer.parseInt('10')
                    }
                },
                ammos: {
                    id: 'tacz:ammo_box',
                    count: 1,
                    nbt: {
                        Level: Integer.parseInt('1'),
                        AmmoCount: Integer.parseInt('60'),
                        AmmoId: "tacz:58x42"
                    }
                }

            }
        },
        rightClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return qbu88Attachments
            }
        }
    },
    sv98: {
        index: "sv98",
        icon: 'tacz:modern_kinetic_gun',
        iconNbt: {
            GunId: "cib:sv98"
        },
        location: {
            x: 4,
            y: 3
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                gunItem: {
                    id: 'tacz:modern_kinetic_gun',
                    count: 1,
                    nbt: {
                        HasBulletInBarrel: true,
                        GunFireMode: "SEMI",
                        GunId: "cib:sv98",
                        GunCurrentAmmoCount: Integer.parseInt('10')
                    }
                },
                ammos: {
                    id: 'tacz:ammo_box',
                    count: 1,
                    nbt: {
                        Level: Integer.parseInt('1'),
                        AmmoCount: Integer.parseInt('30'),
                        AmmoId: "tacz:762x54"
                    }
                }

            }
        },
        rightClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return sv98Attachments
            }
        }
    },
    /*     svd: {
            index: "svd",
            icon: 'tacz:modern_kinetic_gun',
            iconNbt: {
                GunId: "cib:svd"
            },
            location: {
                x: 5,
                y: 1
            },
            leftClickAction: {
                type: "simpleSelect",
                items: {
                    type: "multiple",
                    gunItem: {
                        id: 'tacz:modern_kinetic_gun',
                        count: 1,
                        nbt: {
                            HasBulletInBarrel: true,
                            GunFireMode: "SEMI",
                            GunId: "cib:svd",
                            GunCurrentAmmoCount: Integer.parseInt('10')
                        }
                    },
                    ammos: {
                        id: 'tacz:ammo_box',
                        count: 1,
                        nbt: {
                            Level: Integer.parseInt('1'),
                            AmmoCount: Integer.parseInt('40'),
                            AmmoId: "tacz:762x54"
                        }
                    }
    
                }
            },
            rightClickAction: {
                type: "changeMenu",
                get nextMenu() {
                    return svdAttachments
                }
            }
        }, */

    /*     m99: {
            index: "m99",
            icon: 'tacz:modern_kinetic_gun',
            iconNbt: {
                GunId: "cib:m99"
            },
            location: {
                x: 5,
                y: 2
            },
            leftClickAction: {
                type: "simpleSelect",
                items: {
                    type: "multiple",
                    gunItem: {
                        id: 'tacz:modern_kinetic_gun',
                        count: 1,
                        nbt: {
                            HasBulletInBarrel: true,
                            GunFireMode: "SEMI",
                            GunId: "cib:m99",
                            GunCurrentAmmoCount: Integer.parseInt('5')
                        }
                    },
                    ammos: {
                        id: 'tacz:ammo_box',
                        count: 1,
                        nbt: {
                            Level: Integer.parseInt('1'),
                            AmmoCount: Integer.parseInt('20'),
                            AmmoId: "tacz:50bmg"
                        }
                    }
    
                }
            },
            rightClickAction: {
                type: "changeMenu",
                get nextMenu() {
                    return m99Attachments
                }
            }
        }, */
    //爆炸
    /*javelin: {
        index: "javelin",
        icon: 'pointblank:javelin',
        iconNbt: {
        },
        location: {
            x: 6,
            y: 1
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                gunItem: {
                    id: 'pointblank:javelin',
                    count: 1,
                    nbt: {}
                },
                ammos: {
                    id: 'pointblank:javelin_rocket',
                    count: 3,
                    nbt: {}
                }
            }
        }
    },
    mgl: {
        index: "mgl",
        icon: 'pointblank:m32mgl',
        iconNbt: {
        },
        location: {
            x: 6,
            y: 2
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                gunItem: {
                    id: 'pointblank:m32mgl',
                    count: 1,
                    nbt: {}
                },
                ammos: {
                    id: 'pointblank:grenade40mm',
                    count: 12,
                    nbt: {}
                }
            }
        }
    },*/
}
