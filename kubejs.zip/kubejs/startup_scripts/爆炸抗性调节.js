BlockEvents.modification(event => {
    event.modify('minecraft:lever', block => {
        block.explosionResistance = 128
    }),
        event.modify('create:redstone_link', block => {
            block.explosionResistance = 128
        }),
        event.modify('vs_clockwork:phys_bearing', block => {
            block.explosionResistance = 128
            block.destroySpeed = 120
        }),
        event.modify('cbcmodernwarfare:compact_mount', block => {
            block.explosionResistance = 128
        }),
        event.modify('createbigcannons:cannon_mount', block => {
            block.explosionResistance = 128
        }),

        event.modify('create:andesite_door', block => {
            block.explosionResistance = 40
        }),
        event.modify('create:brass_door', block => {
            block.explosionResistance = 40
        }),
        event.modify('create:copper_door', block => {
            block.explosionResistance = 40
        }),
        event.modify('create:train_door', block => {
            block.explosionResistance = 40
        }),


        Ingredient.all.itemIds.forEach((id) => {
            event.modify(id, (item) => {
                if (item.explosionResistance < 9) {
                    item.explosionResistance = 9
                }
            });
        });
})


