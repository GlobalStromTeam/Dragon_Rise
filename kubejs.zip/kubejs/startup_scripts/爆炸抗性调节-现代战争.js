BlockEvents.modification(event => {
    event.modify('minecraft:lever', block => {
        block.explosionResistance = 128
    }),
    event.modify('minecraft:lectern', block => {
        block.explosionResistance = 1200
    }),
        event.modify('create:redstone_link', block => {
            block.explosionResistance = 128
        }),

        event.modify('vs_clockwork:phys_bearing', block => {
            block.explosionResistance = 128
            block.destroySpeed = 1200
        }),
        event.modify('vs_clockwork:propeller_bearing', block => {
            block.explosionResistance = 20
            block.destroySpeed = 1200
        }),
        event.modify('cbcmodernwarfare:compact_mount', block => {
            block.explosionResistance = 128
        }),
        event.modify('createbigcannons:cannon_mount', block => {
            block.explosionResistance = 128
        }),

        event.modify('create:andesite_door', block => {
            block.explosionResistance = 40
        }),
        event.modify('create:brass_door', block => {
            block.explosionResistance = 40
        }),
        event.modify('create:copper_door', block => {
            block.explosionResistance = 40
        }),
        event.modify('create:train_door', block => {
            block.explosionResistance = 40
        }),

        event.modify('create:mechanical_arm', block => {
            block.explosionResistance = 20
        }),


        event.modify(/:.+_terracotta/, block => {
            block.explosionResistance = 9
        }),
        event.modify(/:.+_concrete/, block => {
            block.explosionResistance = 9
        }),
        event.modify(/:.+era/, block => {
            block.explosionResistance = 20
        }),

        event.modify(/_armor_block/, block => {
            block.explosionResistance = 9
        }),

        event.modify(/:.+_seat/, block => {
            block.explosionResistance = 20
        }),
        event.modify(/:.+_helm/, block => {
            block.explosionResistance = 20
        }),

        event.modify(/^computercraft:/, block => {
            block.explosionResistance = 20
        }),
        
        event.modify(/^peripheralworks:/, block => {
            block.explosionResistance = 20
        }),

        event.modify(/^some_peripherals:/, block => {
            block.explosionResistance = 20
        }),

        event.modify(/^vs_tournament:/, block => {
            block.explosionResistance = 20
        }),

        Ingredient.all.itemIds.forEach((id) => {
            event.modify(id, (item) => {
                if (item.explosionResistance < 8) {
                    item.explosionResistance = 8
                }
            });
        });
})

