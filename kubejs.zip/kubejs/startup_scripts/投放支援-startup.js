ForgeEvents.onEvent('net.minecraftforge.event.entity.ProjectileImpactEvent', event => {
    global.projectilefunc(event)
})

/**
 * 
 * @param {Internal.ProjectileImpactEvent} event 
 */

global.projectilefunc = event => {
    //Utils.server.tell(event.entity.nbt)
    //you can reload this with /kubejs reload startup_events to reload without doing a full game restart!
    try {
        //server.tell('1')
        if (event.projectile.type == 'minecraft:snowball') {
            //server.tell('2')
            //let { server, level } = event.entity
            let entity = event.entity
            if (entity.persistentData['strikeType'] && entity.persistentData['strikeData']) {
                let { strikeType, strikeData } = entity.persistentData

                switch (strikeType) {
                    case 'Cannon': {
                        fireStrikeCannonProj(strikeData, entity)
                    }
                        break;

                    case 'Missile': {
                        fireStrikeMissileProj(strikeData, entity)
                    }
                        break;
                    case 'DeployBlock': {

                    }
                        break;
                    case 'DeployEntity': {

                    }
                        break;
                    default:
                        break;
                }

            }
            //console.log(event.rayTraceResult.type.name())
        }
        if (event.projectile.type == 'minecraft:arrow' && event.projectile.persistentData['entityData']) {
            let entity = event.entity
            let { server, level } = entity
            let entityData = event.projectile.persistentData['entityData']
            if (entityData['explosionPower']) {
                let explosion = level.createExplosion(entity.x, entity.y, entity.z)
                //explosion.exploder(serverPlayer)
                explosion.strength(entityData['explosionPower'])
                explosion.explosionMode('mob');
                //explosion.causesFire(true);
                // 引爆
                explosion.explode();
                entity.kill()
            }

        }
    } catch (error) {
        console.log(error)
    }
}

function fireStrikeCannonProj(strikeData, entity) {
    let { server, level } = entity
    //解构
    let { height, radius, fixedRadius, warnRadius, fireLag, fireRounds, fireRoundInterval, firePerRound, fireInterval, projSpeed, strikeProj } = strikeData
    let projItem = Item.of(strikeProj.id).withNBT(strikeProj.nbt)
    let fluidNbt = undefined
    if (strikeProj.nbt.BlockEntityTag['FluidContent']) {
        let { Amount, FluidName, Tag } = strikeProj.nbt.BlockEntityTag.FluidContent
        fluidNbt = {
            Fluid: { Fluid: FluidName, FluidAmount: Amount, FluidTag: Tag }
        }
    }
    //server.tell(projItem.nbt)
    //方便编程的 没啥用
    let snowball =  /** @type {Internal.Entity} */ (entity)
    //let snowball = entity.block
    let spawnPos = new Vec3d(snowball.x, snowball.y + height, snowball.z);

    //let particleTimer = 0
    if (!warnRadius) {
        warnRadius = radius
    }
    server.runCommandSilent(`execute positioned ${snowball.x} ${snowball.y} ${snowball.z} run title @a[distance=..${warnRadius}] title ["",{"text":"侦测到炮火打击","color":"red"}]`)

    server.scheduleInTicks(fireLag, callback => {
        //计数开火周期
        let roundCount = 0
        server.scheduleInTicks(fireRoundInterval + fireInterval * firePerRound, callback => {
            callback.repeating = true
            roundCount++
            if (roundCount >= fireRounds) {
                callback.repeating = false
            }
            //计数每周期开火次数
            let fireCount = 0
            server.scheduleRepeatingInTicks(fireInterval, callback => {
                callback.repeating = true
                fireCount++
                if (fireCount >= firePerRound) {
                    callback.repeating = false
                }
                //开火
                let proj = Block.getBlock(projItem.id)[
                    'getProjectile(net.minecraft.world.level.Level,net.minecraft.world.item.ItemStack)'
                ](level, projItem.copy()); //Gets the actual projectile entity. Works only past CBC 5.5.1 for every shell. Before that, only drop mortars do (GetDropMortarProjectile)
                //server.tell(proj.nbt)
                //byd函数不能把流体数据导入弹头，得写下面这一行
                fluidNbt ? proj.mergeNbt(fluidNbt) : undefined
                //proj.setExplosionPower(2)
                proj.setPos(spawnPos); //set the position
                proj.setChargePower(4); //I'll be honest I forgot what this does.
                let theta = Math.random() * 360
                let deviation = fixedRadius ? 1 : Math.random()
                let deviationX = radius * deviation * Math.sin(theta)
                let deviationZ = radius * deviation * Math.cos(theta)
                proj.shoot(deviationX, -450, deviationZ, projSpeed, 0); //x,y,z speed, power, spread
                level.addFreshEntity(proj);

            })
        })
    })
    //server.tell(1)
    let beamLocateTMP = /** @type {Internal.Entity} */ (level.createEntity('armor_stand'))
    //server.tell(2)
    beamLocateTMP.mergeNbt({
        CustomName: '[{"text":"BeaconLocateTMP","color":"red"}]', Invisible: true,
        ArmorItems: [{}, {}, {}, {
            id: "minecraft:beacon", Count: 1, tag: {
                color: strikeData.beamColor
            }
        }
        ]
    })
    //beamLocateTMP.persistentData['color'] = strikeData.beamColor
    beamLocateTMP.setPos(snowball.x, snowball.y - 1, snowball.z)
    beamLocateTMP.spawn()
    //let beamPos = [snowball.x - 0.5, snowball.y, snowball.z - 0.5, [strikeData.beamColor[0], strikeData.beamColor[1], strikeData.beamColor[2]]]

    //beamsData.push(beamPos)
    server.scheduleInTicks((fireInterval * firePerRound + fireRoundInterval) * fireRounds + fireLag, callback => {
        //beamsData = beamsData.filter(beam => beam != beamPos)
        beamLocateTMP.kill()
    })
}

function fireStrikeMissileProj(strikeData, entity) {
    let { server, level } = entity
    //解构
    let { height, vertical, radius, warnRadius, seekMode, fireLag, firePerRound, fireInterval, projSpeed, strikeProj } = strikeData
    let projItem = Item.of(strikeProj.id).withNBT(strikeProj.nbt)
    let fluidNbt = undefined
    if (strikeProj.nbt.BlockEntityTag['FluidContent']) {
        let { Amount, FluidName, Tag } = strikeProj.nbt.BlockEntityTag.FluidContent
        fluidNbt = {
            Fluid: { Fluid: FluidName, FluidAmount: Amount, FluidTag: Tag }
        }
    }
    //server.tell(projItem.nbt)
    //方便编程的 没啥用
    let snowball =  /** @type {Internal.Entity} */ (entity)
    //let snowball = entity.block
    //计算玩家到雪球的向量，求出水平垂直向量
    let { x: ownX, y: ownY, z: ownZ } = snowball.owner
    let { x: projX, y: projy, z: projZ, } = snowball
    //server.tell(ownX)
    let vecToProj = new Vec3d(projX - ownX, 0, projZ - ownZ)
    //server.tell(vecToProj)
    let vertVecX = vertical * Math.sqrt(1 / (((vecToProj.x() / vecToProj.z()) ** 2) + 1))
    let vertVecZ = -vertVecX * vecToProj.x() / vecToProj.z()
    //server.tell(snowball.owner.health)

    let spawnPos = new Vec3d(snowball.x + vertVecX, snowball.y + height, snowball.z + vertVecZ);

    //let beamPos = [snowball.x - 0.5, snowball.y, snowball.z - 0.5, [strikeData.beamColor[0], strikeData.beamColor[1], strikeData.beamColor[2]]]
    //beamsData.push(beamPos)
    //let particleTimer = 0

    if (!warnRadius) {
        warnRadius = radius
    }
    server.runCommandSilent(`execute positioned ${snowball.x} ${snowball.y} ${snowball.z} run title @a[distance=..${warnRadius}] title ["",{"text":"侦测到导弹","color":"red"}]`)

    server.scheduleInTicks(fireLag, callback => {

        //计数每周期开火次数
        let fireCount = 0
        let targets = getEntityByMode(snowball, radius, firePerRound, seekMode)
        server.scheduleRepeatingInTicks(fireInterval, callback => {
            callback.repeating = true
            fireCount++
            if (fireCount >= firePerRound) {
                callback.repeating = false
            }
            //开火
            let proj = Block.getBlock(projItem.id)[
                'getProjectile(net.minecraft.world.level.Level,net.minecraft.world.item.ItemStack)'
            ](level, projItem.copy()); //Gets the actual projectile entity. Works only past CBC 5.5.1 for every shell. Before that, only drop mortars do (GetDropMortarProjectile)
            //server.tell(proj.nbt)
            //byd函数不能把流体数据导入弹头，得写下面这一行
            fluidNbt ? proj.mergeNbt(fluidNbt) : undefined
            proj.setPos(spawnPos); //set the position
            proj.setChargePower(4); //I'll be honest I forgot what this does.
            if (strikeProj['clusterData']) {
                proj.persistentData['clusterData'] = strikeProj['clusterData']
            }
            //server.tell(targets)
            if (targets.length >= 1) {

                let targetEntity = targets[fireCount % targets.length]
                try {
                    targetEntity.potionEffects.add('glowing', 40, 0, true, false)
                } catch (error) { }
                let result = MissileNewton(spawnPos.x(), spawnPos.y(), spawnPos.z(), targetEntity.x, targetEntity.y, targetEntity.z, projSpeed * 20, 0)
                let yaw = result[0]
                let pitch = result[1]
                let finalVec = rotationToVec3(yaw / 180 * pie, pitch / 180 * pie)
                //server.tell(yaw)
                //server.tell(pitch)
                proj.shoot(finalVec.x(), finalVec.y(), finalVec.z(), projSpeed, 0)
            } else {
                let result = MissileNewton(spawnPos.x(), spawnPos.y(), spawnPos.z(), snowball.x, snowball.y, snowball.z, projSpeed * 20, 0)
                let yaw = result[0]
                let pitch = result[1]
                let finalVec = rotationToVec3(yaw / 180 * pie, pitch / 180 * pie)
                proj.shoot(finalVec.x(), finalVec.y(), finalVec.z(), projSpeed, radius / 4); //x,y,z speed, power, spread
            }
            level.addFreshEntity(proj);
        })

    })
    let beamLocateTMP = level.createEntity('armor_stand')
    //server.tell(2)
    beamLocateTMP.mergeNbt({
        CustomName: '[{"text":"BeaconLocateTMP","color":"red"}]', Invisible: true, CustomNameVisible: true,
        ArmorItems: [{}, {}, {}, {
            id: "minecraft:beacon", Count: 1, tag: {
                color: strikeData.beamColor
            }
        }
        ]
    })
    beamLocateTMP.persistentData['color'] = strikeData.beamColor
    beamLocateTMP.setPos(snowball.x, snowball.y - 1, snowball.z)
    beamLocateTMP.spawn()
    //let beamPos = [snowball.x - 0.5, snowball.y, snowball.z - 0.5, [strikeData.beamColor[0], strikeData.beamColor[1], strikeData.beamColor[2]]]

    //beamsData.push(beamPos)
    server.scheduleInTicks((fireInterval * firePerRound) + fireLag, callback => {
        //beamsData = beamsData.filter(beam => beam != beamPos)
        beamLocateTMP.kill()
    })
}

function deployStrikeBlock(params) {

}

function deployStrikeEntity() {

}

const pie = 3.14159
function MissileNewton(x0, y0, z0, x1, y1, z1, v0, l) {
    let x = x1 - x0
    let y = y1 - y0
    let z = z1 - z0
    let w = Math.sqrt(x * x + z * z)
    let h = 1

    /* let xt2 = Math.acos(w / (5 * v0 + l)) - 0.01
    let xt1 = 0
    try {

        while (Math.abs(xt2 - xt1) > 0.000001) {
            console.log(xt2)
            console.log(xt1)
            xt1 = xt2
            let secx = 1 / Math.cos(xt1)
            let tanx = Math.tan(xt1)
            let f = 100 * w * secx / v0 + w * tanx + 500 * Math.log(1 - (w * secx - l) / (5 * v0)) - y - 100 * l / v0 + h
            let f1 = w * secx * (secx + 100 * tanx / v0 - (500 * tanx) / (5 * v0 - w * secx + l))
            xt2 = xt1 - f / f1
        }

    } catch (error) { }

    let Angle = xt2 * 180 / pie */
    //console.log(Angle)

    let xt2 = -pie / 3
    let xt1 = 0
    try {

        while (Math.abs(xt2 - xt1) > 0.000001) {

            xt1 = xt2
            let secx = 1 / Math.cos(xt1)
            let tanx = Math.tan(xt1)
            let f = 100 * w * secx / v0 + w * tanx + 500 * Math.log(1 - (w * secx - l) / (5 * v0)) - y - 100 * l / v0 + h
            let f1 = w * secx * (secx + 100 * tanx / v0 - (500 * tanx) / (5 * v0 - w * secx + l))
            xt2 = xt1 - f / f1
            //console.log(xt2)
        }

    } catch (error) { }
    let Angle2 = xt2 * 180 / pie

    let yaw = -Math.atan(x / z) * 180 / pie
    if (z < 0) {
        yaw -= 180
    }
    return [yaw, Angle2]
}

function rotationToVec3(yaw, pitch) {
    let x = -Math.sin(yaw) * Math.cos(pitch)
    let z = Math.cos(yaw) * Math.cos(pitch)
    let y = Math.sin(pitch)
    return new Vec3d(x, y, z)
}

function getEntityByMode(sourceEntity, radius, count, seekmode) {
    const notTargetType = ['minecraft:arrow', 'minecraft:item', 'minecraft:experience_orb', 'tacz:bullet', 'minecraft:snowball', 'minecraft:ender_pearl', 'minecraft:fishing_bobber', 'minecraft:armor_stand', 'mutantmonsters:body_part']
    const notTargetTeam = ['HP', 'Player', 'Yellow']
    // 获取源实体的位置和世界
    const level = /** @type {Internal.ServerLevel} */(sourceEntity.level);
    let owner = sourceEntity.owner
    // 创建搜索区域的AABB
    const aabb = sourceEntity.boundingBox.inflate(radius)

    // 获取区域内的所有实体
    const entities = level.getEntitiesWithin(aabb);
    let returnEntities = []
    //console.log(returnEntities)

    for (let i = 0; i < entities.length; i++) {

        let other =  /** @type {Internal.Entity} */ (entities[i]);
        /*         console.log(other == sourceEntity)
                console.log(other.teamId)
                console.log(!other.isAlive())
                console.log(other.type.toString().includes('createbigcannon'))
                console.log(other.type.toString().includes('enhancedai'))
                console.log(other.type.toString().includes('xtraarrows'))
                console.log(notTargetType.includes(other.type)) */
        if (other == owner || other == sourceEntity //|| !other.teamId 
            || other.teamId == owner.teamId
            || !other.isAlive()
            || other.type.toString().includes('createbigcannon')
            || other.type.toString().includes('zombieawareness')
            || other.type.toString().includes('enhancedai')
            || other.type.toString().includes('xtraarrows')
            || notTargetType.includes(other.type)
            || notTargetTeam.includes(other.teamId)) continue;

        //let health = other.health
        //console.log(other)
        //console.log(Math.sqrt(health))
        // 如果更近且可见，则更新最近实体
        /* if (health < minDistance && sourceEntity.hasLineOfSight(other)) {
            closestEntity = other;
            minDistance = health;
        } */
        //console.log(other)
        returnEntities.push(other)
    }

    switch (seekmode) {
        case 'health': {
            //returnEntities = sortByHealth(returnEntities).subList(0, Math.min(returnEntities.length, count))//.filter(e => e.isAlive())//.sort((a, b) => b.health - a.health)
            returnEntities = returnEntities.sort((a, b) => b.health - a.health).slice(0, Math.min(returnEntities.length, count))
        }
            break;
        case 'none': {
            returnEntities = []
        }
            break;

        default:
            break;
    }

    return returnEntities;
}

function sortByHealth(entityArrayList) {
    for (let i = 0; i < entityArrayList.length; i++) {
        for (let j = 0; j < entityArrayList.length - 1; j++) {
            //if (!) continue;
            if (!entityArrayList[j].health || entityArrayList[j].health < entityArrayList[j + 1].health) {
                let num = entityArrayList[j]
                entityArrayList[j] = entityArrayList[j + 1]
                entityArrayList[j + 1] = num
            }
        }
    }
    return entityArrayList
}
//if (player.mainHandItem.id != "minecraft:diamond") return


