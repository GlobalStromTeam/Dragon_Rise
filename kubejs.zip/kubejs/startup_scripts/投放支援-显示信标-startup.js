ForgeEvents.onEvent("net.minecraftforge.client.event.RenderLevelStageEvent", event => global.render(event))

/**
 * 
 * @param {Internal.RenderLevelStageEvent} event 
 */

let RenderLevelStageEvent = Java.loadClass("net.minecraftforge.client.event.RenderLevelStageEvent$Stage")
let Minecraft = Java.loadClass("net.minecraft.client.Minecraft")
let BeaconRenderer = Java.loadClass("net.minecraft.client.renderer.blockentity.BeaconRenderer")
let BeaconBlockEntity = Java.loadClass("net.minecraft.world.level.block.entity.BeaconBlockEntity")
var BEAM_LOCATION = new ResourceLocation("textures/entity/beacon_beam.png");
var color = [5, 5, 5]
let offset = {
    x: 0,
    y: 0,
    z: 0
}

//let beamsData = []

global.render = event => {
    let { poseStack, camera, stage, partialTick } = event;
    //const level = Utils.server.getEntities().filterSelector('@e[type=minecraft:zombie]')
    let player = Minecraft.getInstance().player;
    if (player == null) return;
    //if (!beamsData) return;
    //let entities = level.getEntities('@e[type=minecraft:zombie]')[0]
    try {
        //if (entity.type == 'minecraft:player') return;
        let entities = player.level.getEntities()//.filterSelector('@e[type=minecraft:armor_stand,name=BeaconLocateTMP]')
        //console.log(entities)
        if (!entities) return;
        entities.forEach(beaconBeam => {
            if (beaconBeam.type != 'minecraft:armor_stand') return;
            let color = beaconBeam?.armorSlots[3].nbt.color
            if (!color) return
            if (stage != RenderLevelStageEvent.AFTER_ENTITIES) return;
            let buffer = Minecraft.getInstance().renderBuffers().bufferSource()
            let coordinatesArray = camera.position.toString().replace("(", '').replace(")", '').split(',');
            //console.log(player.position())
            //let coordinatesArray = player.position().toString().replace("(", '').replace(")", '').split(',');
            let [xCoord, yCoord, zCoord] = coordinatesArray;
            poseStack.pushPose();
            poseStack.translate(-xCoord + beaconBeam.x - 0.5, -yCoord + beaconBeam.y, -zCoord + beaconBeam.z - 0.5)
            //Utils.server.tell(beaconBeam[3])
            BeaconRenderer.renderBeaconBeam(poseStack, buffer, BEAM_LOCATION, partialTick, 1.0, player.level.getTime(), 0, 256, [color[0], color[1], color[2]], 0.2, 0.25);
            poseStack.popPose();
        })
    } catch (error) {
        console.log(error);
    }
};