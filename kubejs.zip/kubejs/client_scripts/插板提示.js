
/* ItemEvents.tooltip(event => {
    
    event.addAdvanced('create:sturdy_sheet', (item, Advanced, tooltip) => {

        tooltip.add(1,[Text.of(`当前插板：3`).blue()])
    })
    event.addAdvanced('minecraft:player_head', (item, advanced, text) => {
        let playerName = item.nbt?.SkullOwner?.Name
        if (playerName) {
          text.add(Text.red(`The head of ===${playerName}===`))
        }
      })
}) */

