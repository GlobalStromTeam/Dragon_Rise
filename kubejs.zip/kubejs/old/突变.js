function setDefault() {
    Utils.server.persistentData.mutantList = {
        "感觉统合强化": {
            name: "感觉统合强化",
            tip: "增加流到枕骨和颞叶的营养物，提高视力和听力。显著增加僵尸跟随距离，僵尸将固定可以捡起掉落物",
            followRange: 32,
            votes: 0,
            isActived: false
        },
        "运动神经强化": {
            name: "运动神经强化",
            tip: "增加流到顶叶的营养物，改善僵尸行动和协调性。提升僵尸移动速度和跳跃能力",
            speed: 0.04,
            effects: { Id: 8, Duration: 200000, ShowParticles: false },
            effectsName: "跳跃提升",
            votes: 0,
            isActived: false
        },
        "颞叶操纵": {
            name: "颞叶操纵",
            tip: "僵尸会被运动物体所吸引，更容易保存完整的受害者尸体。增加僵尸跟随距离，玩家死亡时转化为新的僵尸",
            followRange: 32,
            effectsName: "死亡转化",
            votes: 0,
            isActived: false
        },
        "应激合成代谢": {
            name: "应激合成代谢",
            tip: "僵尸会在运动和腺体组织堆积过量营养物，增强其在受激时的爆发力。僵尸在受伤时获得短暂的属性提升。",
            effectsName: "受伤强化",
            votes: 0,
            isActived: false
        },
        "肽合成激增": {
            name: "肽合成激增",
            tip: "僵尸将体内脂肪代谢转化为肌肉，普遍增强僵尸力量。僵尸生命、护甲、速度等均有所提升。",
            health: 5,
            armor: 3,
            damage: 3,
            speed: 0.02,
            votes: 0,
            isActived: false
        },
        "易爆气体堆积": {
            name: "易爆气体堆积",
            tip: "僵尸将在体内堆积大量甲烷等气体，同时表皮韧性增强。僵尸生命、护甲韧性略微提升，死亡时有概率爆炸。",
            health: 5,
            armorToughness: 2,
            effects: { Id: 28, Duration: 200000, ShowParticles: false },
            effectsName: "死亡爆炸",
            votes: 0,
            isActived: false
        },
        "神经中枢转移": {
            name: "神经中枢转移",
            tip: "肺、肝等内脏出现部分神经元发育，僵尸难以被彻底杀死。僵尸生命大幅度提升。",
            health: 15,
            votes: 0,
            isActived: false
        },
        "骨骼结构异常": {
            name: "骨骼结构异常",
            tip: "腺瘤导致生长素分泌异常，皮肤开始钙化，骨骼密度显著增加且生长在头骨内。僵尸护甲和盔甲韧性大幅度提升。",
            armor: 15,
            armorToughness: 6,
            votes: 0,
            isActived: false
        },
        "合成代谢增强": {
            name: "合成代谢增强",
            tip: "僵尸的咬合肌变得丰满，睾酮分泌激增，显著增加僵尸的肌肉质量和体重。僵尸攻击力大幅度提升，速度和击退抗性小幅度提升。",
            damage: 6,
            speed: 0.02,
            knockbackResistance: 0.2,
            votes: 0,
            isActived: false
        },
        "蚓状肌肥大": {
            name: "蚓状肌肥大",
            tip: "显著增加僵尸的抓握力，被尸群盯上的猎物几乎无法逃脱。略微增加攻击力，僵尸更容易持有鱼竿。",
            damage: 1,
            effectsName: "额外鱼竿",
            votes: 0,
            isActived: false
        },
        "集群信息素": {
            name: "集群信息素",
            tip: "尸群可以利用信息素来吸引其他僵尸，并在受伤时释放大量信息素。僵尸增援率大幅度提升。",
            votes: 0,
            isActived: false
        }
    }
    attributeRefresh()
}

function readMutants() {
    if (!Utils.server.persistentData.mutantList) {
        setDefault()
    }
    return Utils.server.persistentData.mutantList
}

function getMutantAttributes(name) {
    return readMutants()[name]
}

function attributeRefresh() {
    mutant = readMutants()
    mutantList = Object.keys(mutant)

    health = 0
    armor = 0
    armorToughness = 0
    damage = 0
    speed = 0
    knockbackResistance = 0
    followRange = 0
    effects = []
    effectsName = []

    mutantList.forEach(name => {
        if (mutant[name].isActived === 1) {
            if (mutant[name].health) {
                health += mutant[name].health
            }
            if (mutant[name].armor) {
                armor += mutant[name].armor
            }
            if (mutant[name].armorToughness) {
                armorToughness += mutant[name].armorToughness
            }
            if (mutant[name].damage) {
                damage += mutant[name].damage
            }
            if (mutant[name].speed) {
                speed += mutant[name].speed
            }
            if (mutant[name].knockbackResistance) {
                knockbackResistance += mutant[name].knockbackResistance
            }
            if (mutant[name].followRange) {
                followRange += mutant[name].followRange
            }
            if (mutant[name].effects) {
                effects.push(mutant[name].effects)
            }
            if (mutant[name].effectsName) {
                effectsName.push(mutant[name].effectsName)
            }
        }
    })

    health += basicHealth
    armor += basicArmor
    armorToughness += basicArmorToughness
    damage += basicDamage
    speed += basicSpeed
    knockbackResistance += basicKnockbackResistance
    followRange += basicFollowRange
}

function activeMutant(name) {
    var mutant = readMutants()
    mutant[name].isActived = true
    attributeRefresh();
}

function disableMutant(name) {
    var mutant = readMutants()
    mutant[name].isActived = false
    attributeRefresh();
}

var mutant = undefined
var mutantList = undefined

var basicHealth = 10
var basicArmor = 2
var basicArmorToughness = 0
var basicDamage = 4.5
var basicSpeed = 0.23
var basicKnockbackResistance = 0
var basicFollowRange = 64

var health = 0
var armor = 0
var armorToughness = 0
var damage = 0
var speed = 0
var knockbackResistance = 0
var followRange = 0
var effects = []
var effectsName = []

const mobs = Java.loadClass('net.minecraft.world.entity.monster.Zombie');
const IntArrayTag = Java.loadClass("net.minecraft.nbt.IntArrayTag")
const Integer = Java.loadClass("java.lang.Integer")
var explosionUUID = new IntArrayTag([
    Integer.parseInt('-885041709'),
    Integer.parseInt('1683771192'),
    Integer.parseInt('-1533567981'),
    Integer.parseInt('-1556236849')
]);
//---------------------------------------------生成事件------------------------------------------------

EntityEvents.spawned(event => {
    const { entity } = event
    if (entity.nbt["IsBaby"]) {
        event.cancel()
    }
    if (entity instanceof mobs && !entity.name.toString().includes("大尸")) {
        //debug用的
        //event.server.tell("1")
        //改属性
        if (Math.random() <= 0.16) {
            entity.mergeNbt({
                HandItems: [{ id: "stone_pickaxe", Count: 1 }]
            })
        }
        entity.mergeNbt({
            Health: health,
            Attributes: [{ Name: "generic.max_health", Base: health },
            { Name: "generic.armor", Base: armor },
            { Name: "generic.armor_toughness", Base: armorToughness },
            { Name: "generic.attack_damage", Base: damage },
            { Name: "generic.movement_speed", Base: speed },
            { Name: "generic.knockback_resistance", Base: knockbackResistance },
            { Name: "generic.follow_range", Base: followRange },
            ],
            ActiveEffects: effects
        })
        if (mutant["感觉统合强化"].isActived === 1) {
            entity.mergeNbt({
                CanPickUpLoot: true
            })
        }
        if (mutant["易爆气体堆积"].isActived === 1 && Math.random() <= 0.25) {
            //entity.block.popItem(Item.playerHead("CJY2"))
            entity.mergeNbt({
                ArmorItems: [{}, {}, {}, {
                    id: "minecraft:player_head", Count: 1, tag: {
                        SkullOwner: {
                            Id: explosionUUID,
                            Properties: {
                                textures: [{
                                    Value: "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvN2Y2N2EyMWQwZjU4MmQ1NzZhMThjZmRjNTU1MDUxYTBjMGIwNmQyYjNiMjRjNzczYmFhMmRjYWJhM2UzYzA5NCJ9fX0="
                                }]
                            }
                        }
                        //SkullOwner: "CJY2"
                    }
                }
                ]
            })
            entity.persistentData["isExplosive"] = true
        }
        if (mutant["蚓状肌肥大"].isActived === 1 && Math.random() <= 0.16) {
            entity.mergeNbt({
                HandItems: [{ id: "fishing_rod", Count: 1 }]
            })
        }
        //只有僵尸有的属性就单独写出来了
        if (mutant["集群信息素"].isActived === 1) {
            entity.mergeNbt({
                Health: health,
                Attributes: [{ Name: "zombie.spawn_reinforcements", Base: 0.2 }
                ]
            })
        }

    }
});

//-------------------受伤事件

EntityEvents.hurt(event => {
    const { entity } = event
    if (entity.isLiving() && entity instanceof mobs) {
        if (mutant["应激合成代谢"].isActived === 1) {
            entity.potionEffects.add('minecraft:haste', 60, 4, true, true)
            entity.potionEffects.add('minecraft:speed', 60, 1, true, true)
            entity.potionEffects.add('minecraft:strength', 60, 1, true, true)
            //event.server.runCommandSilent(`effect give ${entity.id} minecraft:health_boost 2 2 true`);
            //event.server.runCommandSilent(`effect give ${entity.id} minecraft:speed 2 1 true`);
            //event.server.runCommandSilent(`effect give ${entity.id} minecraft:strength 2 1 true`);
            //event.server.tell("hurt")
        }
    }
})

//---------------------死亡事件

EntityEvents.death(event => {
    const { entity, level } = event
    if (entity.type == 'minecraft:player') {
        if (mutant["颞叶操纵"].isActived === 1) {
            //event.server.tell("death1")

            let reborn = level.createEntity('minecraft:zombie')
            reborn.setPosition(entity.x, entity.y, entity.z)
            reborn.spawn()
            //event.server.tell("death2")
        }
    }
    if ((entity instanceof mobs)) {
        //event.server.tell("death2")
        if (entity.persistentData["isExplosive"]) {
            event.server.scheduleInTicks(20, () => {
                level.createExplosion(entity.x, entity.y + 1, entity.z)
                    .strength(5)
                    .explosionMode('none')
                    .exploder(entity)
                    .explode()

            })
            //event.server.tell("death3")
        }
    }
})


ItemEvents.rightClicked(event => {
    if (event.item.areItemsEqual('clock') && event.item.hasNBT() && event.item.nbt["system"]) {
        /*event.player.tell("[数据列表]")
        attributeRefresh();

        event.player.tell("生命:" + health)
        event.player.tell("护甲:" + armor)
        event.player.tell("护甲韧性:" + armorToughness)
        event.player.tell("伤害:" + damage)
        event.player.tell("速度:" + speed)
        event.player.tell("跟随距离:" + followRange)
        event.player.tell("药剂效果:" + effectsName)*/
        event.player.runCommandSilent("mutant main")
    }
});

ServerEvents.commandRegistry(event => {
    var { commands: Commands, arguments: Arguments } = event;
    event.register(
        Commands.literal("mutant")
            .requires(player => player.hasPermission(0))
            .executes(mut => {
                var player = mut.source.playerOrException;
                var server = mut.source.server;
                var playerName = player.getName().getString()

                server.runCommandSilent(`tellraw ${playerName} {"text":"这是什么？","color":"dark_purple"}`);
                server.runCommandSilent(`give ${playerName} minecraft:clock{system:1}`);
                return 1;
            })
            .then(Commands.literal('data')
                .executes(mut => {
                    var player = mut.source.playerOrException;
                    var server = mut.source.server;
                    var playerName = player.getName().getString()

                    server.runCommandSilent(`tellraw ${playerName} {"text":"========[数据列表]=======","color":"dark_purple"}`);
                    server.runCommandSilent(`tellraw ${playerName} {"text":"生命: ${health}","color":"white"}`);
                    server.runCommandSilent(`tellraw ${playerName} {"text":"护甲: ${armor}","color":"white"}`);
                    server.runCommandSilent(`tellraw ${playerName} {"text":"护甲韧性: ${armorToughness}","color":"white"}`);
                    server.runCommandSilent(`tellraw ${playerName} {"text":"伤害: ${damage}","color":"white"}`);
                    server.runCommandSilent(`tellraw ${playerName} {"text":"速度: ${speed}","color":"white"}`);
                    server.runCommandSilent(`tellraw ${playerName} {"text":"跟随距离: ${followRange}","color":"white"}`);
                    server.runCommandSilent(`tellraw ${playerName} {"text":"附加效果: ${effectsName}","color":"white"}`);
                    return 1;
                }))
            .then(Commands.literal('main')
                .executes(mut => {
                    var player = mut.source.playerOrException;
                    var server = mut.source.server;
                    var playerName = player.getName().getString()
                    //var mutant = readMutants()
                    //var mutantList = Object.keys(mutant)

                    server.runCommandSilent(`tellraw ${playerName} {"text":"========突变操作系统========","color":"dark_purple"}`);
                    server.runCommandSilent(`tellraw ${playerName} {"text":"这是一个专门为内鬼和神秘人设计的脚本。","color":"white"}`);
                    server.runCommandSilent(`tellraw ${playerName} [{"text":"[投票系统]","color":"green","clickEvent":{"action":"run_command","value":"/mutant vote"},"hoverEvent":{"action":"show_text","value":"点击以进入投票"}}]`);
                    server.runCommandSilent(`tellraw ${playerName} [{"text":"[数据查看]","color":"green","clickEvent":{"action":"run_command","value":"/mutant data"},"hoverEvent":{"action":"show_text","value":"点击以查看僵尸数据"}}]`);
                    return 1;
                }))
            .then(Commands.literal('list')
                .requires(player => player.hasPermission(2))
                .executes(mut => {
                    var player = mut.source.playerOrException;
                    var server = mut.source.server;
                    var playerName = player.getName().getString()
                    //var mutant = readMutants()
                    //var mutantList = Object.keys(mutant)

                    server.runCommandSilent(`tellraw ${playerName} {"text":"========突变列表========","color":"dark_purple"}`);
                    mutantList.forEach(name => {
                        if (mutant[name].isActived === 1) {
                            server.runCommandSilent(`tellraw ${playerName} [{"text":"${mutant[name].name}","color":"yellow","hoverEvent":{"action":"show_text","value":"${mutant[name].tip}"}},{"text":"[切换]","color":"green","clickEvent":{"action":"run_command","value":"/mutant edit '${mutant[name].name}'"},"hoverEvent":{"action":"show_text","value":"点击以切换开关"}}]`);
                        }
                        else {
                            server.runCommandSilent(`tellraw ${playerName} [{"text":"${mutant[name].name}","color":"yellow","hoverEvent":{"action":"show_text","value":"${mutant[name].tip}"}},{"text":"[切换]","color":"dark_red","clickEvent":{"action":"run_command","value":"/mutant edit '${mutant[name].name}'"},"hoverEvent":{"action":"show_text","value":"点击以切换开关"}}]`);
                        }
                    })
                    return 1;
                }))
            .then(Commands.literal('edit')
                .requires(player => player.hasPermission(2))
                .then(Commands.argument('name', Arguments.STRING.create(event))
                    .executes(mut => {
                        var name = Arguments.STRING.getResult(mut, "name")
                        var player = mut.source.playerOrException;
                        var server = mut.source.server;
                        var playerName = player.getName().getString()
                        //var mutant = readMutants()
                        //var mutantList = Object.keys(mutant)
                        if (mutant[name]) {
                            //server.tell(name)
                            if (mutant[name].isActived === 0) {
                                server.runCommandSilent(`tellraw ${playerName} [{"text":"${mutant[name].name}","color":"yellow"},{"text":"已启用","color":"green"}]`)
                                activeMutant(name)
                            }
                            else {
                                server.runCommandSilent(`tellraw ${playerName} [{"text":"${mutant[name].name}","color":"yellow"},{"text":"已关闭","color":"dark_red"}]`)
                                disableMutant(name)
                            };
                            return 1;
                        }
                        else {
                            server.tell("有bug")
                            return 0;
                        }
                    })
                ))
            .then(Commands.literal('vote')
                .executes(mut => {
                    var player = mut.source.playerOrException;
                    var server = mut.source.server;
                    var playerName = player.getName().getString()
                    //var mutant = readMutants()
                    //var mutantList = Object.keys(mutant)

                    server.runCommandSilent(`tellraw ${playerName} {"text":"========突变投票========","color":"aqua"}`);
                    mutantList.forEach(name => {
                        if (mutant[name].isActived === 1) {
                            server.runCommandSilent(`tellraw ${playerName} [{"text":"${mutant[name].name}","color":"yellow"},{"text":"[已启用]","color":"green"}]`)
                        }
                        else {
                            if (player.persistentData.voteMutant == name) {
                                server.runCommandSilent(`tellraw ${playerName} [{"text":"${mutant[name].name}","color":"yellow","hoverEvent":{"action":"show_text","value":"${mutant[name].tip}"}},{"text":" [已选择]","color":"green","clickEvent":{"action":"run_command","value":"/mutant vote '${mutant[name].name}'"},"hoverEvent":{"action":"show_text","value":"当前选择"}},{"text":" 『得票数：${mutant[name].votes}』","color":"gold"}]`);
                            }
                            else {
                                server.runCommandSilent(`tellraw ${playerName} [{"text":"${mutant[name].name}","color":"yellow","hoverEvent":{"action":"show_text","value":"${mutant[name].tip}"}},{"text":" [选择]","color":"dark_red","clickEvent":{"action":"run_command","value":"/mutant vote '${mutant[name].name}'"},"hoverEvent":{"action":"show_text","value":"点击以更换选择"}},{"text":" 『得票数：${mutant[name].votes}』","color":"gold"}]`);
                            }
                        }
                    })
                    return 1;
                })
                .then(Commands.argument('name', Arguments.STRING.create(event))
                    .executes(mut => {
                        var name = Arguments.STRING.getResult(mut, "name")
                        var player = mut.source.playerOrException;
                        var server = mut.source.server;
                        var playerName = player.getName().getString()
                        var lastVoteMutant = player.persistentData.voteMutant
                        //var mutant = readMutants()
                        //var mutantList = Object.keys(mutant)
                        if (mutant[name]) {
                            //server.tell(name)
                            if (player.persistentData.voteMutant != name) {
                                server.runCommandSilent(`tellraw ${playerName} [{"text":"${mutant[name].name}","color":"yellow"},{"text":"已投票","color":"green"}]`)
                                mutant[name].votes += 1
                                if (lastVoteMutant) {
                                    mutant[lastVoteMutant].votes -= 1
                                }
                                player.persistentData["voteMutant"] = name
                            }
                            else {
                                server.runCommandSilent(`tellraw ${playerName} [{"text":"${mutant[name].name}","color":"yellow"},{"text":"取消投票","color":"dark_red"}]`)
                                mutant[name].votes -= 1
                                player.persistentData["voteMutant"] = ""
                            };
                            return 1;
                        }
                        else {
                            server.tell("有bug2")
                            return 0;
                        }
                    })
                )
                .then(Commands.literal('confirm')
                    .requires(player => player.hasPermission(2))
                    .executes(mut => {
                        //var name = Arguments.STRING.getResult(mut, "name")
                        var player = mut.source.playerOrException;
                        var server = mut.source.server;
                        var playerName = player.getName().getString()
                        var voteSort = []
                        var mostVotedMutant = ""

                        mutantList.forEach(name => {
                            voteSort.push(mutant[name].votes)
                        })
                        voteSort.sort((a, b) => b - a)
                        mutantList.forEach(name => {
                            if (mutant[name].votes == voteSort[0]) {
                                mostVotedMutant = name
                            }
                        })
                        server.runCommandSilent(`tellraw ${playerName} [{"text":"${mutant[mostVotedMutant].name}","color":"yellow"},{"text":"已启用","color":"green"}]`)
                        activeMutant(mostVotedMutant);
                        return 1;
                    }))
            )
            .then(Commands.literal('reset')
                .requires(player => player.hasPermission(2))
                .executes(mut => {
                    var player = mut.source.playerOrException;
                    var playerName = player.getName().getString()
                    var server = mut.source.server;
                    server.runCommandSilent(`tellraw ${playerName} [{"text":"已重置突变","color":"yellow"}]`)
                    setDefault()
                    return 1;
                }))

    )
})

PlayerEvents.loggedIn(event => {
    const player = event.player
    if (!player.stages.has("oneInGame")) {
        player.tell("欢迎第一次进入游戏")
        player.stages.add("oneInGame")
    }
    player.potionEffects.add("resistance", 1200, 4, true, false)
    attributeRefresh()
})
try {
    attributeRefresh()
} catch (error) {
    console.log("首次进入世界就会跳这个，不用管")
}




















/*
function checkTeamData() {
    if (!Utils.server.persistentData.TeamList) {
        Utils.server.persistentData.TeamList = {};
    }
}

function readTeams() {
    checkTeamData();
    return Utils.server.persistentData.TeamList;
}

function writeTeams(teams) {
    Utils.server.persistentData.TeamList = teams;
}

function getTeamByPlayer(player) {
    var teams = readTeams();
    return Object.values(teams).find(team => team.leader === player || String(team.member).includes(player)) || null;
}

function createTeam(teamName, leader) {
    if (!teamName) return false;

    var teams = readTeams();
    if (getTeamByPlayer(leader)) return false;

    if (!teams[teamName]) {
        teams[teamName] = {
            name: teamName,
            leader: leader,
            member: [],
            createTime: new Date().toISOString()
        };
        writeTeams(teams);
        return true;
    }
    return false;
}

function leaveTeam(player) {
    var teams = readTeams();
    var playerTeam = getTeamByPlayer(player);
    if (playerTeam) {
        if (player === playerTeam.leader) {
            delete teams[playerTeam.name];
        } else {
            teams[playerTeam.name].member = teams[playerTeam.name].member.filter(member => member !== player);
        }
        writeTeams(teams);
        return true;
    }
    return false;
}

function kickFromTeam(leader, playerToKick) {
    var teams = readTeams();
    var leaderTeam = getTeamByPlayer(leader);

    if (leaderTeam && leader === leaderTeam.leader && String(leaderTeam.member).includes(playerToKick)) {
        teams[leaderTeam.name].member = teams[leaderTeam.name].member.filter(member => member !== playerToKick);
        writeTeams(teams);
        return true;
    }
    return false;
}

function getTeamInfo(teamName) {
    return readTeams()[teamName] || null;
}

function joinTeam(teamName, player) {
    var teams = readTeams();
    if (getTeamByPlayer(player) || !teams[teamName]) return false;

    var invitedPlayers = teams[teamName].invitedPlayers || [];
    if (!invitedPlayers.indexOf(player)) {
        Utils.server.runCommandSilent(`tellraw ${teams[teamName].leader} [{"text":"[Teams]玩家 ${player} 请求加入队伍，接受请点击 ","color":"yellow"}, {"text":"【此处】","color":"green","clickEvent":{"action":"run_command","value":"/teams invite '${player}'"},"hoverEvent":{"action":"show_text","value":"接受请求"}}]`);
        return false;
    } else {
        teams[teamName].member.push(player);
        teams[teamName].invitedPlayers = invitedPlayers.filter(invitedPlayer => invitedPlayer !== player);
        writeTeams(teams);
        return true;
    }
}

function inviteToTeam(leader, playerToInvite) {
    var teams = readTeams();
    var leaderTeam = getTeamByPlayer(leader);

    if (leaderTeam && leader === leaderTeam.leader) {
        var teamName = leaderTeam.name;
        var invitedPlayers = teams[teamName].invitedPlayers || [];
        invitedPlayers.push(playerToInvite);
        teams[teamName].invitedPlayers = invitedPlayers;
        writeTeams(teams);
        Utils.server.runCommandSilent(`tellraw ${playerToInvite}  [{"text":"[Teams]您已被队长邀请加入队伍 ${teamName} ，接受请点击 ","color":"yellow"}, {"text":"【此处】","color":"green","clickEvent":{"action":"run_command","value":"/teams join"},"hoverEvent":{"action":"show_text","value":"加入队伍 ${teamName}"}}]`);

        setInterval(() => {
            var updatedTeams = readTeams();
            let result = Object.values(updatedTeams).find(team => String(team.member).includes(playerToInvite)) || "null";
            if (result == "null") {
                updatedTeams[teamName].invitedPlayers = updatedTeams[teamName].invitedPlayers.filter(invitedPlayer => invitedPlayer !== playerToInvite);
                writeTeams(updatedTeams);
                Utils.server.runCommandSilent(`tellraw ${playerToInvite} {"text":"[Teams]您未及时接受队伍邀请，邀请已取消。","color":"green"}`);
                Utils.server.runCommandSilent(`tellraw ${leader} {"text":"[Teams]玩家 ${playerToInvite} 未及时接受邀请，邀请已取消。","color":"green"}`);

                // 取消 setInterval

            }
            clearInterval();
        }, 120000);
        return true;
    }
    return false;
}

// Command registration
ServerEvents.commandRegistry(event => {
    var { commands: Commands, arguments: Arguments } = event;
    event.register(
        Commands.literal("teams")
            .executes(ctx => {
                var player = ctx.source.playerOrException;
                var server = ctx.source.server;
                var playerName = player.getName().getString();
                server.runCommandSilent(`tellraw ${playerName} {"text":"========组队系统========","color":"yellow"}`);
                server.runCommandSilent(`tellraw ${playerName} [{"text":"【创建队伍】","color":"yellow","clickEvent":{"action":"run_command","value":"/teams create"},"hoverEvent":{"action":"show_text","value":"创建队伍"}}, {"text":"        ","color":"yellow"}, {"text":"【查看队伍】","color":"yellow","clickEvent":{"action":"run_command","value":"/teams info self"},"hoverEvent":{"action":"show_text","value":"查看当前队伍信息"}}]`);
                server.runCommandSilent(`tellraw ${playerName} [{"text":"【邀请玩家】","color":"yellow","clickEvent":{"action":"run_command","value":"/teams invite"},"hoverEvent":{"action":"show_text","value":"邀请玩家加入队伍"}}, {"text":"        ","color":"yellow"}, {"text":"【踢出玩家】","color":"yellow","clickEvent":{"action":"run_command","value":"/teams kick"},"hoverEvent":{"action":"show_text","value":"从队伍中踢出玩家"}}]`);
                server.runCommandSilent(`tellraw ${playerName} [{"text":"【队伍列表】","color":"yellow","clickEvent":{"action":"run_command","value":"/teams list"},"hoverEvent":{"action":"show_text","value":"查看所有队伍"}}, {"text":"        ","color":"yellow"}, {"text":"【离开队伍】","color":"yellow","clickEvent":{"action":"run_command","value":"/teams leave"},"hoverEvent":{"action":"show_text","value":"退出队伍"}}]`);
                return 1;
            }
            )
            .then(Commands.literal("help")
                .executes(ctx => {
                    var player = ctx.source.playerOrException;
                    var server = ctx.source.server;
                    if (player == null) {
                        console.log("[Teams] /teams - 打开组队面板")
                        console.log("[Teams] /teams help - 查看指令帮助")
                        console.log("[Teams] /teams list - 查看队伍列表")
                        console.log("[Teams] /teams join - 加入队伍")
                        console.log("[Teams] /teams leave - 离开/解散队伍")
                        console.log("[Teams] /teams info <name> - 查看队伍信息")
                        console.log("[Teams] /teams kick <name> - 踢出玩家（名称可不填）")
                        console.log("[Teams] /teams invite <name> - 邀请玩家（名称可不填）")
                        console.log("[Teams] /teams create <name> - 创建队伍（名称可不填）")
                        return 1;
                    } else {
                        var playerName = player.getName().getString();
                        server.runCommandSilent(`tellraw ${playerName} [{"text":"[Teams]","color":"green"}, {"text":" /teams - 打开组队面板","color":"yellow"}]`);
                        server.runCommandSilent(`tellraw ${playerName} [{"text":"[Teams]","color":"green"}, {"text":" /teams help - 查看指令帮助","color":"yellow"}]`);
                        server.runCommandSilent(`tellraw ${playerName} [{"text":"[Teams]","color":"green"}, {"text":" /teams list - 查看队伍列表","color":"yellow"}]`);
                        server.runCommandSilent(`tellraw ${playerName} [{"text":"[Teams]","color":"green"}, {"text":" /teams join - 加入队伍","color":"yellow"}]`);
                        server.runCommandSilent(`tellraw ${playerName} [{"text":"[Teams]","color":"green"}, {"text":" /teams leave - 离开/解散队伍","color":"yellow"}]`);
                        server.runCommandSilent(`tellraw ${playerName} [{"text":"[Teams]","color":"green"}, {"text":" /teams info <name> - 查看队伍信息","color":"yellow"}]`);
                        server.runCommandSilent(`tellraw ${playerName} [{"text":"[Teams]","color":"green"}, {"text":" /teams kick <name> - 踢出玩家（名称可不填）","color":"yellow"}]`);
                        server.runCommandSilent(`tellraw ${playerName} [{"text":"[Teams]","color":"green"}, {"text":" /teams invite <name> - 邀请玩家（名称可不填）","color":"yellow"}]`);
                        server.runCommandSilent(`tellraw ${playerName} [{"text":"[Teams]","color":"green"}, {"text":" /teams create <name> - 创建队伍（名称可不填）","color":"yellow"}]`);
                        server.runCommandSilent(`tellraw ${playerName} [{"text":"[Teams]","color":"green"}, {"text":" Powered By Kubejs - Code Author:Rin_Schariac","color":"gray"}]`);
                        return 1;
                    }
                }
                ))
            .then(Commands.literal('create')
                .then(Commands.argument('name', Arguments.STRING.create(event))
                    .executes(ctx => {
                        var name = Arguments.STRING.getResult(ctx, "name");
                        var player = ctx.source.playerOrException;
                        var server = ctx.source.server;
                        var playerName = player.getName().getString();

                        if (!player) {
                            console.log("[Teams]请勿在控制台创建队伍")
                            return 0;
                        }
                        if (getTeamByPlayer(playerName)) {
                            server.runCommandSilent(`tellraw ${playerName} {"text":"[Teams]你已拥有一个队伍","color":"green"}`);
                            return 0;
                        }
                        if (!isNaN(name)) {
                            server.runCommandSilent(`tellraw ${playerName} {"text":"[Teams]创建队伍失败，请勿使用纯数字名称！","color":"green"}`);
                            return 0;
                        }
                        if (name == "self") {
                            server.runCommandSilent(`tellraw ${playerName} {"text":"[Teams]创建队伍失败，请尝试更换名称后再次创建","color":"green"}`);
                            return 0;
                        }
                        if (createTeam(name, playerName)) {
                            player.runCommandSilent(`ftbteams party create ${name}`)
                            player.runCommandSilent(`mine_and_slash teams create`)
                            server.runCommandSilent(`tellraw ${playerName} {"text":"[Teams]成功创建队伍 ${name} ，聊天开头添加 ! 标识可队内聊天！"}`);
                            player.persistentData.TeamCreate = "False"
                            return 1;
                        } else {
                            server.runCommandSilent(`tellraw ${playerName} {"text":"[Teams]创建队伍失败","color":"green"}`);
                            return 0;
                        }
                    })
                )
                .executes(ctx => {
                    var player = ctx.source.playerOrException;
                    var server = ctx.source.server;
                    var playerName = player.getName().getString();
                    player.persistentData.TeamCreate = "True"
                    server.runCommandSilent(`tellraw ${playerName} {"text":"[Teams]请输入队伍名称（输入 “T” 取消创建）：","color":"yellow"}`);
                    return 1;
                })
            )
            .then(Commands.literal("list")
                .executes(ctx => {
                    var player = ctx.source.playerOrException;
                    var server = ctx.source.server;
                    var playerName = player.getName().getString();

                    var teams = readTeams();
                    var teamList = Object.keys(teams);

                    server.runCommandSilent(`tellraw ${playerName} {"text":"队伍列表：","color":"yellow"}`);
                    teamList.forEach((team, index) => {
                        server.runCommandSilent(`tellraw ${playerName} {"text":"${index + 1}. ${team}","color":"yellow","clickEvent":{"action":"run_command","value":"/teams info '${team}'"},"hoverEvent":{"action":"show_text","value":"查看 ${team} 信息"}}`);
                    });
                    return 1;
                })
            )
            .then(Commands.literal("info")
                .then(Commands.argument("name", Arguments.STRING.create(event))
                    .executes(ctx => {
                        let name = Arguments.STRING.getResult(ctx, "name");
                        var player = ctx.source.playerOrException;
                        var server = ctx.source.server;
                        var playerName = player.getName().getString();
                        var teams = readTeams();
                        if (!name || name == "self") {
                            var playerTeam = getTeamByPlayer(playerName);
                            if (playerTeam) {
                                name = playerTeam.name;
                            } else {
                                server.runCommandSilent(`tellraw ${playerName} {"text":"[Teams]您不在任何队伍中","color":"green"}`);
                                return 0;
                            }
                        }
                        var teamInfo = getTeamInfo(name);
                        var member = []
                        if (teamInfo) {
                            teamInfo.member.forEach(e => {
                                member = String(e).slice(1, -1) + "," + member
                            })
                            server.runCommandSilent(`tellraw ${playerName} {"text":"========队伍信息========"}`);
                            server.runCommandSilent(`tellraw ${playerName} {"text":"队伍名称: ${teamInfo.name}"}`);
                            server.runCommandSilent(`tellraw ${playerName} {"text":"队长: ${teamInfo.leader}"}`);
                            server.runCommandSilent(`tellraw ${playerName} {"text":"队员: ${member}"}`);
                            server.runCommandSilent(`tellraw ${playerName} {"text":"创建时间: ${teamInfo.createTime}"}`);
                            return 1;
                        } else {
                            server.runCommandSilent(`tellraw ${playerName} {"text":"[Teams]队伍不存在","color":"green"}`);
                            return 0;
                        }
                    })
                )
                .executes(ctx => {
                    var player = ctx.source.playerOrException;
                    player.runCommandSilent("teams info self")
                    return 1;
                }
                )
            )
            .then(Commands.literal("leave")
                .executes(ctx => {
                    var player = ctx.source.playerOrException;
                    var server = ctx.source.server;
                    var playerName = player.getName().getString();

                    if (leaveTeam(playerName)) {
                        player.runCommandSilent(`mine_and_slash teams leave`)
                        player.runCommandSilent(`ftbteams party leave`)
                        server.runCommandSilent(`tellraw ${playerName} {"text":"[Teams]离开队伍成功","color":"green"}`);
                        return 1;
                    } else {
                        server.runCommandSilent(`tellraw ${playerName} {"text":"[Teams]您不在任何队伍中","color":"green"}`);
                        return 0;
                    }
                })
            )
            .then(Commands.literal('invite')
                .then(Commands.argument('name', Arguments.STRING.create(event))
                    .executes(ctx => {
                        var name = Arguments.STRING.getResult(ctx, "name");
                        var player = ctx.source.playerOrException;
                        var server = ctx.source.server;
                        var playerName = player.getName().getString();
                        var playerTeam = getTeamByPlayer(name)
                        var targetPlayer = server.playerList.getPlayerByName(name);
                        if (!targetPlayer) {
                            server.runCommandSilent(`tellraw ${playerName} {"text":"[Teams]玩家不在线","color":"green"}`);
                            return 0;
                        }
                        if (!playerTeam && inviteToTeam(playerName, name)) {
                            player.runCommandSilent(`mine_and_slash teams invite ${name}`)
                            player.runCommandSilent(`ftbteams party invite ${name}`)
                            server.runCommandSilent(`tellraw ${playerName} {"text":"[Teams]邀请已发送","color":"green"}`);
                            return 1;
                        } else {
                            server.runCommandSilent(`tellraw ${playerName} {"text":"[Teams]邀请发送失败","color":"green"}`);
                            return 0;
                        }
                    })
                )
                .executes(ctx => {
                    var player = ctx.source.playerOrException;
                    var server = ctx.source.server;
                    var playerName = player.getName().getString();
                    var list = server.playerList.getPlayers()
                    var playerNames = list.toString().match(/ServerPlayer\['([^']+)'/g).map(match => match.slice(14, -1));
                    var playerTeam = getTeamByPlayer(playerName);
                    if (playerTeam) {
                        server.runCommandSilent(`tellraw ${playerName} {"text":"======当前玩家列表======","color":"yellow"}`);
                        let cont = ""
                        let count = 0
                        playerNames.forEach(name => {
                            if (playerTeam = getTeamByPlayer(name)) {
                                return;
                            }
                            if (count < 4) {
                                if (cont == "") {
                                    cont = `{"text":" ${name} ，","color":"yellow","clickEvent":{"action":"run_command","value":"/teams invite '${name}'"},"hoverEvent":{"action":"show_text","value":"邀请 ${name}"}}`
                                } else {
                                    cont = cont + "," + `{"text":" ${name} ，","color":"yellow","clickEvent":{"action":"run_command","value":"/teams invite '${name}'"},"hoverEvent":{"action":"show_text","value":"邀请 ${name}"}}`
                                }
                                count++;
                            } else {
                                cont = cont + "," + `{"text":" ${name} ，","color":"yellow","clickEvent":{"action":"run_command","value":"/teams invite '${name}'"},"hoverEvent":{"action":"show_text","value":"邀请 ${name}"}}`
                                server.runCommandSilent(`tellraw ${playerName} [${cont}]`)
                                count = 0
                                cont = ""
                            }
                        })
                        server.runCommandSilent(`tellraw ${playerName} [${cont}]`)
                        return 1;
                    }
                    return 0;
                })
            )
            .then(Commands.literal('join')
                .executes(ctx => {
                    var player = ctx.source.playerOrException;
                    var server = ctx.source.server;
                    var playerName = player.getName().getString();
                    let teamlist = Utils.server.persistentData.TeamList;
                    var latestInviteTeam = ""
                    for (var teamName in teamlist) {
                        let team = String(teamlist[teamName].invitedPlayers)
                        if (team.match(`"${playerName}"`)) {
                            latestInviteTeam = teamName
                        }
                    }
                    if (joinTeam(latestInviteTeam, playerName)) {
                        const ftbname = server.persistentData.PlayerFTB
                        player.runCommandSilent(`mine_and_slash teams join ${teamlist[latestInviteTeam].leader}`)
                        player.runCommandSilent(`ftbteams party join ${ftbname[playerName]}`)
                        server.runCommandSilent(`tellraw ${playerName} {"text":"[Teams]成功加入队伍 ${latestInviteTeam} ，聊天开头添加 ! 标识可队内聊天！","color":"green"}`);
                        return 1;
                    } else {
                        server.runCommandSilent(`tellraw ${playerName} {"text":"[Teams]您没有被邀请加入任何队伍","color":"green"}`);
                        return 0;
                    }
                })
            )
            .then(Commands.literal("kick")
                .then(Commands.argument("name", Arguments.STRING.create(event))
                    .executes(ctx => {
                        var name = Arguments.STRING.getResult(ctx, "name");
                        var player = ctx.source.playerOrException;
                        var server = ctx.source.server;
                        var playerName = player.getName().getString();

                        if (kickFromTeam(playerName, name)) {
                            player.runCommandSilent(`mine_and_slash teams kick ${name}`)
                            player.runCommandSilent(`ftbteams party kick ${name}`)
                            server.runCommandSilent(`tellraw ${playerName} {"text":"[Teams]玩家 ${name} 已被移出队伍","color":"green"}`);
                            server.runCommandSilent(`tellraw ${Name} {"text":"[Teams]你已被移出队伍","color":"green"}`);
                            return 1;
                        } else {
                            server.runCommandSilent(`tellraw ${playerName} {"text":"[Teams]移出玩家失败","color":"green"}`);
                            return 0;
                        }
                    })
                )
                .executes(ctx => {
                    var player = ctx.source.playerOrException;
                    var server = ctx.source.server;
                    var playerName = player.getName().getString();
                    var playerTeam = getTeamByPlayer(playerName);
                    if (playerTeam) {
                        server.runCommandSilent(`tellraw ${playerName} {"text":"======当前队伍玩家列表======","color":"yellow"}`);
                        let cont = ""
                        let count = 0
                        playerTeam.member.forEach(name => {
                            name = String(name).slice(1, -1)
                            if (count < 4) {
                                if (cont == "") {
                                    cont = `{"text":" ${name} ，","color":"yellow","clickEvent":{"action":"run_command","value":"/teams kick '${name}'"},"hoverEvent":{"action":"show_text","value":"踢出 ${name}"}}`
                                } else {
                                    cont = cont + "," + `{"text":" ${name} ，","color":"yellow","clickEvent":{"action":"run_command","value":"/teams kick '${name}'"},"hoverEvent":{"action":"show_text","value":"踢出 ${name}"}}`
                                }
                                count++;
                            } else {
                                cont = cont + "," + `{"text":" ${name} ，","color":"yellow","clickEvent":{"action":"run_command","value":"/teams kick '${name}'"},"hoverEvent":{"action":"show_text","value":"踢出 ${name}"}}`
                                server.runCommandSilent(`tellraw ${playerName} [${cont}]`)
                                count = 0
                                cont = ""
                            }
                        })
                        server.runCommandSilent(`tellraw ${playerName} [${cont}]`)
                        return 1;
                    }
                    return 0;
                })
            )
    );
});
PlayerEvents.chat(e => {
    if (e.player.persistentData.TeamCreate == "True") {
        if (e.message.toLowerCase() == "t") {
            e.server.runCommandSilent(`tellraw ${e.player.username} {"text":"[Teams]你已取消创建队伍","color":"yellow"}`)
            e.player.persistentData.TeamCreate = "False"
            e.cancel()
        }
        e.player.runCommandSilent(`/teams create "${e.message}"`)
        e.cancel()
    }
    if (e.message.slice(0, 1) == "!" || e.message.slice(0, 1) == "！") {
        var teamInfo = getTeamByPlayer(e.player.username);
        if (teamInfo) {
            var message = String(e.message).slice(1)
            teamInfo.member.forEach(me => {
                e.server.runCommandSilent(`tellraw ${String(me).slice(1, -1)} [{"text":"[${teamInfo.name}] ","color":"yellow"}, {"text":"<${e.player.username}> ${message}","color":"white"}]`)
            })
            e.server.runCommandSilent(`tellraw ${teamInfo.leader} [{"text":"[${teamInfo.name}] ","color":"yellow"}, {"text":"<${e.player.username}> ${message}","color":"white"}]`)
            e.cancel()
        }
    }
}
)
*/