
PlayerEvents.chat((event) => {
    if (event.message.trim().includes("斗蛐蛐")) {
        if (event.player.permissionLevel <= 2) {
            event.server.runCommand('kill ' + event.player.username + ' 不准斗蛐蛐 ')
            event.server.runCommandSilent(`say ${event.player.username}触发了禁蛐令`)
        }
    }
});
