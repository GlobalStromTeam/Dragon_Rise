ItemEvents.rightClicked('heart_of_the_sea', event => {
    let { player, item, server, level } = event
    let serverPlayer = /** @type {Internal.ServerPlayer} */(player)
    if (!item.hasNBT()) {
        player.give(Item.of('heart_of_the_sea').withNBT({
            display: {
                Name: '[{"text":"高爆弹火力网","italic":false,"color":"red"}]'
            },
            strikeType: 'Cannon',
            strikeData: {
                height: 500,
                radius: 50,
                fireLag: 160,
                fireRounds: 10,
                fireRoundInterval: 50,
                firePerRound: 3,
                fireInterval: 20,
                projSpeed: 8,
                beamColor: [1, 0.24, 0.24],
                strikeProj: {
                    id: 'createbigcannons:he_shell',
                    nbt: {
                        BlockEntityTag: {
                            Fuze: { Count: true, id: "createbigcannons:proximity_fuze", tag: { DetonationDistance: 1 } },
                            Tracer: { Count: true, id: "createbigcannons:tracer_tip" },
                            id: "createbigcannons:fuzed_block"
                        }
                    }
                }
            }
        }))
        player.give(Item.of('heart_of_the_sea').withNBT({
            display: {
                Name: '[{"text":"迫击炮火力网","italic":false,"color":"red"}]'
            },
            strikeType: 'Cannon',
            strikeData: {
                height: 500,
                radius: 40,
                fireLag: 120,
                fireRounds: 10,
                fireRoundInterval: 60,
                firePerRound: 3,
                fireInterval: 10,
                projSpeed: 8,
                beamColor: [1, 0.24, 0.24],
                strikeProj: {
                    id: 'createbigcannons:drop_mortar_shell',
                    nbt: {
                        BlockEntityTag: {
                            Fuze: { Count: true, id: "createbigcannons:proximity_fuze", tag: { DetonationDistance: 6 } },
                            Tracer: { Count: true, id: "createbigcannons:tracer_tip" },
                            id: "createbigcannons:fuzed_block"
                        }
                    }
                }
            }
        }))
        player.give(Item.of('heart_of_the_sea').withNBT({
            display: {
                Name: '[{"text":"空爆火力网","italic":false,"color":"red"}]'
            },
            strikeType: 'Cannon',
            strikeData: {
                height: 300,
                radius: 3,
                fixedRadius: true,
                warnRadius: 25,
                fireLag: 100,
                fireRounds: 8,
                fireRoundInterval: 80,
                firePerRound: 1,
                fireInterval: 0,
                projSpeed: 8,
                beamColor: [1, 0.24, 0.24],
                strikeProj: {
                    id: 'createbigcannons:shrapnel_shell',
                    nbt: {
                        BlockEntityTag: {
                            Fuze: { Count: true, id: "createbigcannons:timed_fuze", tag: { FuzeTimer: 33 } },
                            Tracer: { Count: true, id: "createbigcannons:tracer_tip" },
                            id: "createbigcannons:fuzed_block"
                        }
                    }
                }
            }
        }))
        player.give(Item.of('heart_of_the_sea').withNBT({
            display: {
                Name: '[{"text":"毒气弹火力网","italic":false,"color":"red"}]'
            },
            strikeType: 'Cannon',
            strikeData: {
                height: 500,
                radius: 50,
                fireLag: 100,
                fireRounds: 10,
                fireRoundInterval: 50,
                firePerRound: 5,
                fireInterval: 10,
                projSpeed: 8,
                beamColor: [1, 0.24, 0.24],
                strikeProj: {
                    id: 'createbigcannons:fluid_shell',
                    nbt: {
                        BlockEntityTag: {
                            FluidContent: {
                                Amount: 2000, FluidName: "create:potion",
                                Tag: {
                                    Bottle: "REGULAR", CustomPotionEffects: [
                                        { Ambient: false, Amplifier: 3, CurativeItems: [{ Count: 1, id: "minecraft:milk_bucket" }], Duration: 300, Id: 20, ShowIcon: true, ShowParticles: true, "forge:id": "minecraft:wither" },
                                        { Ambient: false, Amplifier: 3, CurativeItems: [{ Count: 1, id: "minecraft:milk_bucket" }], Duration: 300, Id: 2, ShowIcon: true, ShowParticles: true, "forge:id": "minecraft:slowness" }
                                    ]
                                }
                            },
                            Fuze: { Count: true, id: "createbigcannons:proximity_fuze", tag: { DetonationDistance: 1 } },
                            Tracer: { Count: true, id: "createbigcannons:tracer_tip" },
                            id: "createbigcannons:fluid_shell"
                        }
                    }
                }
            }
        }))
        player.give(Item.of('heart_of_the_sea').withNBT({
            display: {
                Name: '[{"text":"燃烧弹火力网","italic":false,"color":"red"}]'
            },
            strikeType: 'Cannon',
            strikeData: {
                height: 500,
                radius: 50,
                fireLag: 100,
                fireRounds: 10,
                fireRoundInterval: 50,
                firePerRound: 5,
                fireInterval: 10,
                projSpeed: 8,
                beamColor: [1, 0.24, 0.24],
                strikeProj: {
                    id: 'createbigcannons:fluid_shell',
                    nbt: {
                        BlockEntityTag: {
                            FluidContent: { Amount: 2000, FluidName: "minecraft:lava" },
                            Fuze: { Count: true, id: "createbigcannons:proximity_fuze", tag: { DetonationDistance: 1 } },
                            Tracer: { Count: true, id: "createbigcannons:tracer_tip" },
                            id: "createbigcannons:fluid_shell"
                        }
                    }
                }
            }
        }))
        player.give(Item.of('heart_of_the_sea').withNBT({
            display: {
                Name: '[{"text":"精确制导炸弹","italic":false,"color":"red"}]'
            },
            strikeType: 'Missile',
            strikeData: {
                height: 150,
                vertical: 150,
                radius: 50,
                seekMode: 'health',
                fireLag: 100,
                firePerRound: 5,
                fireInterval: 10,
                projSpeed: 8,
                beamColor: [1, 0.24, 0.24],
                strikeProj: {
                    id: 'createbigcannons:he_shell',
                    nbt: {
                        BlockEntityTag: {
                            Fuze: { Count: true, id: "createbigcannons:proximity_fuze", tag: { DetonationDistance: 1 } },
                            Tracer: { Count: true, id: "createbigcannons:tracer_tip" },
                            id: "createbigcannons:fuzed_block"
                        }
                    }
                }
            }
        }))
        player.give(Item.of('heart_of_the_sea').withNBT({
            display: {
                Name: '[{"text":"集束炸弹","italic":false,"color":"red"}]'
            },
            strikeType: 'Missile',
            strikeData: {
                height: 150,
                vertical: 150,
                radius: 40,
                warnRadius: 55,
                seekMode: 'none',
                fireLag: 100,
                firePerRound: 12,
                fireInterval: 2,
                projSpeed: 8,
                beamColor: [1, 0.24, 0.24],
                strikeProj: {
                    id: 'createbigcannons:ap_shot',
                    nbt: {
                        BlockEntityTag: {
                            //Fuze: { Count: true, id: "createbigcannons:proximity_fuze", tag: { DetonationDistance: 1 } },
                            Tracer: { Count: true, id: "createbigcannons:tracer_tip" },
                            id: "createbigcannons:fuzed_block"
                        }
                    },
                    clusterData: {
                        count: 16,
                        radius: 6,
                        explosionPower: 3,
                        speed: 1,
                        random: true
                    }
                }
            }
        }))
    }

    if (item.hasNBT() && item.nbt["strikeData"]) {
        item.shrink(1)
        let speed = 2.0; // Adjust speed as needed
        let motionX = serverPlayer.lookAngle.x() * speed;  // Use positive x for forward
        let motionY = serverPlayer.lookAngle.y() * speed;  // Use positive y for upward
        let motionZ = serverPlayer.lookAngle.z() * speed;  // Use positive z for forward
        // Create a Vec3 for the motion
        let motionVec3 = new Vec3d(motionX, motionY, motionZ);
        let spawnX = serverPlayer.x + motionX
        let spawnY = serverPlayer.eyeY + motionY
        let spawnZ = serverPlayer.z + motionZ
        let spawnPos = new Vec3d(spawnX, spawnY, spawnZ);
        //console.log(autoCannonItem)
        let snowball = /** @type {Internal.Entity} */ (level.createEntity('minecraft:snowball'))
        snowball.persistentData['strikeType'] = item.nbt["strikeType"]
        snowball.persistentData['strikeData'] = item.nbt["strikeData"]
        snowball.setOwner(player)
        snowball.setPos(spawnPos)
        snowball.setDeltaMovement(motionVec3)
        snowball.spawn();
    }
})

EntityEvents.spawned('createbigcannons:ap_shot', event => {
    let { entity, server, level } = event
    if (!entity.persistentData['clusterData']) return;
    let { count, radius, explosionPower, speed, random, } = entity.persistentData['clusterData']
    let arrowPData = {
        explosionPower: explosionPower
    }
    server.scheduleRepeatingInTicks(5, event => {
        event.repeating = true
        if (entity.onGround()) {
            event.repeating = false
            //server.tell('test')
            summonRing(count, 0, radius, speed, random, entity.x, entity.y, entity.z, 'minecraft:arrow', server, level, arrowPData)
            server.scheduleInTicks(1, event => {
                let explosion = level.createExplosion(entity.x, entity.y, entity.z)
                //explosion.exploder(serverPlayer)
                explosion.strength(5)
                //explosion.explosionMode('mob');
                //explosion.causesFire(true);
                // 引爆
                explosion.explode();
                entity.kill()
            })
        }
    })

})

function summonRing(count, delay, radius, speed, random, x, y, z, entityId, server, level, entityData) {
    const angleTemp = 6.28 / count;
    //const speedTemp = (speed * 0.0000002).toFixed(8);
    //const modeTemp = 1000000
    for (let i = 0, counter = 0; i < count; i++) {
        server.scheduleInTicks(delay * i, () => {
            counter++;
            //server.tell(angleTemp * counter)
            if (random) {
                let motionX = Math.cos(angleTemp * counter) * speed * Math.random();  // Use positive x for forward
                let motionY = speed * Math.random();  // Use positive y for upward
                let motionZ = Math.sin(angleTemp * counter) * speed * Math.random();  // Use positive z for forward
                // Create a Vec3 for the motion
                let motionVec3 = new Vec3d(motionX, motionY, motionZ);
                let spawnX = x + Math.cos(angleTemp * counter) * radius * Math.random()
                let spawnY = y + radius
                let spawnZ = z + Math.sin(angleTemp * counter) * radius * Math.random()
                let spawnPos = new Vec3d(spawnX, spawnY, spawnZ)
                //server.tell(spawnPos)
                let ringEntity = level.createEntity(entityId)
                ringEntity.persistentData['entityData'] = entityData
                ringEntity.setPos(spawnPos)
                ringEntity.setDeltaMovement(motionVec3)
                ringEntity.spawn()
            } else {
                let motionX = Math.cos(angleTemp * counter) * speed;  // Use positive x for forward
                let motionY = speed * Math.random();  // Use positive y for upward
                let motionZ = Math.sin(angleTemp * counter) * speed;  // Use positive z for forward
                // Create a Vec3 for the motion
                let motionVec3 = new Vec3d(motionX, motionY, motionZ);
                let spawnX = x + Math.cos(angleTemp * counter) * radius
                let spawnY = y + radius
                let spawnZ = z + Math.sin(angleTemp * counter) * radius
                let spawnPos = new Vec3d(spawnX, spawnY, spawnZ)
                //server.tell(spawnPos)
                let ringEntity = level.createEntity(entityId)
                ringEntity.persistentData['entityData'] = entityData
                ringEntity.setPos(spawnPos)
                ringEntity.setDeltaMovement(motionVec3)
                ringEntity.spawn()
            }


            //Utils.server.tell(`execute positioned ${x} ${y} ${z} facing entity @e[type=!xtraarrows:netherite_explosive_arrow,sort=nearest,limit=1] eyes run particle ${entityId} ^${Math.sin(angleTemp*counter)} ^${Math.cos(angleTemp*counter)} ^ ^${modeTemp * Math.sin(angleTemp*counter)} ^${modeTemp * Math.cos(angleTemp*counter)} ^ ${speedTemp} 0 force`)
            //Utils.server.runCommandSilent(`execute positioned ${x} ${y} ${z} facing entity @e[type=!xtraarrows:netherite_explosive_arrow,sort=nearest,limit=1] eyes run particle ${entityId} ^${0.1 * Math.sin(angleTemp * counter)} ^${0.1 * Math.cos(angleTemp * counter)} ^-1 ^${modeTemp * Math.sin(angleTemp * counter)} ^${modeTemp * Math.cos(angleTemp * counter)} ^${modeTemp * 2} ${speedTemp} 0 force`)
            //Utils.server.runCommandSilent(`execute positioned ${x} ${y} ${z} facing ~ ~1 ~ run summon ${entityId} 10 0.2 100 1 ^${0.1 * Math.sin(angleTemp * counter)} ^${0.1 * Math.cos(angleTemp * counter)} ^-1 ^${modeTemp * Math.sin(angleTemp * counter)} ^${modeTemp * Math.cos(angleTemp * counter)} ^${modeTemp * 2} ${speedTemp} 0 force`)
        })
    }
}

/* ItemEvents.rightClicked('emerald', event => {
    let { player, item, server, level } = event
    let arrowPData = {
        explosionPower: 2
    }
    summonRing(8, 0, 2, player.x, player.y, player.z, 'minecraft:arrow', server, level, arrowPData)
    server.scheduleInTicks(1, event => {
        let explosion = level.createExplosion(player.x, player.y, player.z)
        //explosion.exploder(serverPlayer)
        explosion.strength(5)
        //explosion.explosionMode('mob');
        //explosion.causesFire(true);
        // 引爆
        explosion.explode();
    })

}) */

/* EntityEvents.spawned(event => {
    let { entity, server, level } = event
    let e = /** @type {Internal.Entity}  (entity)
    server.tell(e?.armorSlots[3].nbt.color)
}) 

//Make sure to register this item on startup, and give it durability!
/* ItemEvents.rightClicked('fire_charge', (event) => {
    let player = event.player; // Get the player who right-clicked
    let allItems = player.inventory.allItems; // Get all items in the player's inventory
    let mortar = event.item; // The mortar item

    // Iterate through all items in the player's inventory
    for (const invItem of allItems) {
        // Check if the inventory item has the 'createbigcannons:big_cannon_projectiles' tag
        if (invItem.id === 'createbigcannons:fluid_shell') {
            // Calculate the spawn position for the projectile
            let viewVec = player.getLookAngle();
            let spawnPos = null;

            //handle spawning the projectile far enough away from the player so that it doesn't hit it
            //but also prevent firing through walls.
            if (event.target.block == null) {
                let len = 4; // Distance from the player
                spawnPos = new Vec3d(
                    player.x + viewVec.x() * len,
                    player.eyeY + viewVec.y() * len,
                    player.z + viewVec.z() * len
                );
            } else {
                let { x, y, z } = event.target.block;
                spawnPos = new Vec3d(x, y, z);
            }
            let dis = 4
            let disVecX = dis * Math.sqrt(1 / (((viewVec.x() / viewVec.z()) ** 2) + 1))
            let disVecZ = -disVecX * viewVec.x() / viewVec.z()
            let projCount = 2
            // Set projectile properties and spawn it
            for (let i = 0; i < projCount; i++) {
                let proj = Block.getBlock(invItem.id)[
                    'getProjectile(net.minecraft.world.level.Level,net.minecraft.world.item.ItemStack)'
                ](event.level, invItem.copy());

                let fluidNbt = undefined
                if (invItem.nbt.BlockEntityTag?.FluidContent) {
                    let { Amount, FluidName, Tag } = invItem.nbt.BlockEntityTag.FluidContent
                    fluidNbt = {
                        Fluid: { Fluid: FluidName, FluidAmount: Amount, FluidTag: Tag }
                    }
                }
                fluidNbt ? proj.mergeNbt(fluidNbt) : undefined
                let spawnPosN = undefined
                if (projCount >= 2) {
                    spawnPosN = new Vec3d(spawnPos.x() + disVecX / 2 - disVecX * i / (projCount - 1), spawnPos.y(), spawnPos.z() + disVecZ / 2 - disVecZ * i)
                } else {
                    spawnPosN = new Vec3d(spawnPos.x(), spawnPos.y(), spawnPos.z())
                }

                //event.server.tell(spawnPos.y())
                proj.setPos(spawnPosN);
                proj.setChargePower(5.0);
                proj.shoot(viewVec.x(), viewVec.y(), viewVec.z(), 4, 0);
                proj.xRotO = player.getXRot();
                proj.yRotO = player.getYRot();
                event.level.addFreshEntity(proj);
                // Handle item durability and player cooldown for non-creative mode
                if (!player.isCreative()) {
                    invItem.count--; // Decrease ammo item count
                    mortar.maxDamage ? mortar.damageValue++ : undefined; // damage the mortar
                    if (mortar.maxDamage && mortar.damageValue > mortar.maxDamage) {
                        mortar.count--; // break the mortar if no durability
                    }
                }
                player.addItemCooldown(event.item, 40); // Add a cooldown to the mortar

                // Play the firing sound
                event.level.playSound(
                    null,
                    player.x,
                    player.y,
                    player.z,
                    'createbigcannons:fire_drop_mortar',
                    'players',
                    1,
                    1
                );
                if (!invItem.count) break;
            }
            break; // Stop after firing one shell.
        }
    }
});   */