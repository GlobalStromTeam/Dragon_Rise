PlayerEvents.chat(event => {
    var message = event.message.trim();
    var chat = [];

    if (event.player.persistentData.contains("prefix"))
        chat.push(Text.aqua(`[${event.player.persistentData["prefix"]}]`));
    var id = event.player.hasPermissions(2) ? Text.darkRed(event.player.name) : Text.white(event.player.name);
    chat.push(Text.white('<').append(id).append(Text.white('>')));
    chat.push(message)

    event.server.tell(chat);
    event.cancel();
});

ItemEvents.rightClicked(event => {
    if (event.item.areItemsEqual('paper') && event.item.hasNBT() && event.item.nbt["prefix"]){
        event.player.persistentData["prefix"] = event.item.nbt["prefix"];
        event.item.shrink(1);
    }
});