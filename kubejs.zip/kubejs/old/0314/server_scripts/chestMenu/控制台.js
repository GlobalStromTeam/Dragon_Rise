ItemEvents.rightClicked('clock', event => {
    let { player, item, server } = event
    if (item.nbt["console"]) {
        let serverPlayer = /** @type {Internal.ServerPlayer} */(player)
        openGUIMenu(serverPlayer, 控制台)
    }
})

const 控制台 = {
    description: {
        index: "控制台",
        type: "none",
        title: Text.darkGreen('『控制台』'),
        leftButton: {
            icon: 'createdeco:decal_left',
            iconNbt: {
                display: {
                    Name: '{"text":"退出","color":"red","italic":"false"}',
                    Lore: ['{"text":"按esc有一样的效果","color":"gray","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "exit",
            }
        },

    },
    set东欧: {
        index: "set东欧",
        icon: "dirt_path",
        iconNbt: {
            display: {
                Name: '{"text":"设置为东欧","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 1,
            y: 1
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['scoreboard players set 地图 Maps 0'
            ]
        }
    },
    set海岛: {
        index: "set海岛",
        icon: "grass_block",
        iconNbt: {
            display: {
                Name: '{"text":"设置为海岛","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 2,
            y: 1
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['scoreboard players set 地图 Maps 1'
            ]
        }
    },
    set中东: {
        index: "set中东",
        icon: "sand",
        iconNbt: {
            display: {
                Name: '{"text":"设置为中东","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 3,
            y: 1
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['scoreboard players set 地图 Maps 2'
            ]
        }
    },
    set雪山: {
        index: "set雪山",
        icon: "snow_block",
        iconNbt: {
            display: {
                Name: '{"text":"设置为雪山","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 4,
            y: 1
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['scoreboard players set 地图 Maps 3'
            ]
        }
    },
    set首府: {
        index: "set首府",
        icon: "minecraft:stripped_spruce_log",
        iconNbt: {
            display: {
                Name: '{"text":"设置为首府","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 5,
            y: 1
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['scoreboard players set 地图 Maps 4'
            ]
        }
    },
    set越南: {
        index: "set越南",
        icon: "oak_leaves",
        iconNbt: {
            display: {
                Name: '{"text":"设置为越南","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 6,
            y: 1
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['scoreboard players set 地图 Maps 5'
            ]
        }
    },
    set白宫: {
        index: "set白宫",
        icon: "minecraft:white_shulker_box",
        iconNbt: {
            display: {
                Name: '{"text":"设置为白宫","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 7,
            y: 1
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['scoreboard players set 地图 Maps 6'
            ]
        }
    },
    set寺庙: {
        index: "set寺庙",
        icon: "minecraft:white_shulker_box",
        iconNbt: {
            display: {
                Name: '{"text":"设置为寺庙","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 1,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['scoreboard players set 地图 Maps 7'
            ]
        }
    },
    开放红队TP: {
        index: "开放红队TP",
        icon: "minecraft:lime_stained_glass_pane",
        iconNbt: {
            display: {
                Name: '{"text":"开放红队TP","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 1,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['scoreboard players set 红队开放状态 OpenOrClose 1',
                'title @a title ["",{"text":"东联传送已开放","color":"red"}]'
            ]
        }
    },
    关闭红队TP: {
        index: "关闭红队TP",
        icon: "minecraft:red_stained_glass_pane",
        iconNbt: {
            display: {
                Name: '{"text":"关闭红队TP","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 2,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['scoreboard players set 红队开放状态 OpenOrClose 0'
            ]
        }
    },
    点位重设为红: {
        index: "点位重设为红",
        icon: "minecraft:red_concrete",
        iconNbt: {
            display: {
                Name: '{"text":"点位重设为红","color":"red","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 3,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function domination:reset_red'
            ]
        }
    },
    开放蓝队TP: {
        index: "开放蓝队TP",
        icon: "minecraft:lime_stained_glass_pane",
        iconNbt: {
            display: {
                Name: '{"text":"开放蓝队TP","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 1,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['scoreboard players set 蓝队开放状态 OpenOrClose 1',
                'title @a title ["",{"text":"盟军传送已开放","color":"blue"}]'
            ]
        }
    },
    关闭蓝队TP: {
        index: "关闭蓝队TP",
        icon: "minecraft:red_stained_glass_pane",
        iconNbt: {
            display: {
                Name: '{"text":"关闭蓝队TP","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 2,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['scoreboard players set 蓝队开放状态 OpenOrClose 0'
            ]
        }
    },
    点位重设为蓝: {
        index: "点位重设为蓝",
        icon: "minecraft:blue_concrete",
        iconNbt: {
            display: {
                Name: '{"text":"点位重设为蓝","color":"blue","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 3,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function domination:reset_blue'
            ]
        }
    },
    点位重设为白: {
        index: "点位重设为白",
        icon: "minecraft:white_concrete",
        iconNbt: {
            display: {
                Name: '{"text":"点位重设为白","color":"white","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 4,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function domination:reset_white',
                'function domination:reset_score'
            ]
        }
    },
    allBack: {
        index: "allBack",
        icon: "minecraft:red_bed",
        iconNbt: {
            display: {
                Name: '{"text":"全部抓回主城","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 7,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['clear @a',
                'tp @a 482 -59 -450'
            ]
        }
    },
    重置计时器: {
        index: "重置计时器",
        icon: "minecraft:clock",
        iconNbt: {
            display: {
                Name: '{"text":"重置计时器","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 7,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function timer:timer_reset'
            ]
        }
    },
}