
ItemEvents.rightClicked('recovery_compass', event => {
    let { player, item, server } = event
    if (item.nbt["Menu"]) {
        let serverPlayer = /** @type {Internal.ServerPlayer} */(player)
        //preMenu = menuItems
        readItemData(serverPlayer)
        switch (serverPlayer.teamId) {
            case 'EA':
                openGUIMenu(serverPlayer, menuMainRED)
                break;
            case 'WE':
                openGUIMenu(serverPlayer, menuMainBLUE)
                break;
            default:
                server.runCommandSilent(`tellraw ${serverPlayer.username} ["",{"text":"请先加入一个队伍！","color":"gold"}]`)
                break;
        }/*
        serverPlayer.tags.forEach(tag => {
            serverPlayer.removeTag(tag)
        })*/
        //serverPlayer.setFeetArmorItem(Item.of('acacia_boat').withCount(2))
        //server.tell(serverPlayer.getArmorSlots()[3].nbt)
        server.runCommandSilent(`execute as ${serverPlayer.username} at @s run playsound ${menuSounds.accept} player @s`)
        //server.runCommandSilent(`tell ${serverPlayer.username} ${menuSounds.deny}`)
        //server.tell("1")
        //let a = Item.of('acacia_boat').withNBT()
    }
})

function openGUIMenu(player, menuConfig) {

    player.openChestGUI(menuConfig.description.title, chestGUISize.height, gui => {
        //黑框装饰
        for (let i = 0; i < 9; i++) {
            for (let j = 0; j < chestGUISize.height; j++) {
                if (j == 0 || i == 0 || i == 8 || j == chestGUISize.height - 1) {
                    gui.slot(i, j, slot => {
                        slot.item = Item.of('black_stained_glass_pane')
                    })
                }
            }
        }
        //前选项按钮
        if (menuConfig.description["leftButton"]) {
            let leftButton = menuConfig.description.leftButton
            gui.slot(0, 5, slot => {

                slot.item = Item.of(leftButton.icon).withNBT(leftButton.iconNbt)
                slot.leftClicked = () => {
                    buttonAction(player, leftButton, menuConfig, "left")
                }
            })
        }
        //后选项按钮
        if (menuConfig.description["rightButton"]) {
            let rightButton = menuConfig.description.rightButton
            gui.slot(8, 5, slot => {

                slot.item = Item.of(rightButton.icon).withNBT(rightButton.iconNbt)
                slot.leftClicked = () => {
                    buttonAction(player, rightButton, menuConfig, "left")
                }
            })
        }
        //左上方按钮
        if (menuConfig.description["leftTopButton"]) {
            let leftTopButton = menuConfig.description.leftTopButton
            gui.slot(0, 0, slot => {

                slot.item = Item.of(leftTopButton.icon).withNBT(leftTopButton.iconNbt)
                slot.leftClicked = () => {
                    buttonAction(player, leftTopButton, menuConfig, "left")
                }
            })
        }
        //右上方按钮
        if (menuConfig.description["rightTopButton"]) {
            let rightTopButton = menuConfig.description.rightTopButton
            gui.slot(8, 0, slot => {

                slot.item = Item.of(rightTopButton.icon).withNBT(rightTopButton.iconNbt)
                slot.leftClicked = () => {
                    buttonAction(player, rightTopButton, menuConfig, "left")
                }
            })
        }
        //菜单的主要内容
        let menuConfigIndex = Object.keys(menuConfig)
        //let playerItemData = readItemData(player)
        let menuType = menuConfig.description.type
        //let menuTypeData = readMenuTypeData(player, menuType)

        /*进入type类中操作数据，如
                showSelection：{
                        menuItems：{
                            mainWeapons：{
                                digger: {
                                    id: "minecraft:iron_shovel",
                                    count: 1,
                                    nbt: {
                                        GunId: "",
                                        display: {
                                            Name: "",
                                            Lore: [""]
                                        }
                                    }
                                }
                            }
                        }
                    }
            menuTypeData指showSelection：{}
            menuData指menuItems：{}
            menuConfig是当前所处的菜单，可能是menuItems或mainWeapons或digger
            menuElement指当前菜单的子菜单，可能是mainWeapons或digger或nbt
            顺序是menuType-menu以及menuConfig-menuElement依次包含
        */
        for (let i = 0; i < menuConfigIndex.length; i++) {
            let index = menuConfigIndex[i]
            let menuElement = menuConfig[index]
            //遍历每一个子菜单
            if (index != "description") {
                let x0 = menuElement.location.x
                let y0 = menuElement.location.y
                let menuData = undefined
                //console.log(menuData)
                //根据description的type选择
                switch (menuType) {
                    //在物品位置显示已经选择的物品，否则显示未选择
                    //使用例：主菜单
                    case "showSelection":
                        menuData = readMenuData(player, menuType, index)
                        //console.log(menuData)
                        //gui.slot(x0, y0, slot => {
                        gui.slot(x0, y0, slot => {
                            if (menuData["icon"]) {
                                let mixNbt = Object.assign({},
                                    menuData.icon.nbt,
                                    menuElement.iconNbt
                                )
                                slot.item = Item.of(menuData.icon.id)
                                    .withNBT(mixNbt),
                                    slot.leftClicked = () => {
                                        //player.server.tell('test1')
                                        buttonAction(player, menuElement, menuConfig, "left")
                                    }
                            } else {
                                if (menuElement["icon"]) {
                                    slot.item = Item.of(menuElement.icon).withNBT(menuElement.iconNbt)
                                } else {
                                    slot.item = Item.of(unselectSign.type).withNBT(menuElement.iconNbt)
                                }

                                slot.leftClicked = () => {
                                    //player.server.tell('test2')
                                    buttonAction(player, menuElement, menuConfig, "left")
                                }
                                if (menuElement["rightClickAction"]) {
                                    slot.rightClicked = () => { buttonAction(player, menuElement, menuConfig, "right") }
                                }
                            }
                        })
                        break;
                    case "conductSelect":
                        menuData = readMenuData(player, menuType, menuConfig.description.index)
                        gui.slot(x0, y0, slot => {
                            //let playerSubItemData = playerItemData[menuConfig.description.index]
                            //console.log(playerSubItemData)
                            if (menuData[menuElement.index] && menuData[menuElement.index].selCount >= 1) {
                                slot.item = Item.of(menuElement.icon)
                                    .withNBT(menuElement.iconNbt)
                                    .enchant("minecraft:sweeping", 1)
                                    .withCount(menuData[menuElement.index].selCount)
                                //console.log("test2")
                            } else {
                                slot.item = Item.of(menuElement.icon).withNBT(menuElement.iconNbt)
                            }
                            //console.log(getCount(playerItemData, index))
                            //console.log(index)
                            //console.log(player.persistentData.playerItemData[menuConfig.description.index].indexOf(index))
                            //player.server.tell('test4')
                            slot.leftClicked = () => { buttonAction(player, menuElement, menuConfig, "left") }
                            if (menuElement["rightClickAction"]) {
                                slot.rightClicked = () => { buttonAction(player, menuElement, menuConfig, "right") }
                            }
                            //preMenu = menuConfig
                            //player.server.tell('test6')
                            //player.server.tell('test5')
                        })
                        break;
                    case "nbtModifier":
                        menuData = readMenuData(player, menuType, menuElement.leftClickAction.targetItem)
                        //console.log(menuData[menuConfig.description.index])
                        //console.log(menuElement.index)
                        gui.slot(x0, y0, slot => {
                            //let playerSubItemData = playerItemData[menuConfig.description.index]
                            //console.log(playerSubItemData)
                            if (menuData[menuConfig.description.index] && menuData[menuConfig.description.index]["index"] && menuData[menuConfig.description.index]["index"] == menuElement.index) {
                                slot.item = Item.of(menuElement.icon)
                                    .withNBT(menuElement.iconNbt)
                                    .enchant("minecraft:sweeping", 1)
                                //console.log("test2")
                            } else {
                                slot.item = Item.of(menuElement.icon).withNBT(menuElement.iconNbt)
                            }
                            //console.log(getCount(playerItemData, index))
                            //console.log(index)
                            //console.log(player.persistentData.playerItemData[menuConfig.description.index].indexOf(index))
                            //player.server.tell('test4')
                            slot.leftClicked = () => { buttonAction(player, menuElement, menuConfig, "left") }
                            if (menuElement["rightClickAction"]) {
                                slot.rightClicked = () => { buttonAction(player, menuElement, menuConfig, "right") }
                            }
                            //preMenu = menuConfig
                            //player.server.tell('test6')
                            //player.server.tell('test5')
                        })
                        break;
                    case "invSave":
                        let playerInventoryData = readInventoryData(player)
                        if (!playerInventoryData[menuType]) {
                            playerInventoryData[menuType] = {}
                            playerInventoryData['tagSave'] = {}
                        }
                        menuData = playerInventoryData[menuType]
                        //menuData = readMenuTypeData(player, menuType)
                        //console.log(menuData)
                        //console.log(menuData)
                        //gui.slot(x0, y0, slot => {

                        gui.slot(x0, y0, slot => {
                            if (menuData[menuElement.leftClickAction.invPath] && menuData[menuElement.leftClickAction.invPath][0]?.tag) {
                                let mixNbt = Object.assign({},
                                    menuData[menuElement.leftClickAction.invPath][0]?.tag,
                                    menuElement.iconNbt
                                )
                                slot.item = Item.of(menuData[menuElement.leftClickAction.invPath][0].id)
                                    .withNBT(mixNbt)
                            } else {
                                slot.item = Item.of(menuElement.icon).withNBT(menuElement.iconNbt)
                            }


                            slot.leftClicked = () => {
                                //player.server.tell('test2')
                                buttonAction(player, menuElement, menuConfig, "left")
                            }
                            if (menuElement["rightClickAction"]) {
                                slot.rightClicked = () => { buttonAction(player, menuElement, menuConfig, "right") }
                            }
                        })
                        break;
                    //默认菜单
                    default:
                        gui.slot(x0, y0, slot => {
                            slot.item = Item.of(menuElement.icon).withNBT(menuElement.iconNbt)
                            //player.server.tell('test4')
                            slot.leftClicked = () => { buttonAction(player, menuElement, menuConfig, "left") }
                            if (menuElement["rightClickAction"]) {
                                slot.rightClicked = () => { buttonAction(player, menuElement, menuConfig, "right") }
                            }
                            //preMenu = menuConfig
                            //player.server.tell('test6')
                            //player.server.tell('test5')
                        })
                        break;
                }
            }
        }
    })
}

function buttonAction(player, element, currentMenu, side) {
    let menuName = currentMenu.description.index
    //let menuType = currentMenu.description.type
    //let elementName = Object.keys( element )
    let playerItemData = readItemData(player)
    let playerInventoryData = readInventoryData(player)
    //console.log(elementName)
    let playerName = player.username
    let server = player.server
    let choseType = element.leftClickAction.type
    if (side == "right") {
        choseType = element.rightClickAction.type
    }
    switch (choseType) {
        case "exit":
            //console.log(allItemList)
            player.closeMenu()
            break;
        case "deploy":
            server.scheduleInTicks(2, callback => {

                //server.tell(`execute as ${playerName} run ${commandText.toString().slice(1, -1)}`)
                //server.tell(typeof commandText)
                server.runCommandSilent(`clear ${playerName}`)
                server.runCommandSilent(`tag ${playerName} remove Radar`)
                server.runCommandSilent(`tag ${playerName} remove Explode`)
                server.runCommandSilent(`give ${playerName} recovery_compass{Menu:1}`)
                server.runCommandSilent(`give ${playerName} clock{Menu:1}`)
                server.runCommandSilent(`give ${playerName} combatgear:pillsui`)
            })

            let indexList = Object.keys(playerItemData["conductSelect"])
            for (let i = 0; i < indexList.length; i++) {
                let itemList = playerItemData.conductSelect[indexList[i]]
                let itemListIndex = Object.keys(itemList)
                for (let i = 0; i < itemListIndex.length; i++) {
                    let itemIndex = itemListIndex[i];
                    let item = itemList[itemListIndex[i]]
                    readMenuTypeData(player, "nbtModifier")
                    let nbtList = playerItemData.nbtModifier[itemIndex]
                    switch (item.type) {
                        case "single":
                            if (nbtList) {
                                let mixNbt = undefined
                                let nbtListIndex = Object.keys(nbtList)
                                for (let i = 0; i < nbtListIndex.length; i++) {
                                    let nbtIndex = nbtListIndex[i];
                                    let nbtElement = nbtList[nbtIndex]
                                    //console.log(nbtForItemPart)
                                    let mixPartNbt = nbtElement[itemPartIndexList[i]]
                                    mixNbt = Object.assign({},
                                        mixNbt,
                                        mixPartNbt.nbt,
                                    )
                                    //console.log(mixNbt)
                                }
                                //console.log(mixNbt)
                                mixNbt = Object.assign({},
                                    mixNbt,
                                    item.nbt,
                                )
                                //console.log(mixNbt)

                                server.scheduleInTicks(2, callback => {
                                    if (item["armorSlot"]) {
                                        mergePlayerArmorSlot(player, item["armorSlot"], Item.of(item.id).withNBT(mixNbt).withCount(item.selCount * item.count))
                                    } else {
                                        player.give(Item.of(item.id).withNBT(mixNbt).withCount(item.selCount * item.count))
                                    }

                                })
                            } else {
                                //server.tell(item.selCount)
                                server.scheduleInTicks(2, callback => {
                                    if (item["armorSlot"]) {
                                        mergePlayerArmorSlot(player, item["armorSlot"], Item.of(item.id).withNBT(item.nbt).withCount(item.selCount * item.count))
                                    } else {
                                        player.give(Item.of(item.id).withNBT(item.nbt).withCount(item.selCount * item.count))
                                    }
                                })
                            }
                            break;
                        case "multiple":
                            //console.log(mixNbt)
                            let itemPartIndexList = Object.keys(item).filter(function (item) {
                                return (item !== "type" && item !== "selCount")
                            })
                            for (let i = 0; i < itemPartIndexList.length; i++) {
                                //console.log(itemPartIndexList[i])
                                let itemPart = item[itemPartIndexList[i]]
                                //console.log(itemPart)
                                if (nbtList) {
                                    let mixNbt = undefined
                                    let nbtListIndex = Object.keys(nbtList)
                                    for (let j = 0; j < nbtListIndex.length; j++) {
                                        let nbtIndex = nbtListIndex[j];
                                        let nbtElement = nbtList[nbtIndex]
                                        let mixPartNbt = nbtElement[itemPartIndexList[i]]
                                        if (mixPartNbt) {
                                            mixNbt = Object.assign({},
                                                mixNbt,
                                                mixPartNbt.nbt,
                                            )
                                        }
                                        //console.log(mixPartNbt.nbt)
                                    }
                                    //let itemPart = item[itemPartIndexList[i]]
                                    mixNbt = Object.assign({},
                                        mixNbt,
                                        itemPart.nbt,
                                    )
                                    server.scheduleInTicks(2, callback => {
                                        //console.log(itemPart)
                                        if (itemPart["armorSlot"]) {
                                            mergePlayerArmorSlot(player, itemPart["armorSlot"], Item.of(itemPart.id).withNBT(mixNbt).withCount(item.selCount * itemPart.count))
                                        } else {
                                            //server.tell(itemPart.selCount)
                                            //server.tell(itemPart.count)
                                            player.give(Item.of(itemPart.id).withNBT(mixNbt).withCount(item.selCount * itemPart.count))
                                        }
                                        //server.tell(`give ${playerName} ${itemPart.id}${mixNbt} ${itemPart.selCount}`)
                                        //server.runCommandSilent(`give ${playerName} ${itemPart.id}${mixNbt} ${itemPart.selCount}`)
                                    })
                                } else {
                                    //console.log(itemPart)
                                    //let itemPart = item[itemPartIndexList[i]]
                                    server.scheduleInTicks(2, callback => {
                                        if (itemPart["armorSlot"]) {
                                            //console.log(itemPart["armorSlot"])
                                            mergePlayerArmorSlot(player, itemPart["armorSlot"], Item.of(itemPart.id).withNBT(itemPart.nbt).withCount(item.selCount * itemPart.count))
                                        } else {
                                            //console.log(item)
                                            player.give(Item.of(itemPart.id).withNBT(itemPart.nbt).withCount(item.selCount * itemPart.count))
                                        }
                                    })
                                }
                            }
                            break;
                        case 'command':
                            server.scheduleInTicks(2, callback => {
                                item.commands.forEach(commandText => {
                                    //server.tell(`execute as ${playerName} run ${commandText.toString().slice(1, -1)}`)
                                    //server.tell(typeof commandText)
                                    server.runCommandSilent(`execute as ${playerName} at @s run ${commandText.toString().slice(1, -1)}`)
                                });
                            })
                            break;

                        default:
                            break;
                    }
                }
                //index是mainTools这一级,itemlist是mainTools里的东西
            }

            player.closeMenu()
            /*server.scheduleInTicks(2, callback => {
                server.runCommandSilent(`clear ${player.username} minecraft:recovery_compass`)
            })*/
            break;

        //不允许重复选择
        case "simpleSelect":

            mergeSimpleSelectItem(player, element, currentMenu)
            mergeDisplayItem(player, element, currentMenu)
            openGUIMenu(player, currentMenu)
            break;
        //允许重复选择
        case "multiSelect":

            mergeMultiSelectItem(player, element, currentMenu)
            mergeDisplayItem(player, element, currentMenu)
            openGUIMenu(player, currentMenu)
            //console.log(element)
            break;

        case "nbtSelect":

            mergeItemNbt(player, element, currentMenu)
            mergeDisplayItem(player, element, currentMenu)
            openGUIMenu(player, currentMenu)
            break;
        case "changeMenu":
            //player.closeMenu()
            if (side == "left") {
                openGUIMenu(player, element.leftClickAction.nextMenu)
            } else {
                openGUIMenu(player, element.rightClickAction.nextMenu)
            }
            server.runCommandSilent(`execute as ${player.username} at @s run playsound ${menuSounds.changeMenu} player @s`)
            break;
        case "runCommand":
            server.scheduleInTicks(2, callback => {
                element.leftClickAction.commands.forEach(commandText => {
                    //server.tell(`execute as ${player.username} run playsound ${commandText} player @s`)
                    server.runCommandSilent(`execute as ${player.username} run ${commandText}`)
                })
            })
            player.closeMenu()
            break;
        case "reset":
            //console.log(typeof playerItemData.toString())
            let menuType = currentMenu.description.type
            //delete playerItemData[menuType][menuName]
            //console.log(findKey(playerItemData, menuName))
            if (findKey(playerItemData[menuType], menuName)) {
                delete playerItemData[menuType][menuName]
                let showIndex = Object.keys(playerItemData["showSelection"])
                showIndex.forEach(index => {
                    if (index == menuName) {
                        //console.log(playerItemData["showSelection"][index])
                        //console.log(index)
                        delete playerItemData["showSelection"][index]
                    }
                });
                //server.tell('1')
            } else {
                //只有主界面会找不到对象
                delete player.persistentData.playerItemData[player.teamId]
                //server.tell('2')
            }
            /* player.tags.forEach(tag=>{
                player.removeTag(tag)
            }) */
            server.runCommandSilent(`execute as ${player.username} at @s run playsound ${menuSounds.reset} player @s`)
            openGUIMenu(player, currentMenu)
            break;

        case "saveInventory":
            player.closeMenu()
            server.runCommandSilent(`title ${player.username} title ["",{"text":"5","color":"red"}]`)
            server.scheduleInTicks(20, callback => {
                server.runCommandSilent(`title ${player.username} title ["",{"text":"4","color":"red"}]`)
                server.scheduleInTicks(20, callback => {
                    server.runCommandSilent(`title ${player.username} title ["",{"text":"3","color":"red"}]`)
                    server.scheduleInTicks(20, callback => {
                        server.runCommandSilent(`title ${player.username} title ["",{"text":"2","color":"red"}]`)
                        server.scheduleInTicks(20, callback => {
                            server.runCommandSilent(`title ${player.username} title ["",{"text":"1","color":"red"}]`)

                        })
                    })
                })
            })
            server.scheduleInTicks(100, callback => {
                server.runCommandSilent(`title ${player.username} title ["",{"text":"已保存","color":"red"}]`)
                //player.persistentData[element.leftClickAction.invPath] = player.nbt.get("Inventory")
                playerInventoryData.invSave[element.leftClickAction.invPath] = player.nbt.get("Inventory")
                //delete player.persistentData["Tmp"]
                if(player.nbt.get("Tags")){
                    playerInventoryData.tagSave[element.leftClickAction.invPath] = player.nbt.get("Tags")
                }

            })
            break;
        case "loadInventory":
            player.closeMenu()
            server.scheduleInTicks(2, callback => {
                if (playerInventoryData.invSave[element.leftClickAction.invPath]) {
                    //player.persistentData['invTmp'] = player.persistentData.get(element.leftClickAction.invPath).copy()

                    player.inventory.load(playerInventoryData.invSave.get(element.leftClickAction.invPath).copy())
                    player.tags.clear()
                    for (let i = 0; i < playerInventoryData.tagSave[element.leftClickAction.invPath].length; i++) {
                        player.addTag(playerInventoryData.tagSave[element.leftClickAction.invPath][i])
                    }
                    
                    //delete player.persistentData['invTmp']
                    //player.inventoryMenu.broadcastFullState()
                    server.runCommandSilent(`title ${player.username} title ["",{"text":"已加载","color":"gold"}]`)
                } else {
                    server.runCommandSilent(`title ${player.username} title ["",{"text":"请先保存配置","color":"red"}]`)
                }
            })
            break;
        default:
            break;
    }
}

function readItemData(player) {
    if (!player.persistentData["playerItemData"]) {
        player.persistentData["playerItemData"] = {}
    }
    if (!player.persistentData.playerItemData[player.teamId]) {
        player.persistentData.playerItemData[player.teamId] = {}
    }
    return player.persistentData.playerItemData[player.teamId]

}

function readInventoryData(player) {
    if (!player.persistentData["playerInventoryData"]) {
        player.persistentData["playerInventoryData"] = {}
    }
    if (!player.persistentData.playerInventoryData[player.teamId]) {
        player.persistentData.playerInventoryData[player.teamId] = {}
    }
    return player.persistentData.playerInventoryData[player.teamId]

}

function readMenuTypeData(player, type) {
    let data = readItemData(player)
    //console.log(data)
    if (!data[type]) {
        data[type] = {}
    }
    return data[type]
}

function readMenuData(player, type, menu) {
    let data = readMenuTypeData(player, type)
    //console.log(data)
    if (!data[menu]) {
        data[menu] = {}
    }
    return data[menu]
}

function mergeDisplayItem(player, menuElement, menu) {
    let playerMenuTypeData = readMenuTypeData(player, "showSelection")
    //let playerMenuData = playerMenuTypeData[menu.description.index]
    playerMenuTypeData[menu.description.index] = {
        icon: {
            id: menuElement.icon,
            nbt: menuElement.iconNbt
        }
    }
}

function mergeSimpleSelectItem(player, menuElement, menu) {
    let playerMenuTypeData = readMenuTypeData(player, "conductSelect")
    let playerMenuData = playerMenuTypeData[menu.description.index]
    let server = player.server
    //let playerMenuElementData = playerMenuData[menuElement.index]
    //type对应simpleselect，menu对应maintools，element对应shield
    //console.log(playerMenuTypeData)
    //console.log(menuElement.leftClickAction.items)
    if (!playerMenuData[menuElement.index]) {
        if (getItemCountInMenu(playerMenuData) >= menu.description.maxSelect) {
            let firstItem = playerMenuData[Object.keys(playerMenuData)[0]]
            firstItem.selCount -= 1
            if (firstItem.selCount <= 0) {
                //console.log(firstItem)
                delete playerMenuData[Object.keys(playerMenuData)[0]]
            }
        }
        playerMenuData[menuElement.index] = menuElement.leftClickAction.items
        playerMenuData[menuElement.index].selCount = 1
        server.runCommandSilent(`execute as ${player.username} at @s run playsound ${menuSounds.accept} player @s`)
        //console.log(playerMenuData)
    } else {
        server.runCommandSilent(`execute as ${player.username} at @s run playsound ${menuSounds.deny} player @s`)
    }

}

function mergeMultiSelectItem(player, menuElement, menu) {
    let playerMenuTypeData = readMenuTypeData(player, "conductSelect")
    let playerMenuData = playerMenuTypeData[menu.description.index]
    let server = player.server
    //let playerMenuElementData = playerMenuData[menuElement.index]
    if (getItemCountInMenu(playerMenuData) >= menu.description.maxSelect) {
        let firstItem = playerMenuData[Object.keys(playerMenuData)[0]]
        firstItem.selCount -= 1
        if (firstItem.selCount <= 0) {
            //console.log(firstItem)
            delete playerMenuData[Object.keys(playerMenuData)[0]]
        }
    }

    if (!playerMenuData[menuElement.index]) {

        playerMenuData[menuElement.index] = menuElement.leftClickAction.items
        playerMenuData[menuElement.index].selCount = 1
    } else {
        playerMenuData[menuElement.index].selCount += 1
    }
    server.runCommandSilent(`execute as ${player.username} at @s run playsound ${menuSounds.accept} player @s`)
}

function mergeItemNbt(player, menuElement, menu) {
    //nbt的格式相对不一样，所以读取方式也不同
    let playerMenuTypeData = readMenuTypeData(player, "nbtModifier")
    let playerMenuData = playerMenuTypeData[menuElement.leftClickAction.targetItem]
    let server = player.server
    //let playerMenuElementData = playerMenuData[menu.description.index]
    //console.log(playerMenuData)
    server.runCommandSilent(`execute as ${player.username} at @s run playsound ${menuSounds.accept} player @s`)
    playerMenuData[menu.description.index] = menuElement.leftClickAction.nbts
    playerMenuData[menu.description.index].index = menuElement.index
}

function mergePlayerArmorSlot(player, slot, item) {
    switch (slot) {
        case 'head':
            //console.log(itemPart["armorSlot"])
            player.setHeadArmorItem(item)
            break;
        case 'chest':
            player.setChestArmorItem(item)
            break;
        case 'legs':
            player.setLegsArmorItem(item)
            break;
        case 'feet':
            player.setFeetArmorItem(item)
            break;
        default:
            break;
    }
}

function getItemCountInMenu(menu) {
    let menuIndex = Object.keys(menu)
    let count = 0
    for (let i = 0; i < menuIndex.length; i++) {
        let index = menuIndex[i]
        let menuElement = menu[index];
        if (menuElement["selCount"]) {
            count += menuElement["selCount"]
        }
    }
    return count
}

function findKey(data, field) {
    return `${data}`.includes(field)
}

