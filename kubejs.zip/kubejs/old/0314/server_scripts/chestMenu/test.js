
const examplePlayerItemData = {
    //依据 type-menu-menuElement-物品和nbt 的格式储存
    //如主菜单对应menuItems，读取时就根据showSelection-menuItems显示对应的物品
    //只有在菜单type为showSelection时才会读取和写入showSelection，否则显示菜单本身提供的物品
    //如果菜单本身提供物品，则优先显示物品而非空位
    showSelection: {
        menuItems: {
            mainWeapons: {
                icon: {
                    id: "minecraft:iron_sword",
                    nbt: {
                        GunId: "",
                        display: {
                            Name: "",
                            Lore: [""]
                        }
                    }
                }
            },
            subTools: {
                icon: {
                    id: "minecraft:iron_axe",
                    nbt: {
                        GunId: "",
                        display: {
                            Name: "",
                            Lore: [""]
                        }
                    }
                }
            },
        },
    },
    conductSelect: {
        mainWeapons: {
            qbz951: {
                type: "multiple",
                selCount: 1,
                gunItem: {
                    id: 'tacz:modern_kinetic_gun',
                    count: 1,
                    nbt: {
                        HasBulletInBarrel: true,
                        GunFireMode: "AUTO",
                        GunId: "suffuse:qbz951",
                        GunCurrentAmmoCount: Integer.parseInt('30')
                    }
                },
                ammos: {
                    id: 'tacz:ammo_box',
                    count: 1,
                    nbt: {
                        Level: Integer.parseInt('1'),
                        AmmoCount: Integer.parseInt('180'),
                        AmmoId: "tacz:556x45"
                    }
                }
            },
            aaa: {

            }
        },
        mainTools: {
            xxx: {
                type: "multiple",
                selCount: 1,
                xxx_1: {
                    id: "minecraft:iron_pickaxe",
                    count: 1,
                    nbt: {
                        GunId: "",
                        display: {
                            Name: "",
                            Lore: [""]
                        }
                    }
                },
                xxx_2: {
                    id: "minecraft:iron_pickaxe",
                    count: 1,
                    nbt: {
                        GunId: "",
                        display: {
                            Name: "",
                            Lore: [""]
                        }
                    }
                }

            },
            ccc: {
                type: "command",
                selCount: 1,
                commands: ['tag @s add aaa']
            }
        },
    },
    nbtModifier: {
        qbz951: {
            qbz951Scopes: {
                index: "",
                gunItem: {
                    nbt: {
                        AttachmentEXTENDED_MAG: {
                            id: "tacz:attachment",
                            count: true,
                            tag: {
                                AttachmentId: "tacz:extended_mag_2"
                            }
                        }
                    }
                }
            },
        }
    },
}


