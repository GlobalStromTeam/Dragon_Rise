const ReCD = 10

ItemEvents.rightClicked('clock', event => {
    let { player, item, server } = event
    if (item.nbt["Menu"]) {
        let serverPlayer = /** @type {Internal.ServerPlayer} */(player)
        //openGUIMenu(serverPlayer,menuItemsBLUETP)
        //preMenu = menuItems
        readRespawnCD(serverPlayer)
        //let mapScore = getPlayerScore('地图', 'Maps')
        let Maps = server.scoreboard.getObjective('Maps')
        let mapScore = server.scoreboard.getOrCreatePlayerScore('地图', Maps).getScore()
        let OpenOrClose = server.scoreboard.getObjective('OpenOrClose')


        //server.tell(mapScore)
        //server.tell(serverPlayer.persistentData["RespawnCD"])

        if (serverPlayer.persistentData["RespawnCD"] >= ReCD) {
            switch (serverPlayer.teamId) {
                case 'EA':
                    let redOOC = server.scoreboard.getOrCreatePlayerScore('红队开放状态', OpenOrClose).getScore()
                    if (redOOC == 1) {
                        switch (mapScore) {
                            case 0:
                                //东欧
                                openGUIMenu(serverPlayer, 东欧REDTP)
                                break;
                            case 1:
                                //东欧
                                openGUIMenu(serverPlayer, 海岛REDTP)
                                break;
                            case 2:
                                //东欧
                                openGUIMenu(serverPlayer, 中东REDTP)
                                break;
                            case 3:
                                //东欧
                                openGUIMenu(serverPlayer, 雪山REDTP)
                                break;
                            case 4:
                                //东欧
                                openGUIMenu(serverPlayer, 首府REDTP)
                                break;
                            case 5:
                                //东欧
                                openGUIMenu(serverPlayer, 越南REDTP)
                                break;
                            case 6:
                                //东欧
                                openGUIMenu(serverPlayer, 白宫REDTP)
                                break;
                            case 7:
                                //东欧
                                openGUIMenu(serverPlayer, 寺庙REDTP)
                                break;
                            default:
                                break;
                        }
                    } else {
                        server.runCommandSilent(`tellraw ${serverPlayer.username} ["",{"text":"传送未开放！","color":"gold"}]`)
                    }

                    //openGUIMenu(serverPlayer, menuItemsREDTP)
                    break;
                case 'WE':
                    let blueOOC = server.scoreboard.getOrCreatePlayerScore('蓝队开放状态', OpenOrClose).getScore()
                    if (blueOOC == 1) {
                        switch (mapScore) {
                            case 0:
                                //东欧
                                openGUIMenu(serverPlayer, 东欧BLUETP)
                                break;
                            case 1:
                                //东欧
                                openGUIMenu(serverPlayer, 海岛BLUETP)
                                break;
                            case 2:
                                //东欧
                                openGUIMenu(serverPlayer, 中东BLUETP)
                                break;
                            case 3:
                                //东欧
                                openGUIMenu(serverPlayer, 雪山BLUETP)
                                break;
                            case 4:
                                //东欧
                                openGUIMenu(serverPlayer, 首府BLUETP)
                                break;
                            case 5:
                                //东欧
                                openGUIMenu(serverPlayer, 越南BLUETP)
                                break;
                            case 6:
                                //东欧
                                openGUIMenu(serverPlayer, 白宫BLUETP)
                                break;
                            case 7:
                                //东欧
                                openGUIMenu(serverPlayer, 寺庙BLUETP)
                                break;
                            default:
                                break;
                        }
                    } else {
                        server.runCommandSilent(`tellraw ${serverPlayer.username} ["",{"text":"传送未开放！","color":"gold"}]`)
                    }
                    //openGUIMenu(serverPlayer, menuItemsBLUETP)
                    break;
                default:
                    server.runCommandSilent(`tellraw ${serverPlayer.username} ["",{"text":"请先加入一个队伍！","color":"gold"}]`)
                    break;
            }
            server.runCommandSilent(`execute as ${serverPlayer.username} at @s run playsound ${menuSounds.accept} player @s`)
        } else {
            server.runCommandSilent(`tellraw ${serverPlayer.username} ["",{"text":"重生冷却未完成！剩余时间：${ReCD - serverPlayer.persistentData["RespawnCD"]} 秒","color":"gold"}]`)
            server.runCommandSilent(`execute as ${serverPlayer.username} at @s run playsound ${menuSounds.accept} player @s`)
        }
        //readItemData(serverPlayer)

        //serverPlayer.setFeetArmorItem(Item.of('acacia_boat').withCount(2))
        //server.tell(serverPlayer.getArmorSlots()[3].nbt)

        //server.runCommandSilent(`tell ${serverPlayer.username} ${menuSounds.deny}`)
        //server.tell("1")
        //let a = Item.of('acacia_boat').withNBT()

    }
})

EntityEvents.death(event => {
    const { entity } = event
    if (entity.isPlayer()) {
        entity.persistentData["RespawnCD"] = 0
    }
})

ServerEvents.tick(event => {
    let { server } = event
    if (server.tickCount % 20 == 0) {
        //server.tell(server.players)
        server.players.forEach(player => {
            player.persistentData["RespawnCD"] += 1
        });

    }
})

function readRespawnCD(player) {
    if (!player.persistentData["RespawnCD"]) {
        player.persistentData["RespawnCD"] = 0
    }
    return player.persistentData["RespawnCD"]
}

function getPlayerScore(player, objectiveName) {
    const scoreboard = player.getScoreboard();
    const objective = scoreboard.getObjective(objectiveName);
    if (!objective) {
        console.log(`Objective not found: ${objectiveName}`);
        return null
    }
    const scoreHolder = Java.loadClass('net.minecraft.world.scores.ScoreHolder').forNameOnly(player.getUsername());
    const score = scoreboard.getOrCreatePlayerScore(scoreHolder, objective);
    return score.getScore();
}