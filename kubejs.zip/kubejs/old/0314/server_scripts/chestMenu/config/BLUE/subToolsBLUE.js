const subToolsBLUE = {
    description: {
        index: "subToolsBLUE",
        type: "conductSelect",
        maxSelect: 2,
        title: Text.black('『副道具菜单』'),
        leftButton: {
            icon: 'createdeco:decal_left',
            iconNbt: {
                display: {
                    Name: '{"text":"返回","color":"gold","italic":"false"}',
                    Lore: ['{"text":"回到上一界面","color":"white","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "changeMenu",
                get nextMenu() {
                    return menuItemsBLUE
                }
            }
        },
        leftTopButton: {
            icon: 'createdeco:decal_warning',
            iconNbt: {
                display: {
                    Name: '{"text":"重置","color":"red","italic":"false"}',
                    Lore: ['{"text":"重置当前页面下的选择","color":"white","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "reset"
            },
        }
    },
    爆破套件: {
        index: "爆破套件",
        icon: 'minecraft:tnt',
        iconNbt: {
            display: {
                Name: '["",{"text":"爆破套件","color":"green","italic":false}]'
            },
        },
        location: {
            x: 1,
            y: 2
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                tnt: {
                    id: 'minecraft:tnt',
                    count: 4,
                    nbt: {}
                },
                goggles: {
                    id: 'create:goggles',
                    count: 1,
                    nbt: {}
                },
                flint: {
                    id: 'minecraft:flint_and_steel',
                    count: 1,
                    nbt: {}
                },
                IED: {
                    id: 'minecraft:creeper_spawn_egg',
                    count: 12,
                    nbt: { EntityTag: { id: 'magma_cube', Size: 0, CustomName: '[{"text":"地雷"}]', Health: 10, NoAI: true, Team: 'WE', ActiveEffects: [{ Id: 14, Duration: 72000, Amplifier: 0, ShowParticles: false }], Attributes: [{ Name: "generic.max_health", Base: 10 }] }, display: { Name: '[{"text":"IED地雷 Blue","italic":false,"color":"blue"}]', Lore: ['[{"text":"敌人接近地雷","italic":false,"color":"white"},{"text":"3格","color":"yellow"},{"text":"范围时爆炸，不会被"},{"text":"友军","color":"green"},{"text":"触发。"},{"text":"","color":"dark_purple"}]', '[{"text":"为了敌人的危险着想，请放在狭窄要道处。","italic":false,"color":"gray"}]'] } }
                },
            }
        }
    },
    构筑套件: {
        index: "构筑套件",
        icon: 'minecraft:stone_pickaxe',
        iconNbt: {
            display: {
                Name: '["",{"text":"构筑套件","color":"green","italic":false}]'
            },
        },
        location: {
            x: 1,
            y: 3
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                scaffolding: {
                    id: 'create:andesite_scaffolding',
                    count: 16,
                    nbt: {}
                },
                /* brick: {
                    id: 'minecraft:brick_slab',
                    count: 36,
                    nbt: {}
                }, */
                sandbag: {
                    id: 'create_tank_defenses:sandbag',
                    count: 16,
                    nbt: {}
                },
                goggles: {
                    id: 'create:goggles',
                    count: 1,
                    nbt: {}
                },
                pickaxe: {
                    id: 'minecraft:stone_pickaxe',
                    count: 1,
                    nbt: {}
                },
            }
        }
    },
    神经活性维持剂: {
        index: "神经活性维持剂",
        icon: 'minecraft:potion',
        iconNbt: {
            CustomPotionColor: 8991416,
            display: {
                Name: '["",{"text":"神经活性维持剂","italic":false,"color":"light_purple"}]',
                Lore: ['["",{"text":"8秒的无敌，即使被打成破布也能继续行动。","italic":false,"color":"white"}]', '["",{"text":"那么，代价是什么呢？","italic":false,"color":"dark_red"}]']
            }
        },
        location: {
            x: 2,
            y: 2
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "single",
                id: 'minecraft:potion',
                count: 1,
                nbt: { CustomPotionColor: 8991416, CustomPotionEffects: [{ Id: 11, Duration: 160, Amplifier: 9 }, { Id: 20, Duration: 72000, Amplifier: 1 }, { Id: 2, Duration: 72000, Amplifier: 3 }, { Id: 19, Duration: 72000, Amplifier: 1 }, { Id: 17, Duration: 72000, Amplifier: 49 }], display: { Name: '["",{"text":"神经活性维持剂","italic":false,"color":"light_purple"}]', Lore: ['["",{"text":"8秒的无敌，即使被打成破布也能继续行动。","italic":false,"color":"white"}]', '["",{"text":"那么，代价是什么呢？","italic":false,"color":"dark_red"}]'] }, HideFlags: 32 }
            }
        }
    },
    重型防弹衣: {
        index: "重型防弹衣",
        icon: 'combatgear:gign_chestplate',
        iconNbt: {
            display: {
                Name: '["",{"text":"重型防弹衣","color":"gray","italic":false}]',
                Lore: ['{"text":"因为部署顺序问题，请确保在选择完护甲之后才选择该道具，否则会吞物品。","color":"dark_red","italic":"false"}'],
            },
            Enchantments: [{ lvl: 5, id: 'blast_protection' }], AttributeModifiers: [{ AttributeName: "generic.armor", Amount: 10, Slot: 'chest', UUID: randomUUID(), Name: 1725382139797 }, { AttributeName: "generic.armor_toughness", Amount: 8, Slot: 'chest', UUID: randomUUID(), Name: 1725382139797 }, { AttributeName: "generic.movement_speed", Amount: -0.02, Slot: 'chest', UUID: randomUUID(), Name: 1725382139797 }], Unbreakable: true
        },
        location: {
            x: 2,
            y: 3
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "single",
                id: 'combatgear:gign_chestplate',
                count: 1,
                armorSlot: 'chest',
                nbt: { display: { Name: '["",{"text":"重型防弹衣","italic":false}]' }, Enchantments: [{ lvl: 5, id: 'blast_protection' }], AttributeModifiers: [{ AttributeName: "generic.armor", Amount: 10, Slot: 'chest', UUID: randomUUID(), Name: 1725382139797 }, { AttributeName: "generic.armor_toughness", Amount: 8, Slot: 'chest', UUID: randomUUID(), Name: 1725382139797 }, { AttributeName: "generic.movement_speed", Amount: -0.02, Slot: 'chest', UUID: randomUUID(), Name: 1725382139797 }], Unbreakable: true },
            }
        }
    },
    肾上腺素: {
        index: "肾上腺素",
        icon: 'minecraft:potion',
        iconNbt: { CustomPotionColor: 8444959, CustomPotionEffects: [{ Id: 1, Duration: 1200, Amplifier: 0, ShowParticles: false }, { Id: 11, Duration: 1200, Amplifier: 0 }, { Id: 10, Duration: 600, Amplifier: 0 }, { Id: 23, Duration: 1, Amplifier: 9 }], display: { Name: '["",{"text":"肾上腺素","italic":false,"color":"aqua"}]', Lore: ['["",{"text":"生命回复速度：","italic":false,"color":"white"},{"text":"0.4/秒","italic":false,"color":"green"}]', '["",{"text":"立刻恢复所有饥饿值","italic":false,"color":"light_purple"}]', '["",{"text":"验血结果出来了，子弹里没一滴血","italic":false,"color":"aqua"}]'] } },
        location: {
            x: 3,
            y: 2
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "single",
                id: 'minecraft:potion',
                count: 2,
                nbt: { CustomPotionColor: 8444959, CustomPotionEffects: [{ Id: 1, Duration: 1200, Amplifier: 0, ShowParticles: false }, { Id: 11, Duration: 1200, Amplifier: 0 }, { Id: 10, Duration: 600, Amplifier: 0 }, { Id: 23, Duration: 1, Amplifier: 9 }], display: { Name: '["",{"text":"肾上腺素","italic":false,"color":"aqua"}]', Lore: ['["",{"text":"生命回复速度：","italic":false,"color":"white"},{"text":"0.4/秒","italic":false,"color":"green"}]', '["",{"text":"立刻恢复所有饥饿值","italic":false,"color":"light_purple"}]', '["",{"text":"验血结果出来了，子弹里没一滴血","italic":false,"color":"aqua"}]'] } }
            }
        }
    },
    兴奋剂: {
        index: "兴奋剂",
        icon: 'minecraft:potion',
        iconNbt: { CustomPotionColor: 3847130, CustomPotionEffects: [{ Id: 1, Duration: 6000, Amplifier: 1, ShowParticles: false }, { Id: 8, Duration: 6000, Amplifier: 0, ShowParticles: false }], display: { Name: '["",{"text":"兴奋剂","italic":false,"color":"green"}]' } },
        location: {
            x: 3,
            y: 3
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "single",
                id: 'minecraft:potion',
                count: 2,
                nbt: { CustomPotionColor: 3847130, CustomPotionEffects: [{ Id: 1, Duration: 6000, Amplifier: 1, ShowParticles: false }, { Id: 8, Duration: 6000, Amplifier: 0, ShowParticles: false }], display: { Name: '["",{"text":"兴奋剂","italic":false,"color":"blue"}]' } }
            }
        }
    },
    动态侦测器: {
        index: "动态侦测器",
        icon: 'pig_spawn_egg',
        iconNbt: { display: { Name: '[{"text":"动态侦测器 Blue","italic":false,"color":"blue"}]', Lore: ['[{"text":"使30格内的敌方单位显形，并使其获得挖掘疲劳。","italic":false,"color":"white"}]', '[{"text":"侦测器具有","italic":false,"color":"white"},{"text":"16点","color":"yellow"},{"text":"生命，"},{"text":"在被击杀前持续生效。","color":"green"}]'] } },
        location: {
            x: 4,
            y: 2
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "single",
                id: 'pig_spawn_egg',
                count: 2,
                nbt: {
                    EntityTag: {
                        id: 'slime', Size: 0, CustomName: '[{"text":"动态侦测器","color":"blue"}]', CustomNameVisible: true, Glowing: true, Health: 16, NoGravity: true, Team: 'WE',
                        Attributes: [
                            { Name: "generic.max_health", Base: 16 },
                            { Name: "generic.knockback_resistance", Base: 1 },
                            { Name: "generic.movement_speed", Base: -1 }
                        ]
                    },
                    display: {
                        Name: '[{"text":"动态侦测器 Blue","italic":false,"color":"blue"}]',
                        Lore: ['[{"text":"使30格内的敌方单位显形，并使其获得挖掘疲劳。","italic":false,"color":"white"}]', '[{"text":"侦测器具有","italic":false,"color":"white"},{"text":"16点","color":"yellow"},{"text":"生命，"},{"text":"在被击杀前持续生效。","color":"green"}]']
                    }
                }
            }
        }
    },
    信号弹: {
        index: "信号弹",
        icon: 'vex_spawn_egg',
        iconNbt: { display: { Name: '[{"text":"信号弹 Blue","italic":false,"color":"blue"}]', Lore: ['[{"text":"标记周围","italic":false,"color":"white"},{"text":"40格","color":"dark_green"},{"text":"内的敌人，并使其获得挖掘疲劳，持续"},{"text":"30秒","color":"dark_green"}]'] } },
        location: {
            x: 4,
            y: 3
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "single",
                id: 'vex_spawn_egg',
                count: 4,
                nbt: { EntityTag: { id: 'armor_stand', ShowArms: true, Invisible: true, CustomName: '[{"text":"Illume"}]', Team: 'WE' }, display: { Name: '[{"text":"信号弹 Blue","italic":false,"color":"blue"}]', Lore: ['[{"text":"标记周围","italic":false,"color":"white"},{"text":"40格","color":"dark_green"},{"text":"内的敌人，并使其获得挖掘疲劳，持续"},{"text":"30秒","color":"dark_green"}]'] } }
            }
        }
    },
    便携医疗站: {
        index: "急救站",
        icon: 'sheep_spawn_egg',
        iconNbt: {
            display: {
                Name: '[{"text":"便携医疗站","italic":false,"color":"green"}]',
                Lore: ['[{"text":"为周围","italic":false,"color":"white"},{"text":"5格","color":"yellow"},{"text":"内的玩家提供"},{"text":"生命恢复I（0.4HP/S）、恢复饱食度","color":"green"},{"text":"效果，并能拉起附近倒地玩家。"},{"text":"","color":"dark_purple"}]', '[{"text":"医疗站具有","italic":false,"color":"white"},{"text":"20点","color":"green"},{"text":"生命，在被击杀前持续生效。"},{"text":"","color":"dark_purple"}]', '[{"text":"可以通过丢出物品的方式部署。","italic":false,"color":"gold"},{"text":"","italic":false,"color":"dark_purple"}]', '[{"text":"敌人也能用。","italic":false,"color":"gray"}]']
            }
        },
        location: {
            x: 5,
            y: 2
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "single",
                id: 'sheep_spawn_egg',
                count: 2,
                nbt: {
                    EntityTag:
                    {
                        id: 'villager', VillagerData: { type: 'plains', profession: 'cleric', level: 5 },

                        ActiveEffects: [{ Id: 20, Duration: 72000, ShowParticles: false }],
                        CustomName: '[{"text":"便携医疗站","color":"green"}]', CustomNameVisible: true, Silent: true, Team: 'HP', ArmorItems: [{}, {}, {}, { id: 'white_banner', tag: { BlockEntityTag: { Patterns: [{ Pattern: 'sc', Color: 5 }] } }, Count: 1 }], Attributes: [{ Name: "generic.knockback_resistance", Base: 1 }, { Name: "generic.movement_speed", Base: -1 }], ArmorDropChances: [0, 0, 0, 0]
                    },
                    display: { Name: '[{"text":"便携医疗站","italic":false,"color":"green"}]', Lore: ['[{"text":"为周围","italic":false,"color":"white"},{"text":"5格","color":"yellow"},{"text":"内的玩家提供"},{"text":"生命恢复I（0.4HP/S）、恢复饱食度","color":"green"},{"text":"效果，并能拉起附近倒地玩家。"},{"text":"","color":"dark_purple"}]', '[{"text":"医疗站具有","italic":false,"color":"white"},{"text":"20点","color":"green"},{"text":"生命，在被击杀前持续生效。"},{"text":"","color":"dark_purple"}]', '[{"text":"可以通过丢出物品的方式部署。","italic":false,"color":"gold"},{"text":"","italic":false,"color":"dark_purple"}]', '[{"text":"敌人也能用。","italic":false,"color":"gray"}]'] }
                }
            }
        }
    },
    急救套件: {
        index: "急救套件",
        icon: 'combatgear:stimpack',
        iconNbt: {
            display: {
                Name: '["",{"text":"急救套件","color":"green","italic":false}]'
            },
        },
        location: {
            x: 5,
            y: 3
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                potion: {
                    id: 'minecraft:splash_potion',
                    count: 2,
                    nbt: { CustomPotionColor: 11546150, CustomPotionEffects: [{ Id: 10, Duration: 40, Amplifier: 5 }, { Id: 20, Duration: 200, Amplifier: 0 }, { Id: 15, Duration: 40, Amplifier: 0 }], display: { Name: '["",{"text":"紧急除颤","italic":false,"color":"dark_red"}]', Lore: ['["",{"text":"可以立即救起倒地的玩家并恢复所有生命","italic":false,"color":"green"}]', '[{"text":"有一点微不足道的副作用","italic":false,"color":"blue"}]'] } }
                },
                stim: {
                    id: 'combatgear:stimpack',
                    count: 2,
                    nbt: { display: { Name: '["",{"text":"急救针","italic":false,"color":"yellow"}]', Lore: ['["",{"text":"翻译：","italic":false,"color":"aqua"},{"text":"倒地时将其丢出，6秒后拉起自己。","italic":false,"color":"white"}]'] } }
                },
            }
        }
    },
    钩爪: {
        index: "钩爪",
        icon: 'fishing_rod',
        iconNbt: {
            display: {
                Name: '[{"text":"钩爪","italic":false,"color":"gold"}]',
                Lore: ['[{"text":"点击抛出和收回，收回时如果钩住方块，将玩家较大力拉向钩爪位置，并消耗大量耐久；钩爪在空中时收回则较小力拉动玩家，消耗少量耐久。","italic":false,"color":"white"},{"text":"","italic":false,"color":"dark_purple"}]', '[{"text":"男人！什么罐头我说，曼巴出去。","italic":false,"color":"gray"}]']
            }
        },
        location: {
            x: 6,
            y: 2
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",

                hook: {
                    id: 'minecraft:fishing_rod',
                    count: 1,
                    nbt: {
                        display: {
                            Name: '[{"text":"钩爪","italic":false,"color":"gold"}]',
                            Lore: ['[{"text":"点击抛出和收回，收回时如果钩住方块，将玩家较大力拉向钩爪位置，并消耗大量耐久；钩爪在空中时收回则较小力拉动玩家，消耗少量耐久。","italic":false,"color":"white"},{"text":"","italic":false,"color":"dark_purple"}]', '[{"text":"男人！什么罐头我说，曼巴出去。","italic":false,"color":"gray"}]']
                        }
                    }
                },

            }
        }
    },
    弹道雷达: {
        index: "弹道雷达",
        icon: 'compass',
        iconNbt: {
            display: {
                Name: '["",{"text":"弹道雷达","color":"green","italic":false}]',
                Lore: ['{"text":"在受到伤害时高亮攻击者4秒。","color":"aqua","italic":"false"}'],
            },
        },
        location: {
            x: 6,
            y: 3
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "command",
                commands: ["tag @s add Radar", "effect give @s minecraft:luck infinite 0 false", `tellraw @s ["",{"text":"弹道雷达已激活！","color":"dark_green"}]`]
            }
        }
    },
    反触发炸弹: {
        index: "反触发炸弹",
        icon: 'tnt_minecart',
        iconNbt: {
            display: {
                Name: '["",{"text":"反触发炸弹","color":"red","italic":false}]',
                Lore: ['{"text":"玩家死亡后1.5秒自爆。","color":"gray","italic":"false"}'],
            },
        },
        location: {
            x: 7,
            y: 2
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "command",
                commands: ["tag @s add Explode", "effect give @s minecraft:unluck infinite 0 false", `tellraw @s ["",{"text":"反触发炸弹已激活！","color":"dark_green"}]`]
            }
        }
    },
    /*
    test1: {
        index: "test1",
        icon: 'minecraft:grass_block',
        iconNbt: {

        },
        location: {
            x: 8,
            y: 3
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "single",
                id: 'minecraft:egg',
                count: 1,
                nbt: {

                }
            }
        }
    },
    test1: {
        index: "test1",
        icon: 'minecraft:grass_block',
        iconNbt: {

        },
        location: {
            x: 8,
            y: 3
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "single",
                id: 'minecraft:egg',
                count: 1,
                nbt: {

                }
            }
        }
    },
    test1: {
        index: "test1",
        icon: 'minecraft:grass_block',
        iconNbt: {

        },
        location: {
            x: 8,
            y: 3
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "single",
                id: 'minecraft:egg',
                count: 1,
                nbt: {

                }
            }
        }
    },
    test1: {
        index: "test1",
        icon: 'minecraft:grass_block',
        iconNbt: {

        },
        location: {
            x: 8,
            y: 3
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "single",
                id: 'minecraft:egg',
                count: 1,
                nbt: {

                }
            }
        }
    },
    */
}