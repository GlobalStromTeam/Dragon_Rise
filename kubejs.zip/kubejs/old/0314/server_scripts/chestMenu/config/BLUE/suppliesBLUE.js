const suppliesBLUE = {
    description: {
        index: "suppliesBLUE",
        type: "conductSelect",
        maxSelect: 1,
        title: Text.black('『物资菜单』'),
        leftButton: {
            icon: 'createdeco:decal_left',
            iconNbt: {
                display: {
                    Name: '{"text":"返回","color":"gold","italic":"false"}',
                    Lore: ['{"text":"回到上一界面","color":"white","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "changeMenu",
                get nextMenu() {
                    return menuItemsBLUE
                }
            }
        },
        leftTopButton: {
            icon: 'createdeco:decal_warning',
            iconNbt: {
                display: {
                    Name: '{"text":"重置","color":"red","italic":"false"}',
                    Lore: ['{"text":"重置当前页面下的选择","color":"white","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "reset"
            },
        }
    },

    normal: {
        index: "normal",
        icon: 'minecraft:cooked_beef',
        iconNbt: {
            display: {
                Name: '["",{"text":"后勤分队","italic":false,"color":"gray"}]',
                Lore: ['["",{"text":"干粮、防弹插板、占领信标，样样俱到","italic":false,"color":"gold"}]']
            }
        },
        location: {
            x: 1,
            y: 2
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                food: {
                    id: 'minecraft:cooked_beef',
                    count: 4,
                    nbt: {
                        display: {
                            Name: '["",{"text":"干粮","italic":false,"color":"yellow"}]',
                            Lore: ['["",{"text":"最普遍的食物","italic":false,"color":"white"}]']
                        }
                    }
                },
                bulletProof: {
                    id: 'create:sturdy_sheet',
                    count: 2,
                    nbt: {
                        BulletproofCount: 6,
                        display: {
                            Name: '["",{"text":"防弹插板","italic":false,"color":"gray"}]',
                            Lore: ['["",{"text":"插板护甲：6.0","italic":false,"color":"aqua"}]', '["",{"text":"插板上限为3个，使用时优先覆盖剩余护甲最低的插板。","italic":false,"color":"dark_aqua"}]']
                        }
                    }
                },
                beaconBLUE: {
                    id: 'minecraft:chicken_spawn_egg',
                    count: 1,
                    nbt: { EntityTag: { id: 'armor_stand', ShowArms: true, CustomName: '[{"text":"占领信标","color":"blue"}]', CustomNameVisible: true, Glowing: true, Team: 'WE', ArmorItems: [{ id: 'leather_boots', Count: 1 }, { id: 'leather_leggings', Count: 1 }, { id: 'leather_chestplate', Count: 1 }, { id: 'leather_helmet', Count: 1 }], ArmorDropChances: [0, 0, 0, 0] }, display: { Name: '[{"text":"占领信标 Blue","italic":false,"color":"blue"}]' } }
                },
                point: {
                    id: 'minecraft:nether_star',
                    count: 8,
                    nbt: { display: { Name: '["",{"text":"物资点","italic":false,"color":"gold"}]', Lore: ['["",{"text":"可以使用","italic":false,"color":"white"},{"text":"物资点","italic":false,"color":"gold"},{"text":"在目标点的补给站村民处补充弹药、食物等资源。","italic":false,"color":"white"}]'] } }
                },
            }
        }
    },
    support: {
        index: "support",
        icon: 'minecraft:beacon',
        iconNbt: {
            display: {
                Name: '["",{"text":"支援分队","italic":false,"color":"aqua"}]',
                Lore: ['["",{"text":"减少插板以携带一个支援信标。","italic":false,"color":"gold"},{"text":"支援信标同时只能存在一个！","italic":false,"color":"dark_red"}]']
            }
        },
        location: {
            x: 2,
            y: 2
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                food: {
                    id: 'minecraft:cooked_beef',
                    count: 4,
                    nbt: {
                        display: {
                            Name: '["",{"text":"干粮","italic":false,"color":"yellow"}]',
                            Lore: ['["",{"text":"最普遍的食物","italic":false,"color":"white"}]']
                        }
                    }
                },
                bulletProof: {
                    id: 'create:sturdy_sheet',
                    count: 2,
                    nbt: {
                        BulletproofCount: 6,
                        display: {
                            Name: '["",{"text":"防弹插板","italic":false,"color":"gray"}]',
                            Lore: ['["",{"text":"插板护甲：6.0","italic":false,"color":"aqua"}]', '["",{"text":"插板上限为3个，使用时优先覆盖剩余护甲最低的插板。","italic":false,"color":"dark_aqua"}]']
                        }
                    }
                },
                supportBeaconBLUE: {
                    id: 'minecraft:warden_spawn_egg',
                    count: 1,
                    nbt: {
                        EntityTag: {
                            id: 'armor_stand',
                            ShowArms: true,
                            CustomName: '[{"text":"支援信标","color":"blue"}]',
                            CustomNameVisible: true, Team: 'WE',
                            ArmorItems: [{}, {}, {}, { id: 'blue_concrete', Count: 1 }],
                            ArmorDropChances: [0, 0, 0, 0]
                        },
                        display: {
                            Name: '[{"text":"支援信标 Blue","italic":false,"color":"blue"}]',
                            Lore: ['[{"text":"己方成员可以选择复活在支援信标处。","italic":false,"color":"green"},{"text":"","italic":false,"color":"dark_purple"}]', '[{"text":"同时只能存在一个支援信标。","italic":false,"color":"gold"},{"text":"","italic":false,"color":"dark_purple"}]', '[{"text":"当场上已存在支援信标时，新放置的信标将被","italic":false,"color":"dark_aqua"},{"text":"自动清除。","color":"red"},{"text":"如果以某些方式产生多个信标，玩家将会"},{"text":"随机","color":"red"},{"text":"复活到已存在的信标之一。"}]']
                        }
                    }
                },
                point: {
                    id: 'minecraft:nether_star',
                    count: 4,
                    nbt: { display: { Name: '["",{"text":"物资点","italic":false,"color":"gold"}]', Lore: ['["",{"text":"可以使用","italic":false,"color":"white"},{"text":"物资点","italic":false,"color":"gold"},{"text":"在目标点的补给站村民处补充弹药、食物等资源。","italic":false,"color":"white"}]'] } }
                },
            }
        }
    },
    artillery: {
        index: "artillery",
        icon: 'createbigcannons:he_shell',
        iconNbt: {
            display: {
                Name: '["",{"text":"炮击分队","italic":false,"color":"aqua"}]',
                Lore: ['["",{"text":"能够呼叫一次火炮支援。","italic":false,"color":"gold"}]','["",{"text":"小心友伤","italic":false,"color":"gray"}]']
            }
        },
        location: {
            x: 3,
            y: 2
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                food: {
                    id: 'minecraft:cooked_beef',
                    count: 4,
                    nbt: {
                        display: {
                            Name: '["",{"text":"干粮","italic":false,"color":"yellow"}]',
                            Lore: ['["",{"text":"最普遍的食物","italic":false,"color":"white"}]']
                        }
                    }
                },
                bulletProof: {
                    id: 'create:sturdy_sheet',
                    count: 1,
                    nbt: {
                        BulletproofCount: 6,
                        display: {
                            Name: '["",{"text":"防弹插板","italic":false,"color":"gray"}]',
                            Lore: ['["",{"text":"插板护甲：6.0","italic":false,"color":"aqua"}]', '["",{"text":"插板上限为3个，使用时优先覆盖剩余护甲最低的插板。","italic":false,"color":"dark_aqua"}]']
                        }
                    }
                },
                ArtilleryStrike: {
                    id: 'heart_of_the_sea',
                    count: 1,
                    nbt: {
                        display: {
                            Name: '[{"text":"高爆弹火力网","italic":false,"color":"red"}]'
                        },
                        strikeType: 'Cannon',
                        strikeData: {
                            height: 500,
                            radius: 50,
                            fireLag: 160,
                            fireRounds: 10,
                            fireRoundInterval: 50,
                            firePerRound: 3,
                            fireInterval: 20,
                            projSpeed: 8,
                            beamColor: [1, 0.24, 0.24],
                            strikeProj: {
                                id: 'createbigcannons:he_shell',
                                nbt: {
                                    BlockEntityTag: {
                                        Fuze: { Count: true, id: "createbigcannons:proximity_fuze", tag: { DetonationDistance: 1 } },
                                        Tracer: { Count: true, id: "createbigcannons:tracer_tip" },
                                        id: "createbigcannons:fuzed_block"
                                    }
                                }
                            }
                        }
                    }
                },
                point: {
                    id: 'minecraft:nether_star',
                    count: 4,
                    nbt: { display: { Name: '["",{"text":"物资点","italic":false,"color":"gold"}]', Lore: ['["",{"text":"可以使用","italic":false,"color":"white"},{"text":"物资点","italic":false,"color":"gold"},{"text":"在目标点的补给站村民处补充弹药、食物等资源。","italic":false,"color":"white"}]'] } }
                },
            }
        }
    },
    cluster: {
        index: "cluster",
        icon: 'createbigcannons:he_shell',
        iconNbt: {
            display: {
                Name: '["",{"text":"轰炸分队","italic":false,"color":"aqua"}]',
                Lore: ['["",{"text":"能够呼叫一次集束炸弹轰炸。","italic":false,"color":"gold"}]','["",{"text":"务必小心友伤","italic":false,"color":"gray"}]']
            }
        },
        location: {
            x: 4,
            y: 2
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                food: {
                    id: 'minecraft:cooked_beef',
                    count: 4,
                    nbt: {
                        display: {
                            Name: '["",{"text":"干粮","italic":false,"color":"yellow"}]',
                            Lore: ['["",{"text":"最普遍的食物","italic":false,"color":"white"}]']
                        }
                    }
                },
                bulletProof: {
                    id: 'create:sturdy_sheet',
                    count: 1,
                    nbt: {
                        BulletproofCount: 6,
                        display: {
                            Name: '["",{"text":"防弹插板","italic":false,"color":"gray"}]',
                            Lore: ['["",{"text":"插板护甲：6.0","italic":false,"color":"aqua"}]', '["",{"text":"插板上限为3个，使用时优先覆盖剩余护甲最低的插板。","italic":false,"color":"dark_aqua"}]']
                        }
                    }
                },
                clusterStrike: {
                    id: 'heart_of_the_sea',
                    count: 1,
                    nbt: {
                        display: {
                            Name: '[{"text":"集束炸弹","italic":false,"color":"red"}]'
                        },
                        strikeType: 'Missile',
                        strikeData: {
                            height: 150,
                            vertical: 150,
                            radius: 40,
                            warnRadius: 55,
                            seekMode: 'none',
                            fireLag: 100,
                            firePerRound: 12,
                            fireInterval: 2,
                            projSpeed: 8,
                            beamColor: [1, 0.24, 0.24],
                            strikeProj: {
                                id: 'createbigcannons:ap_shot',
                                nbt: {
                                    BlockEntityTag: {
                                        //Fuze: { Count: true, id: "createbigcannons:proximity_fuze", tag: { DetonationDistance: 1 } },
                                        Tracer: { Count: true, id: "createbigcannons:tracer_tip" },
                                        id: "createbigcannons:fuzed_block"
                                    }
                                },
                                clusterData: {
                                    count: 16,
                                    radius: 6,
                                    explosionPower: 3,
                                    speed: 1,
                                    random: true
                                }
                            }
                        }
                    }
                },
                point: {
                    id: 'minecraft:nether_star',
                    count: 4,
                    nbt: { display: { Name: '["",{"text":"物资点","italic":false,"color":"gold"}]', Lore: ['["",{"text":"可以使用","italic":false,"color":"white"},{"text":"物资点","italic":false,"color":"gold"},{"text":"在目标点的补给站村民处补充弹药、食物等资源。","italic":false,"color":"white"}]'] } }
                },
            }
        }
    },
    /* supplyStation: {
        index: "supplyStation",
        icon: 'minecraft:emerald',
        iconNbt: {
            display: {
                Name: '["",{"text":"补给站物资","italic":false,"color":"green"}]',
                Lore: ['["",{"text":"随身携带一个使用物资点的补给站。","italic":false,"color":"gold"},{"text":"补给站可以被破坏！","italic":false,"color":"dark_red"}]']
            }
        },
        location: {
            x: 3,
            y: 2
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                food: {
                    id: 'minecraft:cooked_beef',
                    count: 4,
                    nbt: {
                        display: {
                            Name: '["",{"text":"干粮","italic":false,"color":"yellow"}]',
                            Lore: ['["",{"text":"最普遍的食物","italic":false,"color":"white"}]']
                        }
                    }
                },
                bulletProof: {
                    id: 'create:sturdy_sheet',
                    count: 2,
                    nbt: {
                        BulletproofCount: 6,
                        display: {
                            Name: '["",{"text":"防弹插板","italic":false,"color":"gray"}]',
                            Lore: ['["",{"text":"插板护甲：6.0","italic":false,"color":"aqua"}]', '["",{"text":"插板上限为3个，使用时优先覆盖剩余护甲最低的插板。","italic":false,"color":"dark_aqua"}]']
                        }
                    }
                },
                point: {
                    id: 'minecraft:nether_star',
                    count: 16,
                    nbt: { display: { Name: '["",{"text":"物资点","italic":false,"color":"gold"}]', Lore: ['["",{"text":"可以使用","italic":false,"color":"white"},{"text":"物资点","italic":false,"color":"gold"},{"text":"在目标点的补给站村民处补充弹药、食物等资源。","italic":false,"color":"white"}]'] } }
                },
                station: {
                    id: 'minecraft:villager_spawn_egg',
                    count: 1,
                    nbt: {
                        EntityTag: {
                            id: 'villager',
                            VillagerData: { type: 'plains', profession: 'cleric', level: 5 },
                            Offers: {
                                Recipes: [
                                    {
                                        maxUses: 1024, rewardExp: false, priceMultiplier: 0,
                                        buy: { id: 'nether_star', tag: { display: { Name: '["",{"text":"物资点","italic":false,"color":"gold"}]', Lore: ['["",{"text":"可以使用","italic":false,"color":"white"},{"text":"物资点","italic":false,"color":"gold"},{"text":"在目标点的补给站村民处补充弹药、食物等资源。","italic":false,"color":"white"}]'] } }, Count: 1 },
                                        sell: { id: 'tacz:ammo', Count: 30, tag: { AmmoId: "tacz:556x45" } }
                                    },
                                    {
                                        maxUses: 1024, rewardExp: false, priceMultiplier: 0,
                                        buy: { id: 'nether_star', tag: { display: { Name: '["",{"text":"物资点","italic":false,"color":"gold"}]', Lore: ['["",{"text":"可以使用","italic":false,"color":"white"},{"text":"物资点","italic":false,"color":"gold"},{"text":"在目标点的补给站村民处补充弹药、食物等资源。","italic":false,"color":"white"}]'] } }, Count: 1 },
                                        sell: { id: 'tacz:ammo', Count: 30, tag: { AmmoId: "tacz:58x42" } }
                                    },
                                    {
                                        maxUses: 1024, rewardExp: false, priceMultiplier: 0,
                                        buy: { id: 'nether_star', tag: { display: { Name: '["",{"text":"物资点","italic":false,"color":"gold"}]', Lore: ['["",{"text":"可以使用","italic":false,"color":"white"},{"text":"物资点","italic":false,"color":"gold"},{"text":"在目标点的补给站村民处补充弹药、食物等资源。","italic":false,"color":"white"}]'] } }, Count: 1 },
                                        sell: { id: 'tacz:ammo', Count: 30, tag: { AmmoId: "cib:545x39" } }
                                    },
                                    {
                                        maxUses: 1024, rewardExp: false, priceMultiplier: 0,
                                        buy: { id: 'nether_star', tag: { display: { Name: '["",{"text":"物资点","italic":false,"color":"gold"}]', Lore: ['["",{"text":"可以使用","italic":false,"color":"white"},{"text":"物资点","italic":false,"color":"gold"},{"text":"在目标点的补给站村民处补充弹药、食物等资源。","italic":false,"color":"white"}]'] } }, Count: 1 },
                                        sell: { id: 'tacz:ammo', Count: 20, tag: { AmmoId: "tacz:308" } }
                                    },
                                    {
                                        maxUses: 1024, rewardExp: false, priceMultiplier: 0,
                                        buy: { id: 'nether_star', tag: { display: { Name: '["",{"text":"物资点","italic":false,"color":"gold"}]', Lore: ['["",{"text":"可以使用","italic":false,"color":"white"},{"text":"物资点","italic":false,"color":"gold"},{"text":"在目标点的补给站村民处补充弹药、食物等资源。","italic":false,"color":"white"}]'] } }, Count: 1 },
                                        sell: { id: 'tacz:ammo', Count: 30, tag: { AmmoId: "tacz:762x54" } }
                                    },
                                    {
                                        maxUses: 1024, rewardExp: false, priceMultiplier: 0,
                                        buy: { id: 'nether_star', tag: { display: { Name: '["",{"text":"物资点","italic":false,"color":"gold"}]', Lore: ['["",{"text":"可以使用","italic":false,"color":"white"},{"text":"物资点","italic":false,"color":"gold"},{"text":"在目标点的补给站村民处补充弹药、食物等资源。","italic":false,"color":"white"}]'] } }, Count: 1 },
                                        sell: { id: 'tacz:ammo', Count: 45, tag: { AmmoId: "tacz:9mm" } }
                                    },
                                    {
                                        maxUses: 1024, rewardExp: false, priceMultiplier: 0,
                                        buy: { id: 'nether_star', tag: { display: { Name: '["",{"text":"物资点","italic":false,"color":"gold"}]', Lore: ['["",{"text":"可以使用","italic":false,"color":"white"},{"text":"物资点","italic":false,"color":"gold"},{"text":"在目标点的补给站村民处补充弹药、食物等资源。","italic":false,"color":"white"}]'] } }, Count: 1 },
                                        sell: { id: 'tacz:ammo', Count: 16, tag: { AmmoId: "tacz:12g" } }
                                    },
                                    {
                                        maxUses: 1024, rewardExp: false, priceMultiplier: 0,
                                        buy: { id: 'nether_star', tag: { display: { Name: '["",{"text":"物资点","italic":false,"color":"gold"}]', Lore: ['["",{"text":"可以使用","italic":false,"color":"white"},{"text":"物资点","italic":false,"color":"gold"},{"text":"在目标点的补给站村民处补充弹药、食物等资源。","italic":false,"color":"white"}]'] } }, Count: 1 },
                                        sell: { id: 'tacz:ammo', Count: 16, tag: { AmmoId: "classicr:410_bore" } }
                                    },
                                    {
                                        maxUses: 1024, rewardExp: false, priceMultiplier: 0,
                                        buy: { id: 'nether_star', tag: { display: { Name: '["",{"text":"物资点","italic":false,"color":"gold"}]', Lore: ['["",{"text":"可以使用","italic":false,"color":"white"},{"text":"物资点","italic":false,"color":"gold"},{"text":"在目标点的补给站村民处补充弹药、食物等资源。","italic":false,"color":"white"}]'] } }, Count: 1 },
                                        sell: { id: 'tacz:ammo', Count: 15, tag: { AmmoId: "tacz:50bmg" } }
                                    },
                                    {
                                        maxUses: 1024, rewardExp: false, priceMultiplier: 0,
                                        buy: { id: 'nether_star', tag: { display: { Name: '["",{"text":"物资点","italic":false,"color":"gold"}]', Lore: ['["",{"text":"可以使用","italic":false,"color":"white"},{"text":"物资点","italic":false,"color":"gold"},{"text":"在目标点的补给站村民处补充弹药、食物等资源。","italic":false,"color":"white"}]'] } }, Count: 6 },
                                        sell: { id: "pointblank:javelin_rocket", Count: 3 }
                                    }, {
                                        maxUses: 1024, rewardExp: false, priceMultiplier: 0,
                                        buy: { id: 'nether_star', tag: { display: { Name: '["",{"text":"物资点","italic":false,"color":"gold"}]', Lore: ['["",{"text":"可以使用","italic":false,"color":"white"},{"text":"物资点","italic":false,"color":"gold"},{"text":"在目标点的补给站村民处补充弹药、食物等资源。","italic":false,"color":"white"}]'] } }, Count: 6 },
                                        sell: { id: "pointblank:grenade40mm", Count: 12 }
                                    }, {
                                        maxUses: 1024, rewardExp: false, priceMultiplier: 0,
                                        buy: { id: 'nether_star', tag: { display: { Name: '["",{"text":"物资点","italic":false,"color":"gold"}]', Lore: ['["",{"text":"可以使用","italic":false,"color":"white"},{"text":"物资点","italic":false,"color":"gold"},{"text":"在目标点的补给站村民处补充弹药、食物等资源。","italic":false,"color":"white"}]'] } }, Count: 1 },
                                        sell: { id: 'cooked_beef', Count: 4 }
                                    }, {
                                        maxUses: 1024, rewardExp: false, priceMultiplier: 0,
                                        buy: { id: 'nether_star', tag: { display: { Name: '["",{"text":"物资点","italic":false,"color":"gold"}]', Lore: ['["",{"text":"可以使用","italic":false,"color":"white"},{"text":"物资点","italic":false,"color":"gold"},{"text":"在目标点的补给站村民处补充弹药、食物等资源。","italic":false,"color":"white"}]'] } }, Count: 1 },
                                        sell: { id: 'create:sturdy_sheet', tag: { BulletproofCount: 6, display: { Name: '["",{"text":"防弹插板","italic":false,"color":"gray"}]', Lore: ['["",{"text":"插板护甲：6.0","italic":false,"color":"aqua"}]','["",{"text":"插板上限为3个，使用时优先覆盖剩余护甲最低的插板。","italic":false,"color":"dark_aqua"}]'] } }, Count: 1 }
                                    }, {
                                        maxUses: 1024, rewardExp: false, priceMultiplier: 0,
                                        buy: { id: 'nether_star', tag: { display: { Name: '["",{"text":"物资点","italic":false,"color":"gold"}]', Lore: ['["",{"text":"可以使用","italic":false,"color":"white"},{"text":"物资点","italic":false,"color":"gold"},{"text":"在目标点的补给站村民处补充弹药、食物等资源。","italic":false,"color":"white"}]'] } }, Count: 1 },
                                        sell: { id: "cgm:grenade", Count: 2 }
                                    }, {
                                        maxUses: 1024, rewardExp: false, priceMultiplier: 0,
                                        buy: { id: 'nether_star', tag: { display: { Name: '["",{"text":"物资点","italic":false,"color":"gold"}]', Lore: ['["",{"text":"可以使用","italic":false,"color":"white"},{"text":"物资点","italic":false,"color":"gold"},{"text":"在目标点的补给站村民处补充弹药、食物等资源。","italic":false,"color":"white"}]'] } }, Count: 1 },
                                        sell: { id: "cgm:stun_grenade", Count: 2 }
                                    }]
                            }, CustomName: '[{"text":"补给站"}]', CustomNameVisible: true, NoAI: true, Silent: true, Invulnerable: true
                        }, display: { Name: '[{"text":"补给站","italic":false,"color":"gold"}]', Lore: ['[{"text":"可以使用","italic":false,"color":"white"},{"text":"物资点","color":"gold"},{"text":"在目标点的补给站村民处补充弹药、食物等资源，村民仅存在"},{"text":"60","color":"green"},{"text":"秒。"}]'] }
                    },

                }
            }
        }
    }, */


}
