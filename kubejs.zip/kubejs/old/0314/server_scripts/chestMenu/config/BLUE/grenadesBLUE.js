const grenadesBLUE = {
    description: {
        index: "grenadesBLUE",
        type: "conductSelect",
        maxSelect: 4,
        title: Text.black('『投掷物菜单』'),
        leftButton: {
            icon: 'createdeco:decal_left',
            iconNbt: {
                display: {
                    Name: '{"text":"返回","color":"gold","italic":"false"}',
                    Lore: ['{"text":"回到上一界面","color":"white","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "changeMenu",
                get nextMenu() {
                    return menuItemsBLUE
                }
            }
        },
        leftTopButton: {
            icon: 'createdeco:decal_warning',
            iconNbt: {
                display: {
                    Name: '{"text":"重置","color":"red","italic":"false"}',
                    Lore: ['{"text":"重置当前页面下的选择","color":"white","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "reset"
            },
        }
    },
    fragGrenade: {
        index: "fragGrenade",
        icon: 'cgm:grenade',
        iconNbt: {

        },
        location: {
            x: 1,
            y: 2
        },
        leftClickAction: {
            type: "multiSelect",
            items: {
                type: "single",
                id: 'cgm:grenade',
                count: 2,
                nbt: {
                }
            }
        }
    },
    fragGrenade2: {
        index: "fragGrenade2",
        icon: 'crusty_chunks:grenade',
        iconNbt: {

        },
        location: {
            x: 1,
            y: 3
        },
        leftClickAction: {
            type: "multiSelect",
            items: {
                type: "single",
                id: 'crusty_chunks:grenade',
                count: 1,
                nbt: {
                }
            }
        }
    },
    stunGrenade: {
        index: "stunGrenade",
        icon: 'cgm:stun_grenade',
        iconNbt: {

        },
        location: {
            x: 2,
            y: 2
        },
        leftClickAction: {
            type: "multiSelect",
            items: {
                type: "single",
                id: 'cgm:stun_grenade',
                count: 2,
                nbt: {
                }
            }
        }
    },
    smokeGrenade: {
        index: "smokeGrenade",
        icon: 'minecraft:lingering_potion',
        iconNbt: {
            CustomPotionColor: 16351261,
            display: {
                Name: '["",{"text":"烟雾弹","italic":false,"color":"gold"}]',
                Lore: ['["",{"text":"制造一片持续","italic":false,"color":"white"},{"text":"30s","italic":false,"color":"dark_green"},{"text":"的烟雾，可以通过进入烟雾中心","italic":false,"color":"white"},{"text":"强行","italic":false,"color":"dark_purple"},{"text":"踩灭。","italic":false,"color":"white"}]', '["",{"text":"中心很熏人，别乱踩。","italic":false,"color":"gray"}]']
            }
        },
        location: {
            x: 3,
            y: 2
        },
        leftClickAction: {
            type: "multiSelect",
            items: {
                type: "single",
                id: 'minecraft:lingering_potion',
                count: 1,
                nbt: {
                    CustomPotionColor: 16351261,
                    CustomPotionEffects: [
                        { Id: 9, Duration: 160, Amplifier: 0 },
                        { Id: 7, Duration: 1, Amplifier: 1 }
                    ],
                    display: {
                        Name: '["",{"text":"烟雾弹","italic":false,"color":"gold"}]',
                        Lore: ['["",{"text":"制造一片持续","italic":false,"color":"white"},{"text":"30s","italic":false,"color":"dark_green"},{"text":"的烟雾，可以通过进入烟雾中心","italic":false,"color":"white"},{"text":"强行","italic":false,"color":"dark_purple"},{"text":"踩灭。","italic":false,"color":"white"}]', '["",{"text":"中心很熏人，别乱踩。","italic":false,"color":"gray"}]']
                    }, HideFlags: 32
                }
            }
        }
    },
}