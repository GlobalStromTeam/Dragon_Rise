const subWeaponsBLUE = {
    description: {
        index: "subWeaponsBLUE",
        type: "conductSelect",
        maxSelect: 1,
        title: Text.black('『副武器菜单』'),
        leftButton: {
            icon: 'createdeco:decal_left',
            iconNbt: {
                display: {
                    Name: '{"text":"返回","color":"gold","italic":"false"}',
                    Lore: ['{"text":"回到上一界面","color":"white","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "changeMenu",
                get nextMenu() {
                    return menuItemsBLUE
                }
            }
        },
        leftTopButton: {
            icon: 'createdeco:decal_warning',
            iconNbt: {
                display: {
                    Name: '{"text":"重置","color":"red","italic":"false"}',
                    Lore: ['{"text":"重置当前页面下的选择","color":"white","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "reset"
            },
        }
    },
    伯莱塔686: {
        index: "伯莱塔686",
        icon: 'tacz:modern_kinetic_gun',
        iconNbt: {
            GunId: "cib:686"
        },
        location: {
            x: 1,
            y: 1
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                gunItem: {
                    id: 'tacz:modern_kinetic_gun',
                    count: 1,
                    nbt: {
                        HasBulletInBarrel: true,
                        GunFireMode: "SEMI",
                        GunId: "cib:686",
                        GunCurrentAmmoCount: Integer.parseInt('2')
                    }
                },
                ammos: {
                    id: 'tacz:ammo_box',
                    count: 1,
                    nbt: {
                        Level: Integer.parseInt('1'),
                        AmmoCount: Integer.parseInt('10'),
                        AmmoId: "tacz:12g"
                    }
                }

            }
        },
    },
    deagle: {
        index: "deagle",
        icon: 'tacz:modern_kinetic_gun',
        iconNbt: {
            GunId: "tacz:deagle"
        },
        location: {
            x: 3,
            y: 1
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                gunItem: {
                    id: 'tacz:modern_kinetic_gun',
                    count: 1,
                    nbt: {
                        HasBulletInBarrel: true,
                        GunFireMode: "SEMI",
                        GunId: "tacz:deagle",
                        GunCurrentAmmoCount: Integer.parseInt('7')
                    }
                },
                ammos: {
                    id: 'tacz:ammo_box',
                    count: 1,
                    nbt: {
                        Level: Integer.parseInt('1'),
                        AmmoCount: Integer.parseInt('80'),
                        AmmoId: "tacz:50ae"
                    }
                }

            }
        },
    },
    python: {
        index: "python",
        icon: 'tacz:modern_kinetic_gun',
        iconNbt: {
            GunId: "suffuse:python"
        },
        location: {
            x: 3,
            y: 2
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                gunItem: {
                    id: 'tacz:modern_kinetic_gun',
                    count: 1,
                    nbt: {
                        HasBulletInBarrel: true,
                        GunFireMode: "SEMI",
                        GunId: "suffuse:python",
                        GunCurrentAmmoCount: Integer.parseInt('6')
                    }
                },
                ammos: {
                    id: 'tacz:ammo_box',
                    count: 1,
                    nbt: {
                        Level: Integer.parseInt('1'),
                        AmmoCount: Integer.parseInt('30'),
                        AmmoId: "tacz:50ae"
                    }
                }

            }
        },
    },
    glock18: {
        index: "glock18",
        icon: 'tacz:modern_kinetic_gun',
        iconNbt: {
            GunId: "classicr:glock_18"
        },
        location: {
            x: 5,
            y: 1
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                gunItem: {
                    id: 'tacz:modern_kinetic_gun',
                    count: 1,
                    nbt: {
                        HasBulletInBarrel: true,
                        GunFireMode: "AUTO",
                        GunId: "classicr:glock_18",
                        GunCurrentAmmoCount: Integer.parseInt('17')
                    }
                },
                ammos: {
                    id: 'tacz:ammo_box',
                    count: 1,
                    nbt: {
                        Level: Integer.parseInt('1'),
                        AmmoCount: Integer.parseInt('90'),
                        AmmoId: "tacz:9mm"
                    }
                }

            }
        },
    },
    匕首: {
        index: "匕首",
        icon: 'combatgear:knife',
        iconNbt: { display: { Name: '["",{"text":"匕首","italic":false,"color":"blue"}]', Lore: ['["",{"text":"小小的也很可爱","italic":false,"color":"white"}]'] }, AttributeModifiers: [{ AttributeName: "generic.attack_damage", Amount: 24, Slot: 'mainhand', UUID: randomUUID(), Name: 1724234570197 }, { AttributeName: "generic.attack_speed", Amount: -2, Slot: 'mainhand', UUID: randomUUID(), Name: 1724234570197 }, { AttributeName: "generic.movement_speed", Amount: 0.025, Slot: 'mainhand', UUID: randomUUID(), Name: 1727409401370 }] },
        location: {
            x: 7,
            y: 1
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "single",
                id: 'combatgear:knife',
                count: 1,
                nbt: { display: { Name: '["",{"text":"匕首","italic":false,"color":"blue"}]', Lore: ['["",{"text":"小小的也很可爱","italic":false,"color":"white"}]'] }, AttributeModifiers: [{ AttributeName: "generic.attack_damage", Amount: 24, Slot: 'mainhand', UUID: randomUUID(), Name: 1724234570197 }, { AttributeName: "generic.attack_speed", Amount: -2, Slot: 'mainhand', UUID: randomUUID(), Name: 1724234570197 }, { AttributeName: "generic.movement_speed", Amount: 0.025, Slot: 'mainhand', UUID: randomUUID(), Name: 1727409401370 }] }
            }
        },
    },
    砍刀: {
        index: "砍刀",
        icon: 'combatgear:machete',
        iconNbt: { display: { Name: '["",{"text":"砍刀","italic":false,"color":"blue"}]', Lore: ['["",{"text":"大刀向鬼子们的头上砍去！","italic":false,"color":"dark_red"}]'] }, AttributeModifiers: [{ AttributeName: "generic.attack_damage", Amount: 40, Slot: 'mainhand', UUID: randomUUID(), Name: 1724234570197 }, { AttributeName: "generic.attack_speed", Amount: -3, Slot: 'mainhand', UUID: randomUUID(), Name: 1724234570197 }, { AttributeName: "generic.movement_speed", Amount: 0.015, Slot: 'mainhand', UUID: randomUUID(), Name: 1727409401370 }] },
        location: {
            x: 7,
            y: 2
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "single",
                id: 'combatgear:machete',
                count: 1,
                nbt: { display: { Name: '["",{"text":"砍刀","italic":false,"color":"blue"}]', Lore: ['["",{"text":"大刀向鬼子们的头上砍去！","italic":false,"color":"dark_red"}]'] }, AttributeModifiers: [{ AttributeName: "generic.attack_damage", Amount: 40, Slot: 'mainhand', UUID: randomUUID(), Name: 1724234570197 }, { AttributeName: "generic.attack_speed", Amount: -3, Slot: 'mainhand', UUID: randomUUID(), Name: 1724234570197 }, { AttributeName: "generic.movement_speed", Amount: 0.015, Slot: 'mainhand', UUID: randomUUID(), Name: 1727409401370 }] },
            }
        },
    },
    爆炸弩: {
        index: "爆炸弩",
        icon: 'crossbow',
        iconNbt: {
            display: { Name: '["",{"text":"爆炸弩","italic":false,"color":"gold"}]', Lore: ['["",{"text":"对直击目标造成70点伤害，并产生中等范围爆炸。","italic":false,"color":"white"}]', '["",{"text":"孩子们，我复活了","italic":false,"color":"gray"}]'] }
        },
        location: {
            x: 1,
            y: 3
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                gunItem: {
                    id: 'crossbow',
                    count: 1,
                    nbt: {
                        display: { Name: '["",{"text":"爆炸弩","italic":false,"color":"gold"}]', Lore: ['["",{"text":"对直击目标造成70点伤害，并产生中等范围爆炸。","italic":false,"color":"white"}]', '["",{"text":"孩子们，我复活了","italic":false,"color":"gray"}]'] }
                    }
                },
                ammos: {
                    id: 'xtraarrows:netherite_explosive_arrow',
                    count: 1,
                    nbt: {
                    }
                }

            }
        },
    },
}