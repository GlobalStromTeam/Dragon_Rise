
/*
格式：
const xxx={
    description: {
    //index和对象名相同，用来索引
        index:"xxx"
        name: "xxx",
        //type决定显示方式
        type: "showSelection",
        //title是菜单标题
        title: Text.black('『配装菜单』'),
        //左按钮
        leftButton: {
        //按钮的图标对应物
            icon: 'createdeco:decal_left',
            iconNbt: {
                display: {
                    Name: '{"text":"xxx","color":"gold","italic":"false"}',
                    Lore: ['{"text":"yyy","color":"white","italic":"false"}'],
                }
            },
            //点击物品的行为
            leftClickAction: {
            //type决定点击之后的结果
                type: "exit",
            }
        },
        rightButton: {
            icon: 'minecraft:diamond_sword',
            iconNbt: {
                display: {
                    Name: '{"text":"xxx","color":"gold","italic":"false"}',
                    Lore: ['{"text":"yyy","color":"white","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "deploy"
            },
        }
    },
    aaa: {
        index:""
        icon: "",
        iconNbt: {
                display: {
                    Name: '{"text":"aa","color":"gold","italic":"false"}',
                    Lore: ['{"text":"bb","color":"white","italic":"false"}'],
                }
            },
        //location的x取值1-7，y取值1-4，是物品在
        菜单的位置
        location: {
            x: 1,
            y: 2
        },
        leftClickAction: {
        //changeMenu必须接它接下来去的菜单界面
            type: "changeMenu",
            get nextMenu() {
                return mainWeapons
            }
        },
    },
    bbb: {
        index:""
        icon: "",
        iconNbt: {
                display: {
                    Name: '{"text":"cc","color":"gold","italic":"false"}',
                    Lore: ['{"text":"dd","color":"white","italic":"false"}'],
                }
            },
        location: {
            x: 3,
            y: 2
        },
        leftClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return subWeapons
            }
        }
    },
}
*/

const mainWeaponsBLUE = {
    description: {
        index: "mainWeaponsBLUE",
        type: "conductSelect",
        maxSelect: 1,
        title: Text.black('『主武器菜单』'),
        leftButton: {
            icon: 'createdeco:decal_left',
            iconNbt: {
                display: {
                    Name: '{"text":"返回","color":"gold","italic":"false"}',
                    Lore: ['{"text":"回到上一界面","color":"white","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "changeMenu",
                get nextMenu() {
                    return menuItemsBLUE
                }
            }
        },
        rightTopButton: {
            icon: 'book',
            iconNbt: {
                display: {
                    Name: '{"text":"注意事项","color":"gold","italic":"false"}',
                    Lore: ['{"text":"右键点击物品可以进入配件菜单。","color":"aqua","italic":"false"}', '{"text":"如果没反应就是没有配件。","color":"gray","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "none",
            }
        },
        leftTopButton: {
            icon: 'createdeco:decal_warning',
            iconNbt: {
                display: {
                    Name: '{"text":"重置","color":"red","italic":"false"}',
                    Lore: ['{"text":"重置当前页面下的选择","color":"white","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "reset"
            },
        }
    },
    mk18Mod1: {
        index: "mk18Mod1",
        icon: 'tacz:modern_kinetic_gun',
        iconNbt: {
            GunId: "classicr:mk18_mod1"
        },
        location: {
            x: 1,
            y: 1
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                gunItem: {
                    id: 'tacz:modern_kinetic_gun',
                    count: 1,
                    nbt: {
                        HasBulletInBarrel: true,
                        GunFireMode: "AUTO",
                        GunId: "classicr:mk18_mod1",
                        GunCurrentAmmoCount: Integer.parseInt('30')
                    }
                },
                ammos: {
                    id: 'tacz:ammo_box',
                    count: 1,
                    nbt: {
                        Level: Integer.parseInt('1'),
                        AmmoCount: Integer.parseInt('180'),
                        AmmoId: "tacz:556x45"
                    }
                }

            }
        },
        rightClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return mk18Mod1Attachments
            }
        }
    },
    spr15: {
        index: "spr15",
        icon: 'tacz:modern_kinetic_gun',
        iconNbt: {
            GunId: "classicr:spr_15"
        },
        location: {
            x: 1,
            y: 2
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                gunItem: {
                    id: 'tacz:modern_kinetic_gun',
                    count: 1,
                    nbt: {
                        HasBulletInBarrel: true,
                        GunFireMode: "SEMI",
                        GunId: "classicr:spr_15",
                        GunCurrentAmmoCount: Integer.parseInt('20')
                    }
                },
                ammos: {
                    id: 'tacz:ammo_box',
                    count: 1,
                    nbt: {
                        Level: Integer.parseInt('1'),
                        AmmoCount: Integer.parseInt('120'),
                        AmmoId: "tacz:556x45"
                    }
                }

            }
        },
        rightClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return spr15Attachments
            }
        }
    },
    FAL: {
        index: "FAL",
        icon: 'tacz:modern_kinetic_gun',
        iconNbt: {
            GunId: "cib:fal"
        },
        location: {
            x: 1,
            y: 3
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                gunItem: {
                    id: 'tacz:modern_kinetic_gun',
                    count: 1,
                    nbt: {
                        HasBulletInBarrel: true,
                        GunFireMode: "SEMI",
                        GunId: "cib:fal",
                        GunCurrentAmmoCount: Integer.parseInt('20')
                    }
                },
                ammos: {
                    id: 'tacz:ammo_box',
                    count: 1,
                    nbt: {
                        Level: Integer.parseInt('1'),
                        AmmoCount: Integer.parseInt('100'),
                        AmmoId: "tacz:308"
                    }
                }

            }
        },
        rightClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return FALAttachments
            }
        }
    },
    mk14: {
        index: "mk14",
        icon: 'tacz:modern_kinetic_gun',
        iconNbt: {
            GunId: "tacz:mk14"
        },
        location: {
            x: 1,
            y: 4
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                gunItem: {
                    id: 'tacz:modern_kinetic_gun',
                    count: 1,
                    nbt: {
                        HasBulletInBarrel: true,
                        GunFireMode: "SEMI",
                        GunId: "tacz:mk14",
                        GunCurrentAmmoCount: Integer.parseInt('10')
                    }
                },
                ammos: {
                    id: 'tacz:ammo_box',
                    count: 1,
                    nbt: {
                        Level: Integer.parseInt('1'),
                        AmmoCount: Integer.parseInt('90'),
                        AmmoId: "tacz:308"
                    }
                }

            }
        },
        rightClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return mk14Attachments
            }
        }
    },
    evo3: {
        index: "evo3",
        icon: 'tacz:modern_kinetic_gun',
        iconNbt: {
            GunId: "cib:evo3"
        },
        location: {
            x: 2,
            y: 1
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                gunItem: {
                    id: 'tacz:modern_kinetic_gun',
                    count: 1,
                    nbt: {
                        HasBulletInBarrel: true,
                        GunFireMode: "AUTO",
                        GunId: "cib:evo3",
                        GunCurrentAmmoCount: Integer.parseInt('20')
                    }
                },
                ammos: {
                    id: 'tacz:ammo_box',
                    count: 1,
                    nbt: {
                        Level: Integer.parseInt('1'),
                        AmmoCount: Integer.parseInt('240'),
                        AmmoId: "tacz:9mm"
                    }
                }

            }
        },
        rightClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return evo3Attachments
            }
        }
    },
    mp9: {
        index: "mp9",
        icon: 'tacz:modern_kinetic_gun',
        iconNbt: {
            GunId: "classicr:mp9"
        },
        location: {
            x: 2,
            y: 2
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                gunItem: {
                    id: 'tacz:modern_kinetic_gun',
                    count: 1,
                    nbt: {
                        HasBulletInBarrel: true,
                        GunFireMode: "AUTO",
                        GunId: "classicr:mp9",
                        GunCurrentAmmoCount: Integer.parseInt('30')
                    }
                },
                ammos: {
                    id: 'tacz:ammo_box',
                    count: 1,
                    nbt: {
                        Level: Integer.parseInt('1'),
                        AmmoCount: Integer.parseInt('240'),
                        AmmoId: "tacz:9mm"
                    }
                }

            }
        },
        rightClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return mp9Attachments
            }
        }
    },
    augPara: {
        index: "augPara",
        icon: 'tacz:modern_kinetic_gun',
        iconNbt: {
            GunId: "ccrp:aug_para"
        },
        location: {
            x: 2,
            y: 3
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                gunItem: {
                    id: 'tacz:modern_kinetic_gun',
                    count: 1,
                    nbt: {
                        HasBulletInBarrel: true,
                        GunFireMode: "AUTO",
                        GunId: "ccrp:aug_para",
                        GunCurrentAmmoCount: Integer.parseInt('25')
                    }
                },
                ammos: {
                    id: 'tacz:ammo_box',
                    count: 1,
                    nbt: {
                        Level: Integer.parseInt('1'),
                        AmmoCount: Integer.parseInt('250'),
                        AmmoId: "tacz:9mm"
                    }
                }

            }
        },
        rightClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return augParaAttachments
            }
        }
    },
    m249STANAG: {
        index: "m249STANAG",
        icon: 'tacz:modern_kinetic_gun',
        iconNbt: {
            GunId: "ccrp:m249_saw"
        },
        location: {
            x: 3,
            y: 1
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                gunItem: {
                    id: 'tacz:modern_kinetic_gun',
                    count: 1,
                    nbt: {
                        HasBulletInBarrel: true,
                        GunFireMode: "AUTO",
                        GunId: "ccrp:m249_saw",
                        GunCurrentAmmoCount: Integer.parseInt('30')
                    }
                },
                ammos: {
                    id: 'tacz:ammo_box',
                    count: 1,
                    nbt: {
                        Level: Integer.parseInt('1'),
                        AmmoCount: Integer.parseInt('300'),
                        AmmoId: "tacz:556x45"
                    }
                }

            }
        },
        rightClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return m249STANAGAttachments
            }
        }
    },
    m249: {
        index: "m249",
        icon: 'tacz:modern_kinetic_gun',
        iconNbt: {
            GunId: "tacz:m249"
        },
        location: {
            x: 3,
            y: 2
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                gunItem: {
                    id: 'tacz:modern_kinetic_gun',
                    count: 1,
                    nbt: {
                        HasBulletInBarrel: true,
                        GunFireMode: "AUTO",
                        GunId: "tacz:m249",
                        GunCurrentAmmoCount: Integer.parseInt('75')
                    }
                },
                ammos: {
                    id: 'tacz:ammo_box',
                    count: 1,
                    nbt: {
                        Level: Integer.parseInt('1'),
                        AmmoCount: Integer.parseInt('300'),
                        AmmoId: "tacz:556x45"
                    }
                }

            }
        },
        rightClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return m249Attachments
            }
        }
    },
    m60: {
        index: "m60",
        icon: 'tacz:modern_kinetic_gun',
        iconNbt: {
            GunId: "classicr:m60"
        },
        location: {
            x: 3,
            y: 3
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                gunItem: {
                    id: 'tacz:modern_kinetic_gun',
                    count: 1,
                    nbt: {
                        HasBulletInBarrel: true,
                        GunFireMode: "AUTO",
                        GunId: "classicr:m60",
                        GunCurrentAmmoCount: Integer.parseInt('100')
                    }
                },
                ammos: {
                    id: 'tacz:ammo_box',
                    count: 1,
                    nbt: {
                        Level: Integer.parseInt('1'),
                        AmmoCount: Integer.parseInt('200'),
                        AmmoId: "tacz:308"
                    }
                }

            }
        },
        rightClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return m60Attachments
            }
        }
    },
    m60Heavy: {
        index: "m60Heavy",
        icon: 'tacz:modern_kinetic_gun',
        iconNbt: {
            GunId: "rainforest:m60"
        },
        location: {
            x: 3,
            y: 4
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                gunItem: {
                    id: 'tacz:modern_kinetic_gun',
                    count: 1,
                    nbt: {
                        HasBulletInBarrel: true,
                        GunFireMode: "AUTO",
                        GunId: "rainforest:m60",
                        GunCurrentAmmoCount: Integer.parseInt('20')
                    }
                },
                ammos: {
                    id: 'tacz:ammo_box',
                    count: 1,
                    nbt: {
                        Level: Integer.parseInt('1'),
                        AmmoCount: Integer.parseInt('180'),
                        AmmoId: "tacz:308"
                    }
                }

            }
        },
        rightClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return m60HeavyAttachments
            }
        }
    },
    aa410: {
        index: "aa410",
        icon: 'tacz:modern_kinetic_gun',
        iconNbt: {
            GunId: "classicr:aa410"
        },
        location: {
            x: 4,
            y: 1
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                gunItem: {
                    id: 'tacz:modern_kinetic_gun',
                    count: 1,
                    nbt: {
                        HasBulletInBarrel: true,
                        GunFireMode: "AUTO",
                        GunId: "classicr:aa410",
                        GunCurrentAmmoCount: Integer.parseInt('30')
                    }
                },
                ammos: {
                    id: 'tacz:ammo_box',
                    count: 1,
                    nbt: {
                        Level: Integer.parseInt('1'),
                        AmmoCount: Integer.parseInt('90'),
                        AmmoId: "classicr:410_bore"
                    }
                }

            }
        },
        rightClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return aa410Attachments
            }
        }
    },

    mk20: {
        index: "mk20",
        icon: 'tacz:modern_kinetic_gun',
        iconNbt: {
            GunId: "classicr:scar_mk20"
        },
        location: {
            x: 5,
            y: 1
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                gunItem: {
                    id: 'tacz:modern_kinetic_gun',
                    count: 1,
                    nbt: {
                        HasBulletInBarrel: true,
                        GunFireMode: "SEMI",
                        GunId: "classicr:scar_mk20",
                        GunCurrentAmmoCount: Integer.parseInt('10')
                    }
                },
                ammos: {
                    id: 'tacz:ammo_box',
                    count: 1,
                    nbt: {
                        Level: Integer.parseInt('1'),
                        AmmoCount: Integer.parseInt('50'),
                        AmmoId: "tacz:308"
                    }
                }

            }
        },
        rightClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return mk20Attachments
            }
        }
    },
    /* m82a2: {
        index: "m82a2",
        icon: 'tacz:modern_kinetic_gun',
        iconNbt: {
            GunId: "classicr:m82a2"
        },
        location: {
            x: 5,
            y: 2
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                gunItem: {
                    id: 'tacz:modern_kinetic_gun',
                    count: 1,
                    nbt: {
                        HasBulletInBarrel: true,
                        GunFireMode: "SEMI",
                        GunId: "classicr:m82a2",
                        GunCurrentAmmoCount: Integer.parseInt('8')
                    }
                },
                ammos: {
                    id: 'tacz:ammo_box',
                    count: 1,
                    nbt: {
                        Level: Integer.parseInt('1'),
                        AmmoCount: Integer.parseInt('32'),
                        AmmoId: "tacz:50bmg"
                    }
                }

            }
        },
        rightClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return m82a2Attachments
            }
        }
    }, */
    aw50: {
        index: "aw50",
        icon: 'tacz:modern_kinetic_gun',
        iconNbt: {
            GunId: "suffuse:aw50"
        },
        location: {
            x: 5,
            y: 3
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                gunItem: {
                    id: 'tacz:modern_kinetic_gun',
                    count: 1,
                    nbt: {
                        HasBulletInBarrel: true,
                        GunFireMode: "SEMI",
                        GunId: "suffuse:aw50",
                        GunCurrentAmmoCount: Integer.parseInt('5')
                    }
                },
                ammos: {
                    id: 'tacz:ammo_box',
                    count: 1,
                    nbt: {
                        Level: Integer.parseInt('1'),
                        AmmoCount: Integer.parseInt('20'),
                        AmmoId: "tacz:50bmg"
                    }
                }

            }
        },
        rightClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return aw50Attachments
            }
        }
    },
    /* awp: {
        index: "awp",
        icon: 'tacz:modern_kinetic_gun',
        iconNbt: {
            GunId: "tacz:ai_awp"
        },
        location: {
            x: 5,
            y: 3
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                gunItem: {
                    id: 'tacz:modern_kinetic_gun',
                    count: 1,
                    nbt: {
                        HasBulletInBarrel: true,
                        GunFireMode: "SEMI",
                        GunId: "tacz:ai_awp",
                        GunCurrentAmmoCount: Integer.parseInt('5')
                    }
                },
                ammos: {
                    id: 'tacz:ammo_box',
                    count: 1,
                    nbt: {
                        Level: Integer.parseInt('1'),
                        AmmoCount: Integer.parseInt('20'),
                        AmmoId: "tacz:338"
                    }
                }

            }
        },
        rightClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return awpAttachments
            }
        }
    }, */
    javelin: {
        index: "javelin",
        icon: 'pointblank:javelin',
        iconNbt: {
        },
        location: {
            x: 6,
            y: 1
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                gunItem: {
                    id: 'pointblank:javelin',
                    count: 1,
                    nbt: {}
                },
                ammos: {
                    id: 'pointblank:javelin_rocket',
                    count: 3,
                    nbt: {}
                }
            }
        }
    },
    mgl: {
        index: "mgl",
        icon: 'pointblank:m32mgl',
        iconNbt: {
        },
        location: {
            x: 6,
            y: 2
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                gunItem: {
                    id: 'pointblank:m32mgl',
                    count: 1,
                    nbt: {}
                },
                ammos: {
                    id: 'pointblank:grenade40mm',
                    count: 12,
                    nbt: {}
                }
            }
        }
    },
}
