const armorsRED = {
    description: {
        index: "armorsRED",
        type: "conductSelect",
        maxSelect: 1,
        title: Text.black('『防具菜单』'),
        leftButton: {
            icon: 'createdeco:decal_left',
            iconNbt: {
                display: {
                    Name: '{"text":"返回","color":"gold","italic":"false"}',
                    Lore: ['{"text":"回到上一界面","color":"white","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "changeMenu",
                get nextMenu() {
                    return menuItemsRED
                }
            }
        },
        leftTopButton: {
            icon: 'createdeco:decal_warning',
            iconNbt: {
                display: {
                    Name: '{"text":"重置","color":"red","italic":"false"}',
                    Lore: ['{"text":"重置当前页面下的选择","color":"white","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "reset"
            },
        }
    },
    EMR: {
        index: "EMR",
        icon: 'combatgear:emr_helmet',
        iconNbt: {
            display: {
                Name: '{"text":"标准作战服","italic":"false"}',
                Lore: ['{"text":"没有任何特点，就是标准军装","color":"white","italic":"false"}'],
            }
        },
        location: {
            x: 2,
            y: 2
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                head: {
                    id: 'combatgear:emr_helmet',
                    count: 1,
                    armorSlot: 'head',
                    nbt: {
                    }
                },
                chest: {
                    id: 'combatgear:emr_chestplate',
                    count: 1,
                    armorSlot: 'chest',
                    nbt: {}
                },
                legs: {
                    id: 'combatgear:emr_leggings',
                    count: 1,
                    armorSlot: 'legs',
                    nbt: {}
                },
                boots: {
                    id: 'combatgear:emr_boots',
                    count: 1,
                    armorSlot: 'feet',
                    nbt: {
                    }
                },

            }
        },
    },
    吉利服: {
        index: "吉利服",
        icon: 'combatgear:ghilliesuit_helmet',
        iconNbt: {
            display: {
                Name: '{"text":"吉利服","color":"green","italic":"false"}',
                Lore: ['{"text":"便于伪装，但是防护性略有下降","color":"white","italic":"false"}'],
            }
        },
        location: {
            x: 4,
            y: 2
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                head: {
                    id: 'combatgear:ghilliesuit_helmet',
                    count: 1,
                    armorSlot: 'head',
                    nbt: {
                    }
                },
                chest: {
                    id: 'combatgear:ghilliesuit_chestplate',
                    count: 1,
                    armorSlot: 'chest',
                    nbt: { AttributeModifiers: [{ AttributeName: "generic.armor", Amount: 6, Slot: 'chest', UUID: chestUUID, Name: 1726124292172 }] }
                },
                legs: {
                    id: 'combatgear:ghilliesuit_leggings',
                    count: 1,
                    armorSlot: 'legs',
                    nbt: { AttributeModifiers: [{ AttributeName: "generic.armor", Amount: 4, Slot: 'legs', UUID: legsUUID, Name: 1726124292110 }] }
                },
                boots: {
                    id: 'combatgear:gign_boots',
                    count: 1,
                    armorSlot: 'feet',
                    nbt: {
                    }
                },

            }
        },
    },
    夜战服: {
        index: "夜战服",
        icon: 'combatgear:tacticalup_helmet',
        iconNbt: {
            display: {
                Name: '{"text":"夜战服","color":"aqua","italic":"false"}',
                Lore: ['{"text":"用少许防护换来夜视能力。按g以激活夜视","color":"white","italic":"false"}'],
            }
        },
        location: {
            x: 6,
            y: 2
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                head: {
                    id: 'combatgear:tacticalup_helmet',
                    count: 1,
                    armorSlot: 'head',
                    nbt: {
                    }
                },
                chest: {
                    id: 'combatgear:emr_chestplate',
                    count: 1,
                    armorSlot: 'chest',
                    nbt: {}
                },
                legs: {
                    id: 'combatgear:emr_leggings',
                    count: 1,
                    armorSlot: 'legs',
                    nbt: { Enchantments: [{ lvl: 1, id: 'binding_curse' }], AttributeModifiers: [{ AttributeName: "generic.armor", Amount: 2, Slot: 'legs', UUID: legsUUID, Name: 1726124292110 }] }
                },
                boots: {
                    id: 'combatgear:emr_boots',
                    count: 1,
                    armorSlot: 'feet',
                    nbt: {
                    }
                },
            }
        },
    }
}