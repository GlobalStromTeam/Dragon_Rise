const origin12Attachments = {
    description: {
        index: "origin12Attachments",
        type: "showSelection",
        title: Text.black('『Origin-12 配件菜单』'),
        leftButton: {
            icon: 'createdeco:decal_left',
            iconNbt: {
                display: {
                    Name: '{"text":"退出","color":"gold","italic":"false"}',
                    Lore: ['{"text":"按esc有一样的效果","color":"white","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "changeMenu",
                get nextMenu() {
                    return mainWeaponsRED
                }
            }
        },
    },
    origin12DescItem: {
        index: "origin12DescItem",
        icon: 'tacz:modern_kinetic_gun',
        iconNbt: {
            GunId: "cib:origin12"
        },
        location: {
            x: 4,
            y: 3
        },
        leftClickAction: {
            type: "none",
        }
    },
    origin12Muzzle: {
        index: "origin12Muzzle",
        icon: '',
        iconNbt: {
            display: {
                Name: '{"text":"枪口","color":"gold","italic":"false"}',
                //Lore: ['{"text":"","color":"white","italic":"false"}'],
            }
        },
        location: {
            x: 1,
            y: 1
        },
        leftClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return origin12Muzzle
            }
        }
    },
    origin12Grips: {
        index: "origin12Grips",
        icon: '',
        iconNbt: {
            display: {
                Name: '{"text":"握把","color":"gold","italic":"false"}',
                //Lore: ['{"text":"","color":"white","italic":"false"}'],
            }
        },
        location: {
            x: 1,
            y: 3
        },
        leftClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return origin12Grips
            }
        }
    },
    origin12Scopes: {
        index: "origin12Scopes",
        icon: '',
        iconNbt: {
            display: {
                Name: '{"text":"瞄具","color":"gold","italic":"false"}',
                //Lore: ['{"text":"","color":"white","italic":"false"}'],
            }
        },
        location: {
            x: 4,
            y: 1
        },
        leftClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return origin12Scopes
            }
        }
    },
    
    origin12Stock: {
        index: "origin12Stock",
        icon: '',
        iconNbt: {
            display: {
                Name: '{"text":"枪托","color":"gold","italic":"false"}',
                //Lore: ['{"text":"","color":"white","italic":"false"}'],
            }
        },
        location: {
            x: 7,
            y: 1
        },
        leftClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return origin12Stock
            }
        }
    },
    
    origin12ExtMag: {
        index: "origin12ExtMag",
        icon: '',
        iconNbt: {
            display: {
                Name: '{"text":"弹夹","color":"gold","italic":"false"}',
                //Lore: ['{"text":"","color":"white","italic":"false"}'],
            }
        },
        location: {
            x: 7,
            y: 3
        },
        leftClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return origin12ExtMag
            }
        }
    },
}

const origin12Muzzle = {
    description: {
        index: "origin12Muzzle",
        type: "nbtModifier",
        //maxSelect: 2,
        title: Text.black('『Origin-12 枪口菜单』'),
        leftButton: {
            icon: 'createdeco:decal_left',
            iconNbt: {
                display: {
                    Name: '{"text":"返回","color":"gold","italic":"false"}',
                    Lore: ['{"text":"回到上一界面","color":"white","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "changeMenu",
                get nextMenu() {
                    return origin12Attachments
                }
            }
        },
    },
    埃斯坦: {
        index: "埃斯坦",
        icon: 'tacz:attachment',
        iconNbt: {
            AttachmentId: "gucci_attachments:muzzle_b_estein290"
        },
        location: {
            x: 1,
            y: 2
        },
        leftClickAction: {
            type: "nbtSelect",
            targetItem: "origin12",
            nbts: {
                gunItem: {
                    nbt: {
                        AttachmentMUZZLE: {
                            id: "tacz:attachment",
                            Count: true,
                            tag: {
                                AttachmentId: "gucci_attachments:muzzle_b_estein290"
                            }
                        }
                    }
                }
            }
        }
    },
    PWS: {
        index: "PWS",
        icon: 'tacz:attachment',
        iconNbt: {
            AttachmentId: "gucci_attachments:muzzle_pws"
        },
        location: {
            x: 2,
            y: 2
        },
        leftClickAction: {
            type: "nbtSelect",
            targetItem: "origin12",
            nbts: {
                gunItem: {
                    nbt: {
                        AttachmentMUZZLE: {
                            id: "tacz:attachment",
                            Count: true,
                            tag: {
                                AttachmentId: "gucci_attachments:muzzle_pws"
                            }
                        }
                    }
                }
            }
        }
    },
    科莫多: {
        index: "科莫多",
        icon: 'tacz:attachment',
        iconNbt: {
            AttachmentId: "gucci_attachments:muzzle_b_komodo"
        },
        location: {
            x: 3,
            y: 2
        },
        leftClickAction: {
            type: "nbtSelect",
            targetItem: "origin12",
            nbts: {
                gunItem: {
                    nbt: {
                        AttachmentMUZZLE: {
                            id: "tacz:attachment",
                            Count: true,
                            tag: {
                                AttachmentId: "gucci_attachments:muzzle_b_komodo"
                            }
                        }
                    }
                },
            }
        }
    },
    科沃斯: {
        index: "科沃斯",
        icon: 'tacz:attachment',
        iconNbt: {
            AttachmentId: "gucci_attachments:muzzle_fr_coors2"
        },
        location: {
            x: 4,
            y: 2
        },
        leftClickAction: {
            type: "nbtSelect",
            targetItem: "origin12",
            nbts: {
                gunItem: {
                    nbt: {
                        AttachmentMUZZLE: {
                            id: "tacz:attachment",
                            Count: true,
                            tag: {
                                AttachmentId: "gucci_attachments:muzzle_fr_coors2"
                            }
                        }
                    }
                }
            }
        }
    },
    宽口: {
        index: "宽口",
        icon: 'tacz:attachment',
        iconNbt: {
            AttachmentId: "gucci_attachments:muzzle_s_widemouth"
        },
        location: {
            x: 5,
            y: 2
        },
        leftClickAction: {
            type: "nbtSelect",
            targetItem: "origin12",
            nbts: {
                gunItem: {
                    nbt: {
                        AttachmentMUZZLE: {
                            id: "tacz:attachment",
                            Count: true,
                            tag: {
                                AttachmentId: "gucci_attachments:muzzle_s_widemouth"
                            }
                        }
                    }
                }
            }
        }
    },
    
}
const origin12Grips = {
    description: {
        index: "origin12Grips",
        type: "nbtModifier",
        //maxSelect: 2,
        title: Text.black('『Origin-12 握把菜单』'),
        leftButton: {
            icon: 'createdeco:decal_left',
            iconNbt: {
                display: {
                    Name: '{"text":"返回","color":"gold","italic":"false"}',
                    Lore: ['{"text":"回到上一界面","color":"white","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "changeMenu",
                get nextMenu() {
                    return origin12Attachments
                }
            }
        },
    },
    军用制式: {
        index: "军用制式",
        icon: 'tacz:attachment',
        iconNbt: {
            AttachmentId: "tacz:grip_vertical_military"
        },
        location: {
            x: 1,
            y: 2
        },
        leftClickAction: {
            type: "nbtSelect",
            targetItem: "origin12",
            nbts: {
                gunItem: {
                    nbt: {
                        AttachmentGRIP: {
                            id: "tacz:attachment",
                            Count: true,
                            tag: {
                                AttachmentId: "tacz:grip_vertical_military"
                            }
                        }
                    }
                },
            }
        }
    },
    默克: {
        index: "默克",
        icon: 'tacz:attachment',
        iconNbt: {
            AttachmentId: "gucci_attachments:grip_vert1"
        },
        location: {
            x: 2,
            y: 2
        },
        leftClickAction: {
            type: "nbtSelect",
            targetItem: "origin12",
            nbts: {
                gunItem: {
                    nbt: {
                        AttachmentGRIP: {
                            id: "tacz:attachment",
                            Count: true,
                            tag: {
                                AttachmentId: "gucci_attachments:grip_vert1"
                            }
                        }
                    }
                }
            }
        }
    },
    BCM: {
        index: "BCM",
        icon: 'tacz:attachment',
        iconNbt: {
            AttachmentId: "gucci_attachments:grip_bcm"
        },
        location: {
            x: 3,
            y: 2
        },
        leftClickAction: {
            type: "nbtSelect",
            targetItem: "origin12",
            nbts: {
                gunItem: {
                    nbt: {
                        AttachmentGRIP: {
                            id: "tacz:attachment",
                            Count: true,
                            tag: {
                                AttachmentId: "gucci_attachments:grip_bcm"
                            }
                        }
                    }
                }
            }
        }
    },
    相位3型: {
        index: "相位3型",
        icon: 'tacz:attachment',
        iconNbt: {
            AttachmentId: "gucci_attachments:grip_phase"
        },
        location: {
            x: 4,
            y: 2
        },
        leftClickAction: {
            type: "nbtSelect",
            targetItem: "origin12",
            nbts: {
                gunItem: {
                    nbt: {
                        AttachmentGRIP: {
                            id: "tacz:attachment",
                            Count: true,
                            tag: {
                                AttachmentId: "gucci_attachments:grip_phase"
                            }
                        }
                    }
                }
            }
        }
    },
    CQR: {
        index: "CQR",
        icon: 'tacz:attachment',
        iconNbt: {
            AttachmentId: "gucci_attachments:grip_cqr"
        },
        location: {
            x: 5,
            y: 2
        },
        leftClickAction: {
            type: "nbtSelect",
            targetItem: "origin12",
            nbts: {
                gunItem: {
                    nbt: {
                        AttachmentGRIP: {
                            id: "tacz:attachment",
                            Count: true,
                            tag: {
                                AttachmentId: "gucci_attachments:grip_cqr"
                            }
                        }
                    }
                }
            }
        }
    },
}
const origin12Scopes = {
    description: {
        index: "origin12Scopes",
        type: "nbtModifier",
        //maxSelect: 2,
        title: Text.black('『Origin-12 瞄具菜单』'),
        leftButton: {
            icon: 'createdeco:decal_left',
            iconNbt: {
                display: {
                    Name: '{"text":"返回","color":"gold","italic":"false"}',
                    Lore: ['{"text":"回到上一界面","color":"white","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "changeMenu",
                get nextMenu() {
                    return origin12Attachments
                }
            }
        },
    },
    coyote: {
        index: "coyote",
        icon: 'tacz:attachment',
        iconNbt: {
            AttachmentId: "tacz:sight_coyote"
        },
        location: {
            x: 1,
            y: 2
        },
        leftClickAction: {
            type: "nbtSelect",
            targetItem: "origin12",
            nbts: {
                gunItem: {
                    nbt: {
                        AttachmentSCOPE: {
                            id: "tacz:attachment",
                            Count: true,
                            tag: {
                                AttachmentId: "tacz:sight_coyote"
                            }
                        }
                    }
                }
            }
        }
    },
    exp3: {
        index: "exp3",
        icon: 'tacz:attachment',
        iconNbt: {
            AttachmentId: "tacz:sight_exp3"
        },
        location: {
            x: 1,
            y: 3
        },
        leftClickAction: {
            type: "nbtSelect",
            targetItem: "origin12",
            nbts: {
                gunItem: {
                    nbt: {
                        AttachmentSCOPE: {
                            id: "tacz:attachment",
                            Count: true,
                            tag: {
                                AttachmentId: "tacz:sight_exp3"
                            }
                        }
                    }
                }
            }
        }
    },
    acog: {
        index: "acog",
        icon: 'tacz:attachment',
        iconNbt: {
            AttachmentId: "tacz:scope_acog_ta31"
        },
        location: {
            x: 2,
            y: 2
        },
        leftClickAction: {
            type: "nbtSelect",
            targetItem: "origin12",
            nbts: {
                gunItem: {
                    nbt: {
                        AttachmentSCOPE: {
                            id: "tacz:attachment",
                            Count: true,
                            tag: {
                                AttachmentId: "tacz:scope_acog_ta31"
                            }
                        }
                    }
                },
            }
        }
    },
    elcan: {
        index: "elcan",
        icon: 'tacz:attachment',
        iconNbt: {
            AttachmentId: "tacz:scope_elcan_4x"
        },
        location: {
            x: 3,
            y: 2
        },
        leftClickAction: {
            type: "nbtSelect",
            targetItem: "origin12",
            nbts: {
                gunItem: {
                    nbt: {
                        AttachmentSCOPE: {
                            id: "tacz:attachment",
                            Count: true,
                            tag: {
                                AttachmentId: "tacz:scope_elcan_4x"
                            }
                        }
                    }
                }
            }
        }
    },
    lpvo: {
        index: "lpvo",
        icon: 'tacz:attachment',
        iconNbt: {
            AttachmentId: "tacz:scope_lpvo_1_6"
        },
        location: {
            x: 4,
            y: 2
        },
        leftClickAction: {
            type: "nbtSelect",
            targetItem: "origin12",
            nbts: {
                gunItem: {
                    nbt: {
                        AttachmentSCOPE: {
                            id: "tacz:attachment",
                            Count: true,
                            tag: {
                                AttachmentId: "tacz:scope_lpvo_1_6"
                            }
                        }
                    }
                }
            }
        }
    },
    
}
const origin12Stock = {
    description: {
        index: "origin12Stock",
        type: "nbtModifier",
        //maxSelect: 2,
        title: Text.black('『Origin-12 枪托菜单』'),
        leftButton: {
            icon: 'createdeco:decal_left',
            iconNbt: {
                display: {
                    Name: '{"text":"返回","color":"gold","italic":"false"}',
                    Lore: ['{"text":"回到上一界面","color":"white","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "changeMenu",
                get nextMenu() {
                    return origin12Attachments
                }
            }
        },
    },
    碳骨C5: {
        index: "碳骨C5",
        icon: 'tacz:attachment',
        iconNbt: {
            AttachmentId: "tacz:stock_carbon_bone_c5"
        },
        location: {
            x: 1,
            y: 2
        },
        leftClickAction: {
            type: "nbtSelect",
            targetItem: "origin12",
            nbts: {
                gunItem: {
                    nbt: {
                        AttachmentSTOCK: {
                            id: "tacz:attachment",
                            Count: true,
                            tag: {
                                AttachmentId: "tacz:stock_carbon_bone_c5"
                            }
                        }
                    }
                }
            }
        }
    },
    派普兰: {
        index: "派普兰",
        icon: 'tacz:attachment',
        iconNbt: {
            AttachmentId: "gucci_attachments:stock_light2"
        },
        location: {
            x: 1,
            y: 3
        },
        leftClickAction: {
            type: "nbtSelect",
            targetItem: "origin12",
            nbts: {
                gunItem: {
                    nbt: {
                        AttachmentSTOCK: {
                            id: "tacz:attachment",
                            Count: true,
                            tag: {
                                AttachmentId: "gucci_attachments:stock_light2"
                            }
                        }
                    }
                }
            }
        }
    },
    /* tactical: {
        index: "tactical",
        icon: 'tacz:attachment',
        iconNbt: {
            AttachmentId: "tacz:oem_stock_tactical"
        },
        location: {
            x: 2,
            y: 2
        },
        leftClickAction: {
            type: "nbtSelect",
            targetItem: "origin12",
            nbts: {
                gunItem: {
                    nbt: {
                        AttachmentSTOCK: {
                            id: "tacz:attachment",
                            Count: true,
                            tag: {
                                AttachmentId: "tacz:oem_stock_tactical"
                            }
                        }
                    }
                }
            }
        }
    }, */
    掠劫8型: {
        index: "掠劫8型",
        icon: 'tacz:attachment',
        iconNbt: {
            AttachmentId: "gucci_attachments:stock_ar3"
        },
        location: {
            x: 2,
            y: 2
        },
        leftClickAction: {
            type: "nbtSelect",
            targetItem: "origin12",
            nbts: {
                gunItem: {
                    nbt: {
                        AttachmentSTOCK: {
                            id: "tacz:attachment",
                            Count: true,
                            tag: {
                                AttachmentId: "gucci_attachments:stock_ar3"
                            }
                        }
                    }
                }
            }
        }
    },
    /* heavy: {
        index: "heavy",
        icon: 'tacz:attachment',
        iconNbt: {
            AttachmentId: "tacz:oem_stock_heavy"
        },
        location: {
            x: 3,
            y: 2
        },
        leftClickAction: {
            type: "nbtSelect",
            targetItem: "origin12",
            nbts: {
                gunItem: {
                    nbt: {
                        AttachmentSTOCK: {
                            id: "tacz:attachment",
                            Count: true,
                            tag: {
                                AttachmentId: "tacz:oem_stock_heavy"
                            }
                        }
                    }
                },
            }
        }
    }, */
    沃尔夫: {
        index: "沃尔夫",
        icon: 'tacz:attachment',
        iconNbt: {
            AttachmentId: "gucci_attachments:stock_ar1"
        },
        location: {
            x: 3,
            y: 2
        },
        leftClickAction: {
            type: "nbtSelect",
            targetItem: "origin12",
            nbts: {
                gunItem: {
                    nbt: {
                        AttachmentSTOCK: {
                            id: "tacz:attachment",
                            Count: true,
                            tag: {
                                AttachmentId: "gucci_attachments:stock_ar1"
                            }
                        }
                    }
                },
            }
        }
    },
    欧特6: {
        index: "欧特6",
        icon: 'tacz:attachment',
        iconNbt: {
            AttachmentId: "gucci_attachments:stock_heavy1"
        },
        location: {
            x: 4,
            y: 2
        },
        leftClickAction: {
            type: "nbtSelect",
            targetItem: "origin12",
            nbts: {
                gunItem: {
                    nbt: {
                        AttachmentSTOCK: {
                            id: "tacz:attachment",
                            Count: true,
                            tag: {
                                AttachmentId: "gucci_attachments:stock_heavy1"
                            }
                        }
                    }
                },
            }
        }
    },
    科利欧: {
        index: "科利欧",
        icon: 'tacz:attachment',
        iconNbt: {
            AttachmentId: "gucci_attachments:stock_heavy2"
        },
        location: {
            x: 4,
            y: 3
        },
        leftClickAction: {
            type: "nbtSelect",
            targetItem: "origin12",
            nbts: {
                gunItem: {
                    nbt: {
                        AttachmentSTOCK: {
                            id: "tacz:attachment",
                            Count: true,
                            tag: {
                                AttachmentId: "gucci_attachments:stock_heavy2"
                            }
                        }
                    }
                },
            }
        }
    },
}
const origin12ExtMag = {
    description: {
        index: "origin12ExtMag",
        type: "nbtModifier",
        //maxSelect: 2,
        title: Text.black('『Origin-12 弹夹菜单』'),
        leftButton: {
            icon: 'createdeco:decal_left',
            iconNbt: {
                display: {
                    Name: '{"text":"返回","color":"gold","italic":"false"}',
                    Lore: ['{"text":"回到上一界面","color":"white","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "changeMenu",
                get nextMenu() {
                    return origin12Attachments
                }
            }
        },
    },
    mag1: {
        index: "mag1",
        icon: 'tacz:attachment',
        iconNbt: {
            AttachmentId: "tacz:extended_mag_1"
        },
        location: {
            x: 1,
            y: 2
        },
        leftClickAction: {
            type: "nbtSelect",
            targetItem: "origin12",
            nbts: {
                gunItem: {
                    nbt: {
                        AttachmentEXTENDED_MAG: {
                            id: "tacz:attachment",
                            Count: true,
                            tag: {
                                AttachmentId: "tacz:extended_mag_1"
                            }
                        }
                    }
                }
            }
        }
    },
    空尖弹: {
        index: "空尖弹",
        icon: 'tacz:attachment',
        iconNbt: {
            AttachmentId: "tacz:ammo_mod_hp"
        },
        location: {
            x: 1,
            y: 3
        },
        leftClickAction: {
            type: "nbtSelect",
            targetItem: "origin12",
            nbts: {
                gunItem: {
                    nbt: {
                        AttachmentEXTENDED_MAG: {
                            id: "tacz:attachment",
                            Count: true,
                            tag: {
                                AttachmentId: "tacz:ammo_mod_hp"
                            }
                        }
                    }
                }
            }
        }
    },
    全金属被甲弹: {
        index: "全金属被甲弹",
        icon: 'tacz:attachment',
        iconNbt: {
            AttachmentId: "tacz:ammo_mod_fmj"
        },
        location: {
            x: 1,
            y: 4
        },
        leftClickAction: {
            type: "nbtSelect",
            targetItem: "origin12",
            nbts: {
                gunItem: {
                    nbt: {
                        AttachmentEXTENDED_MAG: {
                            id: "tacz:attachment",
                            Count: true,
                            tag: {
                                AttachmentId: "tacz:ammo_mod_fmj"
                            }
                        }
                    }
                }
            }
        }
    },
    mag2: {
        index: "mag2",
        icon: 'tacz:attachment',
        iconNbt: {
            AttachmentId: "tacz:extended_mag_2"
        },
        location: {
            x: 2,
            y: 2
        },
        leftClickAction: {
            type: "nbtSelect",
            targetItem: "origin12",
            nbts: {
                gunItem: {
                    nbt: {
                        AttachmentEXTENDED_MAG: {
                            id: "tacz:attachment",
                            Count: true,
                            tag: {
                                AttachmentId: "tacz:extended_mag_2"
                            }
                        }
                    }
                }
            }
        }
    },
    mag3: {
        index: "mag3",
        icon: 'tacz:attachment',
        iconNbt: {
            AttachmentId: "tacz:extended_mag_3"
        },
        location: {
            x: 3,
            y: 2
        },
        leftClickAction: {
            type: "nbtSelect",
            targetItem: "origin12",
            nbts: {
                gunItem: {
                    nbt: {
                        AttachmentEXTENDED_MAG: {
                            id: "tacz:attachment",
                            Count: true,
                            tag: {
                                AttachmentId: "tacz:extended_mag_3"
                            }
                        }
                    }
                }
            }
        }
    },
}