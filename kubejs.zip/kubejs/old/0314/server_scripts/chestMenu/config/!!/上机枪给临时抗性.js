PlayerEvents.tick(event => {
    let { player } = event
    if (player.vehicle && (player.vehicle.type == "createbigcannons:pitch_contraption" || player.vehicle.type == "createbigcannons:cannon_carriage")) {
        player.potionEffects.add("minecraft:resistance", 20, 3, true, true)
    }
})
