const chestGUISize = {
    height: 6
}

const unselectSign = {
    type: 'minecraft:structure_void',
    name: '未选择',
    lore: '未选择'
}

const menuSounds = {
    accept: 'create:confirm',
    deny: 'create:deny',
    reset: 'minecraft:block.fire.extinguish',
    changeMenu: 'minecraft:item.book.page_turn'
}

/*
格式：
const xxx={
    description: {
    //index和对象名相同，用来索引
        index:"xxx"
        name: "xxx",
        //type决定显示方式
        type: "showSelection",
        //title是菜单标题
        title: Text.black('『配装菜单』'),
        //左按钮
        leftButton: {
        //按钮的图标对应物
            icon: 'createdeco:decal_left',
            iconNbt: {
                display: {
                    Name: '{"text":"xxx","color":"gold","italic":"false"}',
                    Lore: ['{"text":"yyy","color":"gray","italic":"false"}'],
                }
            },
            //点击物品的行为
            leftClickAction: {
            //type决定点击之后的结果
                type: "exit",
            }
        },
        rightButton: {
            icon: 'minecraft:diamond_sword',
            iconNbt: {
                display: {
                    Name: '{"text":"xxx","color":"gold","italic":"false"}',
                    Lore: ['{"text":"yyy","color":"gray","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "deploy"
            },
        }
    },
    aaa: {
        index:""
        icon: "",
        iconNbt: {
                display: {
                    Name: '{"text":"aa","color":"gold","italic":"false"}',
                    Lore: ['{"text":"bb","color":"gray","italic":"false"}'],
                }
            },
        //location的x取值1-7，y取值1-4，是物品在
        菜单的位置
        location: {
            x: 1,
            y: 2
        },
        leftClickAction: {
        //changeMenu必须接它接下来去的菜单界面
            type: "changeMenu",
            get nextMenu() {
                return mainWeapons
            }
        },
    },
    bbb: {
        index:""
        icon: "",
        iconNbt: {
                display: {
                    Name: '{"text":"cc","color":"gold","italic":"false"}',
                    Lore: ['{"text":"dd","color":"gray","italic":"false"}'],
                }
            },
        location: {
            x: 3,
            y: 2
        },
        leftClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return subWeapons
            }
        }
    },
}
*/
const Integer = Java.loadClass("java.lang.Integer")
const IntArrayTag = Java.loadClass("net.minecraft.nbt.IntArrayTag")
var headUUID = new IntArrayTag([
    Integer.parseInt('-885041709'),
    Integer.parseInt('1683771192'),
    Integer.parseInt('-1533567981'),
    Integer.parseInt('-114514')
]);
var chestUUID = new IntArrayTag([
    Integer.parseInt('-885041709'),
    Integer.parseInt('1683771192'),
    Integer.parseInt('-1533567981'),
    Integer.parseInt('-1919810')
]);
var legsUUID = new IntArrayTag([
    Integer.parseInt('-885041709'),
    Integer.parseInt('1683771192'),
    Integer.parseInt('-1533567981'),
    Integer.parseInt('-7556038')
]);
var bootsUUID = new IntArrayTag([
    Integer.parseInt('-885041709'),
    Integer.parseInt('1683771192'),
    Integer.parseInt('-1533567981'),
    Integer.parseInt('-9971577')
]);

function randomUUID() {
    return new IntArrayTag([
        Integer.parseInt(Math.floor(Math.random() * 100000).toString()),
        Integer.parseInt(Math.floor(Math.random() * 100000).toString()),
        Integer.parseInt(Math.floor(Math.random() * 100000).toString()),
        Integer.parseInt(Math.floor(Math.random() * 100000).toString()),
    ]);
}
const menuMainRED = {
    description: {
        index: "menuMainRED",
        type: "invSave",
        title: Text.black('『东联主菜单』'),
        leftButton: {
            icon: 'createdeco:decal_left',
            iconNbt: {
                display: {
                    Name: '{"text":"退出","color":"red","italic":"false"}',
                    Lore: ['{"text":"按esc有一样的效果","color":"gray","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "exit",
            }
        },
    },
    menuItemsRED: {
        index: "menuItemsRED",
        icon: "iron_chestplate",
        iconNbt: {
            display: {
                Name: '{"text":"配装菜单","color":"gold","italic":"false"}',
                Lore: ['{"text":"点击进入选择界面","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 4,
            y: 2
        },
        leftClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return menuItemsRED
            }
        },
    },
    saveInventory1: {
        index: "saveInventory1",
        icon: "chest",
        iconNbt: {
            display: {
                Name: '{"text":"加载/保存背包布局-01","color":"gold","italic":"false"}',
                Lore: ['{"text":"左键点击加载布局，右键点击保存布局，展示物品为快捷栏一号位。","color":"aqua","italic":"false"}','{"text":"请在点击前预先布置好布局，保存功能会在点击后延迟5秒生效，此期间请不要再次进入菜单。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 2,
            y: 1
        },
        leftClickAction: {
            type: "loadInventory",
            invPath: "inventory1"
        },
        rightClickAction: {
            type: "saveInventory",
            invPath: "inventory1"
        }
    },
    saveInventory5: {
        index: "saveInventory5",
        icon: "chest",
        iconNbt: {
            display: {
                Name: '{"text":"加载/保存背包布局-05","color":"gold","italic":"false"}',
                Lore: ['{"text":"左键点击加载布局，右键点击保存布局，展示物品为快捷栏一号位。","color":"aqua","italic":"false"}','{"text":"请在点击前预先布置好布局，保存功能会在点击后延迟5秒生效，此期间请不要再次进入菜单。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 6,
            y: 1
        },
        leftClickAction: {
            type: "loadInventory",
            invPath: "inventory5"
        },
        rightClickAction: {
            type: "saveInventory",
            invPath: "inventory5"
        }
    },
    saveInventory2: {
        index: "saveInventory2",
        icon: "chest",
        iconNbt: {
            display: {
                Name: '{"text":"加载/保存背包布局-02","color":"gold","italic":"false"}',
                Lore: ['{"text":"左键点击加载布局，右键点击保存布局，展示物品为快捷栏一号位。","color":"aqua","italic":"false"}','{"text":"请在点击前预先布置好布局，保存功能会在点击后延迟5秒生效，此期间请不要再次进入菜单。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 2,
            y: 2
        },
        leftClickAction: {
            type: "loadInventory",
            invPath: "inventory2"
        },
        rightClickAction: {
            type: "saveInventory",
            invPath: "inventory2"
        }
    },
    saveInventory6: {
        index: "saveInventory6",
        icon: "chest",
        iconNbt: {
            display: {
                Name: '{"text":"加载/保存背包布局-06","color":"gold","italic":"false"}',
                Lore: ['{"text":"左键点击加载布局，右键点击保存布局，展示物品为快捷栏一号位。","color":"aqua","italic":"false"}','{"text":"请在点击前预先布置好布局，保存功能会在点击后延迟5秒生效，此期间请不要再次进入菜单。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 6,
            y: 2
        },
        leftClickAction: {
            type: "loadInventory",
            invPath: "inventory6"
        },
        rightClickAction: {
            type: "saveInventory",
            invPath: "inventory6"
        }
    },
    saveInventory3: {
        index: "saveInventory3",
        icon: "chest",
        iconNbt: {
            display: {
                Name: '{"text":"加载/保存背包布局-03","color":"gold","italic":"false"}',
                Lore: ['{"text":"左键点击加载布局，右键点击保存布局，展示物品为快捷栏一号位。","color":"aqua","italic":"false"}','{"text":"请在点击前预先布置好布局，保存功能会在点击后延迟5秒生效，此期间请不要再次进入菜单。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 2,
            y: 3
        },
        leftClickAction: {
            type: "loadInventory",
            invPath: "inventory3"
        },
        rightClickAction: {
            type: "saveInventory",
            invPath: "inventory3"
        }
    },
    saveInventory7: {
        index: "saveInventory7",
        icon: "chest",
        iconNbt: {
            display: {
                Name: '{"text":"加载/保存背包布局-07","color":"gold","italic":"false"}',
                Lore: ['{"text":"左键点击加载布局，右键点击保存布局，展示物品为快捷栏一号位。","color":"aqua","italic":"false"}','{"text":"请在点击前预先布置好布局，保存功能会在点击后延迟5秒生效，此期间请不要再次进入菜单。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 6,
            y: 3
        },
        leftClickAction: {
            type: "loadInventory",
            invPath: "inventory7"
        },
        rightClickAction: {
            type: "saveInventory",
            invPath: "inventory7"
        }
    },
    saveInventory4: {
        index: "saveInventory4",
        icon: "chest",
        iconNbt: {
            display: {
                Name: '{"text":"加载/保存背包布局-04","color":"gold","italic":"false"}',
                Lore: ['{"text":"左键点击加载布局，右键点击保存布局，展示物品为快捷栏一号位。","color":"aqua","italic":"false"}','{"text":"请在点击前预先布置好布局，保存功能会在点击后延迟5秒生效，此期间请不要再次进入菜单。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 2,
            y: 4
        },
        leftClickAction: {
            type: "loadInventory",
            invPath: "inventory4"
        },
        rightClickAction: {
            type: "saveInventory",
            invPath: "inventory4"
        }
    },
    saveInventory8: {
        index: "saveInventory8",
        icon: "chest",
        iconNbt: {
            display: {
                Name: '{"text":"加载/保存背包布局-08","color":"gold","italic":"false"}',
                Lore: ['{"text":"左键点击加载布局，右键点击保存布局，展示物品为快捷栏一号位。","color":"aqua","italic":"false"}','{"text":"请在点击前预先布置好布局，保存功能会在点击后延迟5秒生效，此期间请不要再次进入菜单。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 6,
            y: 4
        },
        leftClickAction: {
            type: "loadInventory",
            invPath: "inventory8"
        },
        rightClickAction: {
            type: "saveInventory",
            invPath: "inventory8"
        }
    },
}

const menuMainBLUE = {
    description: {
        index: "menuMainBLUE",
        type: "invSave",
        title: Text.black('『盟军主菜单』'),
        leftButton: {
            icon: 'createdeco:decal_left',
            iconNbt: {
                display: {
                    Name: '{"text":"退出","color":"red","italic":"false"}',
                    Lore: ['{"text":"按esc有一样的效果","color":"gray","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "exit",
            }
        },
    },
    menuItemsBLUE: {
        index: "menuItemsBLUE",
        icon: "iron_chestplate",
        iconNbt: {
            display: {
                Name: '{"text":"配装菜单","color":"gold","italic":"false"}',
                Lore: ['{"text":"点击进入选择界面","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 4,
            y: 2
        },
        leftClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return menuItemsBLUE
            }
        },
    },
    saveInventory1: {
        index: "saveInventory1",
        icon: "chest",
        iconNbt: {
            display: {
                Name: '{"text":"加载/保存背包布局-01","color":"gold","italic":"false"}',
                Lore: ['{"text":"左键点击加载布局，右键点击保存布局，展示物品为快捷栏一号位。","color":"aqua","italic":"false"}','{"text":"请在点击前预先布置好布局，保存功能会在点击后延迟5秒生效，此期间请不要再次进入菜单。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 2,
            y: 1
        },
        leftClickAction: {
            type: "loadInventory",
            invPath: "inventory1"
        },
        rightClickAction: {
            type: "saveInventory",
            invPath: "inventory1"
        }
    },
    saveInventory5: {
        index: "saveInventory5",
        icon: "chest",
        iconNbt: {
            display: {
                Name: '{"text":"加载/保存背包布局-05","color":"gold","italic":"false"}',
                Lore: ['{"text":"左键点击加载布局，右键点击保存布局，展示物品为快捷栏一号位。","color":"aqua","italic":"false"}','{"text":"请在点击前预先布置好布局，保存功能会在点击后延迟5秒生效，此期间请不要再次进入菜单。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 6,
            y: 1
        },
        leftClickAction: {
            type: "loadInventory",
            invPath: "inventory5"
        },
        rightClickAction: {
            type: "saveInventory",
            invPath: "inventory5"
        }
    },
    saveInventory2: {
        index: "saveInventory2",
        icon: "chest",
        iconNbt: {
            display: {
                Name: '{"text":"加载/保存背包布局-02","color":"gold","italic":"false"}',
                Lore: ['{"text":"左键点击加载布局，右键点击保存布局，展示物品为快捷栏一号位。","color":"aqua","italic":"false"}','{"text":"请在点击前预先布置好布局，保存功能会在点击后延迟5秒生效，此期间请不要再次进入菜单。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 2,
            y: 2
        },
        leftClickAction: {
            type: "loadInventory",
            invPath: "inventory2"
        },
        rightClickAction: {
            type: "saveInventory",
            invPath: "inventory2"
        }
    },
    saveInventory6: {
        index: "saveInventory6",
        icon: "chest",
        iconNbt: {
            display: {
                Name: '{"text":"加载/保存背包布局-06","color":"gold","italic":"false"}',
                Lore: ['{"text":"左键点击加载布局，右键点击保存布局，展示物品为快捷栏一号位。","color":"aqua","italic":"false"}','{"text":"请在点击前预先布置好布局，保存功能会在点击后延迟5秒生效，此期间请不要再次进入菜单。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 6,
            y: 2
        },
        leftClickAction: {
            type: "loadInventory",
            invPath: "inventory6"
        },
        rightClickAction: {
            type: "saveInventory",
            invPath: "inventory6"
        }
    },
    saveInventory3: {
        index: "saveInventory3",
        icon: "chest",
        iconNbt: {
            display: {
                Name: '{"text":"加载/保存背包布局-03","color":"gold","italic":"false"}',
                Lore: ['{"text":"左键点击加载布局，右键点击保存布局，展示物品为快捷栏一号位。","color":"aqua","italic":"false"}','{"text":"请在点击前预先布置好布局，保存功能会在点击后延迟5秒生效，此期间请不要再次进入菜单。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 2,
            y: 3
        },
        leftClickAction: {
            type: "loadInventory",
            invPath: "inventory3"
        },
        rightClickAction: {
            type: "saveInventory",
            invPath: "inventory3"
        }
    },
    saveInventory7: {
        index: "saveInventory7",
        icon: "chest",
        iconNbt: {
            display: {
                Name: '{"text":"加载/保存背包布局-07","color":"gold","italic":"false"}',
                Lore: ['{"text":"左键点击加载布局，右键点击保存布局，展示物品为快捷栏一号位。","color":"aqua","italic":"false"}','{"text":"请在点击前预先布置好布局，保存功能会在点击后延迟5秒生效，此期间请不要再次进入菜单。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 6,
            y: 3
        },
        leftClickAction: {
            type: "loadInventory",
            invPath: "inventory7"
        },
        rightClickAction: {
            type: "saveInventory",
            invPath: "inventory7"
        }
    },
    saveInventory4: {
        index: "saveInventory4",
        icon: "chest",
        iconNbt: {
            display: {
                Name: '{"text":"加载/保存背包布局-04","color":"gold","italic":"false"}',
                Lore: ['{"text":"左键点击加载布局，右键点击保存布局，展示物品为快捷栏一号位。","color":"aqua","italic":"false"}','{"text":"请在点击前预先布置好布局，保存功能会在点击后延迟5秒生效，此期间请不要再次进入菜单。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 2,
            y: 4
        },
        leftClickAction: {
            type: "loadInventory",
            invPath: "inventory4"
        },
        rightClickAction: {
            type: "saveInventory",
            invPath: "inventory4"
        }
    },
    saveInventory8: {
        index: "saveInventory8",
        icon: "chest",
        iconNbt: {
            display: {
                Name: '{"text":"加载/保存背包布局-08","color":"gold","italic":"false"}',
                Lore: ['{"text":"左键点击加载布局，右键点击保存布局，展示物品为快捷栏一号位。","color":"aqua","italic":"false"}','{"text":"请在点击前预先布置好布局，保存功能会在点击后延迟5秒生效，此期间请不要再次进入菜单。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 6,
            y: 4
        },
        leftClickAction: {
            type: "loadInventory",
            invPath: "inventory8"
        },
        rightClickAction: {
            type: "saveInventory",
            invPath: "inventory8"
        }
    },
}

const menuItemsRED = {
    description: {
        index: "menuItemsRED",
        type: "showSelection",
        title: Text.black('『东联配装菜单』'),
        leftButton: {
            icon: 'createdeco:decal_left',
            iconNbt: {
                display: {
                    Name: '{"text":"退出","color":"red","italic":"false"}',
                    Lore: ['{"text":"按esc有一样的效果","color":"gray","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "exit",
            }
        },
        rightButton: {
            icon: 'minecraft:diamond_sword',
            iconNbt: {
                display: {
                    Name: '{"text":"部署","color":"gold","italic":"false"}',
                    Lore: ['{"text":"第一次部署可能会失败，再点一次就行。","color":"gray","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "deploy"
            },
        },
        leftTopButton: {
            icon: 'createdeco:decal_warning',
            iconNbt: {
                display: {
                    Name: '{"text":"重置","color":"gold","italic":"false"}',
                    Lore: ['{"text":"重置所有选择","color":"gray","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "reset"
            },
        }
    },
    mainWeaponsRED: {
        index: "mainWeaponsRED",
        icon: "",
        iconNbt: {
            display: {
                Name: '{"text":"主武器","color":"gold","italic":"false"}',
                Lore: ['{"text":"最常用的主力枪械","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 1,
            y: 2
        },
        leftClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return mainWeaponsRED
            }
        },
    },
    subWeaponsRED: {
        index: "subWeaponsRED",
        icon: "",
        iconNbt: {
            display: {
                Name: '{"text":"副武器","color":"gold","italic":"false"}',
                Lore: ['{"text":"应急选择，但也不一定","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 3,
            y: 2
        },
        leftClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return subWeaponsRED
            }
        }
    },
    mainToolsRED: {
        index: "mainToolsRED",
        icon: "",
        iconNbt: {
            display: {
                Name: '{"text":"主道具","color":"gold","italic":"false"}',
                Lore: ['{"text":"主导玩法的核心道具","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 5,
            y: 2
        },
        leftClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return mainToolsRED
            }
        }
    },

    subToolsRED: {
        index: "subToolsRED",
        icon: "",
        iconNbt: {
            display: {
                Name: '{"text":"副道具","color":"gold","italic":"false"}',
                Lore: ['{"text":"强而有力的辅助物品","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 7,
            y: 2
        },
        leftClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return subToolsRED
            }
        }
    },
    armorsRED: {
        index: "armorsRED",
        icon: "",
        iconNbt: {
            display: {
                Name: '{"text":"防具","color":"gold","italic":"false"}',
                Lore: ['{"text":"如果在其他道具里选择了护甲类物品，请确保先选择防具再选择道具，否则会出现吞道具的情况！","color":"red","italic":"false"}'],
            }
        },
        location: {
            x: 2,
            y: 3
        },
        leftClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return armorsRED
            }
        }
    },
    grenadesRED: {
        index: "grenadesRED",
        icon: "",
        iconNbt: {
            display: {
                Name: '{"text":"投掷物","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 4,
            y: 3
        },
        leftClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return grenadesRED
            }
        }
    },
    suppliesRED: {
        index: "suppliesRED",
        icon: "",
        iconNbt: {
            display: {
                Name: '{"text":"支援物品","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 6,
            y: 3
        },
        leftClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return suppliesRED
            }
        }
    }
}

const menuItemsBLUE = {
    description: {
        index: "menuItemsBLUE",
        type: "showSelection",
        title: Text.black('『盟军配装菜单』'),
        leftButton: {
            icon: 'createdeco:decal_left',
            iconNbt: {
                display: {
                    Name: '{"text":"退出","color":"red","italic":"false"}',
                    Lore: ['{"text":"按esc有一样的效果","color":"gray","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "exit",
            }
        },
        rightButton: {
            icon: 'minecraft:diamond_sword',
            iconNbt: {
                display: {
                    Name: '{"text":"部署","color":"gold","italic":"false"}',
                    Lore: ['{"text":"第一次部署可能会失败，再点一次就行。","color":"gray","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "deploy"
            },
        },
        leftTopButton: {
            icon: 'createdeco:decal_warning',
            iconNbt: {
                display: {
                    Name: '{"text":"重置","color":"gold","italic":"false"}',
                    Lore: ['{"text":"重置所有选择","color":"gray","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "reset"
            },
        }
    },
    mainWeaponsBLUE: {
        index: "mainWeaponsBLUE",
        icon: "",
        iconNbt: {
            display: {
                Name: '{"text":"主武器","color":"gold","italic":"false"}',
                Lore: ['{"text":"最常用的主力枪械","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 1,
            y: 2
        },
        leftClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return mainWeaponsBLUE
            }
        },
    },
    subWeaponsBLUE: {
        index: "subWeaponsBLUE",
        icon: "",
        iconNbt: {
            display: {
                Name: '{"text":"副武器","color":"gold","italic":"false"}',
                Lore: ['{"text":"应急选择，但也不一定","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 3,
            y: 2
        },
        leftClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return subWeaponsBLUE
            }
        }
    },
    mainToolsBLUE: {
        index: "mainToolsBLUE",
        icon: "",
        iconNbt: {
            display: {
                Name: '{"text":"主道具","color":"gold","italic":"false"}',
                Lore: ['{"text":"主导玩法的核心道具","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 5,
            y: 2
        },
        leftClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return mainToolsBLUE
            }
        }
    },

    subToolsBLUE: {
        index: "subToolsBLUE",
        icon: "",
        iconNbt: {
            display: {
                Name: '{"text":"副道具","color":"gold","italic":"false"}',
                Lore: ['{"text":"强而有力的辅助物品","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 7,
            y: 2
        },
        leftClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return subToolsBLUE
            }
        }
    },
    armorsBLUE: {
        index: "armorsBLUE",
        icon: "",
        iconNbt: {
            display: {
                Name: '{"text":"防具","color":"gold","italic":"false"}',
                Lore: ['{"text":"如果在其他道具里选择了护甲类物品，请确保先选择防具再选择道具，否则会出现吞道具的情况！","color":"red","italic":"false"}'],
            }
        },
        location: {
            x: 2,
            y: 3
        },
        leftClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return armorsBLUE
            }
        }
    },
    grenadesBLUE: {
        index: "grenadesBLUE",
        icon: "",
        iconNbt: {
            display: {
                Name: '{"text":"投掷物","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 4,
            y: 3
        },
        leftClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return grenadesBLUE
            }
        }
    },
    suppliesBLUE: {
        index: "suppliesBLUE",
        icon: "",
        iconNbt: {
            display: {
                Name: '{"text":"支援物品","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 6,
            y: 3
        },
        leftClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return suppliesBLUE
            }
        }
    }
}

