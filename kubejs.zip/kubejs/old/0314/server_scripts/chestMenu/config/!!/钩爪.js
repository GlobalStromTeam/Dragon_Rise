ItemEvents.rightClicked("fishing_rod", (event) => {
  const { entity, item, level } = event;

  if (entity.fishing) {
    let { fishing: hook } = entity;
    let aabb = hook.getBoundingBox().inflate(0.5)
    let isNearBlock = false
    level.getBlockStates(aabb).forEach(state => {
      //event.server.tell(state.block.id)
      if (state.block.id != 'minecraft:air') {
        isNearBlock = true
      }
    })
    //event.server.tell(isNearBlock)
    if (isNearBlock) {
      //event.server.tell(pos)
      entity.deltaMovement = new Vec3d(
        hook.x - entity.x,
        hook.y - entity.y,
        hook.z - entity.z
      ).scale(0.24);
      entity.hurtMarked = true;
      item.damageValue += 10
    } else {
      entity.deltaMovement = new Vec3d(
        hook.x - entity.x,
        hook.y - entity.y,
        hook.z - entity.z
      ).scale(0.05);
      entity.hurtMarked = true;
      item.damageValue += 4
    }

  }
});