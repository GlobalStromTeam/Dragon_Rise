const pie = 3.14159

const mortarItem = Item.of(
    'createbigcannons:drop_mortar_shell',
    '{BlockEntityTag:{Fuze:{Count:1b,id:"createbigcannons:proximity_fuze",tag:{DetonationDistance:6}},Tracer:{Count:1b,id:"createbigcannons:tracer_tip"},id:"createbigcannons:fuzed_block"}}'
);

const autoCannonItem = Item.of(
    'createbigcannons:autocannon_cartridge',
    '{Projectile:{id:"createbigcannons:flak_autocannon_round",Count:1b,tag:{Fuze:{Count:1b,id:"createbigcannons:impact_fuze"},Tracer:1b}}}'
);

const machineGunItem = Item.of(
    'createbigcannons:machine_gun_round',
    '{Tracer:1b}'
);

const notTargetType = ['minecraft:arrow', 'minecraft:item', 'minecraft:experience_orb', 'tacz:bullet', 'minecraft:snowball', 'minecraft:ender_pearl', 'minecraft:fishing_bobber', 'minecraft:armor_stand', 'mutantmonsters:body_part']
const notTargetTeam = ['HP', 'Player', 'Yellow']

let Vec3 = Java.loadClass('net.minecraft.world.phys.Vec3')

const modeMap = {
    'static': '',
    'spread': '1000000',
    'gather': '-1000000'
}
function particleRing(mode, count, delay, x, y, z, particleId, speed) {
    const angleTemp = 360 / count;
    const speedTemp = (speed * 0.0000002).toFixed(8);
    const modeTemp = modeMap[mode];
    for (let i = 0, counter = 0; i < count; i++) {
        Utils.server.scheduleInTicks(delay * i, () => {
            counter++;
            //Utils.server.tell(`execute positioned ${x} ${y} ${z} facing entity @e[type=!xtraarrows:netherite_explosive_arrow,sort=nearest,limit=1] eyes run particle ${particleId} ^${Math.sin(angleTemp*counter)} ^${Math.cos(angleTemp*counter)} ^ ^${modeTemp * Math.sin(angleTemp*counter)} ^${modeTemp * Math.cos(angleTemp*counter)} ^ ${speedTemp} 0 force`)
            //Utils.server.runCommandSilent(`execute positioned ${x} ${y} ${z} facing entity @e[type=!xtraarrows:netherite_explosive_arrow,sort=nearest,limit=1] eyes run particle ${particleId} ^${0.1 * Math.sin(angleTemp * counter)} ^${0.1 * Math.cos(angleTemp * counter)} ^-1 ^${modeTemp * Math.sin(angleTemp * counter)} ^${modeTemp * Math.cos(angleTemp * counter)} ^${modeTemp * 2} ${speedTemp} 0 force`)
            Utils.server.runCommandSilent(`execute positioned ${x} ${y} ${z} facing entity @e[type=!xtraarrows:netherite_explosive_arrow,sort=nearest,limit=1] eyes run particle ${particleId} 10 0.2 100 1 ^${0.1 * Math.sin(angleTemp * counter)} ^${0.1 * Math.cos(angleTemp * counter)} ^-1 ^${modeTemp * Math.sin(angleTemp * counter)} ^${modeTemp * Math.cos(angleTemp * counter)} ^${modeTemp * 2} ${speedTemp} 0 force`)
        })
    }
}

function getClosestVisibleEntity(sourceEntity, radius) {
    // 获取源实体的位置和世界
    const level = sourceEntity.level;

    // 创建搜索区域的AABB
    const aabb = sourceEntity.boundingBox.inflate(radius)

    // 获取区域内的所有实体
    const entities = level.getEntitiesWithin(aabb);

    let closestEntity = null;
    let minDistance = radius * radius // 初始化为半径平方
    for (let i = 0; i < entities.length; i++) {

        let other = entities[i];

        if (other == sourceEntity || !other.teamId || other.teamId == sourceEntity.teamId || !other.isAlive()
            || other.type.toString().includes('createbigcannon')
            || other.type.toString().includes('zombieawareness')
            || other.type.toString().includes('enhancedai')
            || other.type.toString().includes('xtraarrows')
            || notTargetType.includes(other.type)
            || notTargetTeam.includes(other.teamId)) continue;

        // 计算距离

        let distance = sourceEntity.distanceToEntitySqr(other)
        //console.log(other)
        //console.log(Math.sqrt(distance))
        // 如果更近且可见，则更新最近实体
        if (distance < minDistance && sourceEntity.hasLineOfSight(other)) {
            closestEntity = other;
            minDistance = distance;
        }

    }

    return closestEntity;
}

function getClosestSeeSkyEntity(sourceEntity, radius) {
    // 获取源实体的位置和世界
    const level = sourceEntity.level;

    // 创建搜索区域的AABB
    const aabb = sourceEntity.boundingBox.inflate(radius)

    // 获取区域内的所有实体
    const entities = level.getEntitiesWithin(aabb);

    let closestEntity = null;
    let minDistance = radius * radius // 初始化为半径平方
    for (let i = 0; i < entities.length; i++) {

        let other = entities[i];

        if (other == sourceEntity || !other.teamId || other.teamId == sourceEntity.teamId || !other.isAlive()
            || other.type.toString().includes('createbigcannon')
            || other.type.toString().includes('zombieawareness')
            || other.type.toString().includes('enhancedai')
            || other.type.toString().includes('xtraarrows')
            || notTargetType.includes(other.type)
            || notTargetTeam.includes(other.teamId)) continue;

        // 计算距离

        let distance = sourceEntity.distanceToEntitySqr(other)
        //console.log(other)
        //console.log(Math.sqrt(distance))
        // 如果更近且可见，则更新最近实体
        if (distance < minDistance && other.block.up.canSeeSky) {
            closestEntity = other;
            minDistance = distance;
        }

    }

    return closestEntity;
}

function drawMultiParticle(id, x, y, z, vx, vy, vz, interval, count, speedRate, level, server) {
    let currentCount = 0
    server.scheduleRepeating(interval, callback => {
        callback.repeating = true
        if (currentCount >= count) {
            callback.repeating = false
        }
        currentCount += 1
        level.spawnParticles(id, true, x, y, z, vx, vy, vz, 0, speedRate)
    })
}

EntityEvents.spawned('xtraarrows:netherite_explosive_arrow', event => {
    const { entity, server, level } = event
    particleRing('spread', 36, 0, entity.x, entity.y, entity.z, 'createbigcannons:cannon_smoke', 0.4)
    //particleRing('spread', 36, 0, entity.x, entity.y, entity.z, 'flame', 0.4)

})

EntityEvents.spawned('villager', event => {
    const { entity, server, level } = event
    //server.tell(entity.nbt)
    if (entity.name) {
        //server.tell(entity.name)
        let targetEntity = undefined
        switch (entity.name.string) {
            case '哨戒迫击炮':

                server.scheduleRepeatingInTicks(240, callback => {
                    callback.repeating = true
                    if (!entity.isAlive() || entity.isRemoved()) {
                        callback.repeating = false
                    } else {
                        targetEntity = getClosestSeeSkyEntity(entity, 200);
                        //targetEntity = entity.eyePosition
                        if (targetEntity) {
                            //console.log(targetEntity)
                            let speed = 80.0; // Adjust speed as needed
                            let result = Newton(entity.x, entity.y, entity.z, targetEntity.x, targetEntity.y, targetEntity.z, speed, 1)
                            //console.log(result)

                            let yaw = result[0]
                            let pitch = result[1]

                            entity.setRotation(yaw, -pitch)
                            //server.tell(targetEntity.type)
                            //entity.lookAt("eyes", targetEntity.eyePosition)


                            let motionX = entity.lookAngle.x() * speed;  // Use positive x for forward
                            let motionY = entity.lookAngle.y() * speed;  // Use positive y for upward
                            let motionZ = entity.lookAngle.z() * speed;  // Use positive z for forward
                            // Create a Vec3 for the motion

                            //let motionVec3 = new Vec3(motionX, motionY, motionZ);
                            //console.log(motionVec3)
                            let spawnPos = new Vec3d(entity.x + motionX * 0.02, entity.eyeY + motionY * 0.02, entity.z + motionZ * 0.02);

                            let fireTime = 0
                            //server.tell(1)
                            server.scheduleRepeatingInTicks(20, callback => {
                                callback.repeating = true
                                if (!entity.isAlive() || entity.isRemoved() || fireTime >= 4) {
                                    callback.repeating = false
                                    fireTime = 0
                                } else {

                                    fireTime += 1
                                    let proj = Block.getBlock(mortarItem.id)[
                                        'getProjectile(net.minecraft.world.level.Level,net.minecraft.world.item.ItemStack)'
                                    ](level, mortarItem); //Gets the actual projectile entity. Works only past CBC 5.5.1 for every shell. Before that, only drop mortars do (GetDropMortarProjectile)

                                    proj.setPos(spawnPos); //set the position
                                    //proj.setChargePower(2.5); //I'll be honest I forgot what this does.
                                    proj.shoot(motionX, motionY, motionZ, speed / 20, 1); //x,y,z speed, power, and I don't remember what that last one does.
                                    level.addFreshEntity(proj);
                                    level.playSound(
                                        null,
                                        entity.x,
                                        entity.y,
                                        entity.z,
                                        'createbigcannons:fire_drop_mortar',
                                        'players',
                                        5,
                                        1
                                    );
                                }
                            })

                            //server.tell(`最近的可见实体：${targetEntity}`)
                        }
                    }

                })
                break;

            case '哨戒机炮':
                //server.tell('JiPao')
                server.scheduleRepeatingInTicks(20, callback => {
                    callback.repeating = true
                    if (!entity.isAlive() || entity.isRemoved()) {
                        callback.repeating = false
                    }
                    targetEntity = getClosestVisibleEntity(entity, 50);
                })
                server.scheduleRepeatingInTicks(50, callback => {
                    callback.repeating = true
                    if (!entity.isAlive() || entity.isRemoved()) {
                        callback.repeating = false
                    }
                    //targetEntity = getClosestVisibleEntity(entity, 50);
                    //targetEntity = entity.eyePosition
                    if (targetEntity) {
                        //server.tell(targetEntity.type)

                        let speed = 200.0; // Adjust speed as needed

                        let fireTime = 0
                        //server.tell(1)
                        server.scheduleRepeatingInTicks(10, callback => {
                            callback.repeating = true
                            if (!entity.isAlive() || entity.isRemoved() || fireTime >= 3) {
                                callback.repeating = false
                                fireTime = 0
                            } else {
                                fireTime += 1
                                entity.lookAt("eyes", targetEntity.eyePosition)
                                let motionX = entity.lookAngle.x() * speed;  // Use positive x for forward
                                let motionY = entity.lookAngle.y() * speed;  // Use positive y for upward
                                let motionZ = entity.lookAngle.z() * speed;  // Use positive z for forward
                                // Create a Vec3 for the motion
                                //let motionVec3 = new Vec3(motionX, motionY, motionZ);
                                let spawnX = entity.x + motionX * 0.01
                                let spawnY = entity.eyeY + motionY * 0.01
                                let spawnZ = entity.z + motionZ * 0.01
                                let spawnPos = new Vec3d(spawnX, spawnY, spawnZ);

                                let proj = Item.getItem(autoCannonItem.id)[
                                    'getAutocannonProjectile(net.minecraft.world.item.ItemStack,net.minecraft.world.level.Level)'
                                ](autoCannonItem, level);
                                proj.setPos(spawnPos);
                                //proj.setChargePower(10);
                                proj.setTracer(true);
                                proj.setLifetime(200);
                                proj.shoot(motionX, motionY, motionZ, speed / 20, 0);
                                level.addFreshEntity(proj);
                                level.spawnParticles('campfire_cosy_smoke', true, spawnX, spawnY, spawnZ, 0, 0, 0, 2, 0.01);
                                level.spawnParticles('flame', true, spawnX, spawnY, spawnZ, 0, 0, 0, 2, 0.01);
                                level.playSound(
                                    null,
                                    entity.x,
                                    entity.y,
                                    entity.z,
                                    'pointblank:aa12',
                                    'players',
                                    3,
                                    1
                                );
                            }
                        })
                    }
                })
                break;
            case '哨戒机枪':
                //server.tell('JiQiang')
                server.scheduleRepeatingInTicks(10, callback => {
                    callback.repeating = true
                    if (!entity.isAlive() || entity.isRemoved()) {
                        callback.repeating = false
                    }
                    targetEntity = getClosestVisibleEntity(entity, 50);
                    //server.tell(entity.nbt)
                })
                server.scheduleRepeatingInTicks(4, callback => {
                    callback.repeating = true
                    if (!entity.isAlive() || entity.isRemoved()) {
                        callback.repeating = false
                    }
                    //targetEntity = entity.eyePosition
                    if (targetEntity) {
                        //server.tell(targetEntity)
                        //server.tell(targetEntity.type)
                        entity.lookAt("eyes", targetEntity.eyePosition)

                        let speed = 200.0; // Adjust speed as needed
                        // Create a Vec3 for the motion
                        let motionX = entity.lookAngle.x() * speed;  // Use positive x for forward
                        let motionY = entity.lookAngle.y() * speed;  // Use positive y for upward
                        let motionZ = entity.lookAngle.z() * speed;  // Use positive z for forward

                        let spawnX = entity.x + motionX * 0.01
                        let spawnY = entity.eyeY + motionY * 0.01
                        let spawnZ = entity.z + motionZ * 0.01
                        let spawnPos = new Vec3d(spawnX, spawnY, spawnZ);
                        //console.log(autoCannonItem)
                        let proj = Item.getItem(machineGunItem.id)[
                            'getAutocannonProjectile(net.minecraft.world.item.ItemStack,net.minecraft.world.level.Level)'
                        ](machineGunItem, level);
                        proj.setPos(spawnPos);
                        //proj.setChargePower(10);
                        proj.setTracer(true);
                        proj.setLifetime(200);
                        proj.shoot(motionX, motionY, motionZ, speed / 20, 0.2);
                        level.addFreshEntity(proj);
                        level.spawnParticles('flame', true, spawnX, spawnY, spawnZ, 0, 0, 0, 2, 0.01);
                        level.spawnParticles('smoke', true, spawnX, spawnY, spawnZ, 0, 0, 0, 2, 0.01);
                        level.playSound(
                            null,
                            entity.x,
                            entity.y,
                            entity.z,
                            'createbigcannons:fire_machine_gun',
                            'players',
                            3,
                            1
                        );
                        //server.tell(`最近的可见实体：${targetEntity}`)
                    }
                })
                break;
            case '哨戒加特林':
                //server.tell('JiQiang')
                server.scheduleRepeatingInTicks(5, callback => {
                    callback.repeating = true
                    if (!entity.isAlive() || entity.isRemoved()) {
                        callback.repeating = false
                    }
                    targetEntity = getClosestVisibleEntity(entity, 50);
                    //server.tell(entity.nbt)
                })
                server.scheduleRepeatingInTicks(1, callback => {
                    callback.repeating = true
                    if (!entity.isAlive() || entity.isRemoved()) {
                        callback.repeating = false
                    }
                    //targetEntity = entity.eyePosition
                    if (targetEntity) {
                        //server.tell(targetEntity)
                        //server.tell(targetEntity.type)
                        entity.lookAt("eyes", targetEntity.eyePosition)

                        let speed = 200.0; // Adjust speed as needed
                        let motionX = entity.lookAngle.x() * speed;  // Use positive x for forward
                        let motionY = entity.lookAngle.y() * speed;  // Use positive y for upward
                        let motionZ = entity.lookAngle.z() * speed;  // Use positive z for forward
                        // Create a Vec3 for the motion
                        //let motionVec3 = new Vec3(motionX, motionY, motionZ);
                        let spawnX = entity.x + motionX * 0.01
                        let spawnY = entity.eyeY + motionY * 0.01
                        let spawnZ = entity.z + motionZ * 0.01
                        let spawnPos = new Vec3d(spawnX, spawnY, spawnZ);
                        //console.log(autoCannonItem)
                        let proj = Item.getItem(machineGunItem.id)[
                            'getAutocannonProjectile(net.minecraft.world.item.ItemStack,net.minecraft.world.level.Level)'
                        ](machineGunItem, level);
                        proj.setPos(spawnPos);
                        //proj.setChargePower(10);
                        proj.setTracer(true);
                        proj.setLifetime(200);
                        proj.shoot(motionX, motionY, motionZ, speed / 20, 0);
                        level.addFreshEntity(proj);
                        level.spawnParticles('flame', true, spawnX, spawnY, spawnZ, 0, 0, 0, 2, 0.01);
                        level.spawnParticles('smoke', true, spawnX, spawnY, spawnZ, 0, 0, 0, 2, 0.01);
                        level.playSound(
                            null,
                            entity.x,
                            entity.y,
                            entity.z,
                            'createbigcannons:fire_machine_gun',
                            'players',
                            3,
                            1
                        );
                        //server.tell(`最近的可见实体：${targetEntity}`)
                    }
                })
                break;
            case '哨戒火箭炮':
                server.scheduleRepeatingInTicks(20, callback => {
                    callback.repeating = true
                    if (!entity.isAlive() || entity.isRemoved()) {
                        callback.repeating = false
                    }
                    targetEntity = getClosestVisibleEntity(entity, 50);
                    //server.tell(entity.nbt)
                    if (targetEntity) {

                        //server.tell(targetEntity)
                        //server.tell(targetEntity.type)
                        entity.lookAt("eyes", targetEntity.eyePosition)

                        let speed = 4.0; // Adjust speed as needed
                        let motionX = entity.lookAngle.x() * speed;  // Use positive x for forward
                        let motionY = entity.lookAngle.y() * speed;  // Use positive y for upward
                        let motionZ = entity.lookAngle.z() * speed;  // Use positive z for forward
                        // Create a Vec3 for the motion
                        let motionVec3 = new Vec3(motionX, motionY + 0.1, motionZ);
                        let spawnX = entity.x + motionX * 0.01
                        let spawnY = entity.eyeY + motionY * 0.01
                        let spawnZ = entity.z + motionZ * 0.01
                        let spawnPos = new Vec3d(spawnX, spawnY, spawnZ);
                        //console.log(autoCannonItem)
                        let rocket = level.createEntity('xtraarrows:netherite_explosive_arrow');
                        // 合并NBT设置爆炸等级
                        //rocket.mergeNbt({ ExplosionPower: 2 })
                        rocket.setPos(spawnPos)
                        rocket.setDeltaMovement(motionVec3)
                        rocket.spawn();
                        drawMultiParticle('campfire_cosy_smoke', spawnX, spawnY, spawnZ, motionX * 0.01, motionY * 0.01, motionZ * 0.01, 15, 8, 8, level, server)
                        //level.spawnParticles('campfire_cosy_smoke', true, spawnX, spawnY, spawnZ, motionX * 0.01, motionY * 0.01, motionZ * 0.01, 0, 20);
                        drawMultiParticle('flame', spawnX, spawnY, spawnZ, motionX * 0.01, motionY * 0.01, motionZ * 0.01, 20, 12, 12, level, server)
                        level.playSound(
                            null,
                            entity.x,
                            entity.y,
                            entity.z,
                            'pointblank:at4',
                            'players',
                            3,
                            1
                        );
                        //server.tell(`最近的可见实体：${targetEntity}`)
                    }
                })
                break;
            default:
                //server.tell(1)
                /* server.scheduleRepeatingInTicks(10, callback => {
                    callback.repeating = true
                    if (!entity.isAlive() || entity.isRemoved()) {
                        callback.repeating = false
                    }
                    const targetEntity = getClosestVisibleEntity(entity, 20);
                    //targetEntity = entity.eyePosition
                    if (targetEntity) {
                        //server.tell(targetEntity.type)
                        entity.lookAt("eyes", targetEntity.eyePosition)

                        let speed = 4.0; // Adjust speed as needed
                        let motionX = entity.lookAngle.x() * speed;  // Use positive x for forward
                        let motionY = entity.lookAngle.y() * speed;  // Use positive y for upward
                        let motionZ = entity.lookAngle.z() * speed;  // Use positive z for forward
                        // Create a Vec3 for the motion
                        let motionVec3 = new Vec3(motionX, motionY, motionZ);
                        let spawnPos = new Vec3d(entity.x + motionX * 0.02, entity.eyeY + motionY * 0.02, entity.z + motionZ * 0.02);
                        let arrow = entity.level.createEntity('minecraft:arrow')
                        arrow.setOwner(entity)
                        arrow.setPos(spawnPos)
                        arrow.setDeltaMovement(motionVec3)
                        arrow.spawn()
                        //server.tell(`最近的可见实体：${targetEntity}`)
                    }
                }) */
                break;
        }

    }

})

function Newton(x0, y0, z0, x1, y1, z1, v0, l) {
    let x = x1 - x0
    let y = y1 - y0
    let z = z1 - z0
    let w = Math.sqrt(x * x + z * z)
    let h = 1

    let xt2 = Math.acos(w / (5 * v0 + l)) - 0.01
    let xt1 = 0
    try {

        while (Math.abs(xt2 - xt1) > 0.000001) {
            //console.log(xt2)
            //console.log(xt1)
            xt1 = xt2
            let secx = 1 / Math.cos(xt1)
            let tanx = Math.tan(xt1)
            let f = 100 * w * secx / v0 + w * tanx + 500 * Math.log(1 - (w * secx - l) / (5 * v0)) - y - 100 * l / v0 + h
            let f1 = w * secx * (secx + 100 * tanx / v0 - (500 * tanx) / (5 * v0 - w * secx + l))
            xt2 = xt1 - f / f1
        }

    } catch (error) { }

    let Angle = xt2 * 180 / pie
    //console.log(Angle)
    /* 
        xt2 = -pie / 6
        xt1 = 0
        try {
    
            while (Math.abs(xt2 - xt1) > 0.000001) {
                xt1 = xt2
                let secx = 1 / Math.cos(xt1)
                let tanx = Math.tan(xt1)
                let f = 100 * w * secx / v0 + w * tanx + 500 * Math.log(1 - (w * secx - l) / (5 * v0)) - y - 100 * l / v0 + h
                let f1 = w * secx * (secx + 100 * tanx / v0 - (500 * tanx) / (5 * v0 - w * secx + l))
                xt2 = xt1 - f / f1
            }
    
        } catch (error) { }
        let Angle2 = xt2 * 180 / pie */

    let yaw = -Math.atan(x / z) * 180 / pie
    if (z < 0) {
        yaw -= 180
    }
    return [yaw, Angle]
}
