const maxNukeTick = 200

ItemEvents.rightClicked('create:blaze_cake', event => {
    const { player, item, server } = event
    if (item == Item.of('create:blaze_cake').withNBT({
        display: {
            Name: '["",{"text":"单兵云爆弹","italic":false,"color":"aqua"}]',
            Lore: ['["",{"text":"右键使用激活云爆弹，并开始","italic":false,"color":"gray"},{"text":"不可中断的10秒","italic":false,"color":"red"},{"text":"倒计时，倒计时结束时产生巨大爆炸。","italic":false,"color":"gray"}]', '["",{"text":"右键使用已激活的云爆弹以放下炸弹，右击放下的炸弹实体可以将其拾取，","italic":false,"color":"gray"},{"text":"击杀炸弹实体可以阻止爆炸。","italic":false,"color":"gold"}]']
        }
    })) {
        let serverPlayer = /** @type {Internal.ServerPlayer} */(player)
        let playerName = serverPlayer.username

        serverPlayer.give(Item.of('create:creative_blaze_cake').withNBT({
            display: {
                Name: '["",{"text":"已激活的单兵云爆弹","italic":false,"color":"red"}]',
                Lore: ['["",{"text":"右键使用已激活的云爆弹以放下炸弹，右击放下的炸弹可以将其拾取，","italic":false,"color":"gray"},{"text":"击杀炸弹实体可以阻止爆炸。","italic":false,"color":"gold"}]', '["",{"text":"快跑！求你了，快跑！快跑！！","italic":false,"color":"red"}]']
            }
        }))
        item.shrink(1)
        let nukeTick = readPlayerNukeTick(serverPlayer)
        nukeTick.push(maxNukeTick + 1)
        if (!serverPlayer.persistentData['NukeCounting']) {
            //server.tell(nukeTick)
            serverPlayer.persistentData['NukeCounting'] = true
            //nukeTick.push(200)
            server.scheduleRepeatingInTicks(1, callback => {
                callback.repeating = true
                //server.tell(nukeTick)
                //server.tell(nukeTick.length)
                if (!serverPlayer.persistentData['NukeCounting'] || nukeTick.length == 0) {
                    callback.repeating = false
                    serverPlayer.persistentData['NukeCounting'] = false
                }
                for (let i = 0; i < nukeTick.length; i++) {
                    nukeTick[i] -= 1
                    server.runCommandSilent(`playsound minecraft:block.note_block.harp block @a ${serverPlayer.x} ${serverPlayer.y} ${serverPlayer.z} 2 ${2 - nukeTick[i] / maxNukeTick * 2} 0.8`)
                    server.runCommandSilent(`playsound minecraft:block.note_block.harp block @a ${serverPlayer.x} ${serverPlayer.y} ${serverPlayer.z} 2 ${1.7 - nukeTick[i] / maxNukeTick * 2} 0.8`)
                    //event.level.playSound(null, serverPlayer.x, serverPlayer.y, serverPlayer.z, "minecraft:block.note_block.harp", 'blocks', Math.floor(2 - nukeTick / maxNukeTick * 2), 1)
                    //server.tell(nukeTick[i] + 'player')
                    if (nukeTick[i] <= 0) {
                        let explosion = serverPlayer.block.createExplosion()
                        //explosion.exploder(player)
                        explosion.strength(20.0);
                        explosion.explosionMode('mob')
                        //explosion.causesFire(true);
                        // 引爆
                        server.runCommandSilent(`particle createbigcannons:shell_explosion_cloud 20 false ${explosion.x} ${explosion.y} ${explosion.z} 0 0 0 0 5 force`)
                        server.runCommandSilent(`particle minecraft:explosion ${explosion.x} ${explosion.y} ${explosion.z} 10 5 10 35 100 force`)
                        server.runCommandSilent(`playsound createbigcannons:shell_explosion block @a ${explosion.x} ${explosion.y} ${explosion.z} 5 1 0.8`)
                        server.runCommandSilent(`clear ${playerName} create:creative_blaze_cake{display: {Name: '["",{"text":"已激活的单兵云爆弹","italic":false,"color":"red"}]',Lore: ['["",{"text":"右键使用已激活的云爆弹以放下炸弹，右击放下的炸弹可以将其拾取，","italic":false,"color":"gray"},{"text":"击杀炸弹实体可以阻止爆炸。","italic":false,"color":"gold"}]', '["",{"text":"快跑！求你了，快跑！快跑！！","italic":false,"color":"red"}]']}} 1`)
                        explosion.explode();

                        delete nukeTick[i];
                    }
                    if (nukeTick[i] % 20 == 0) {
                        server.runCommandSilent(`title ${playerName} title ${nukeTick[i] / 20}`)
                    }
                }
            })
        }
    }

})

//玩家死亡生成一个携带炸弹的猪
EntityEvents.death('player', event => {
    const { player, server } = event
    let serverPlayer = /** @type {Internal.ServerPlayer} */(player)
    let playerName = serverPlayer.username
    server.runCommandSilent(`clear ${playerName} create:creative_blaze_cake{display: {Name: '["",{"text":"已激活的单兵云爆弹","italic":false,"color":"red"}]',Lore: ['["",{"text":"右键使用已激活的云爆弹以放下炸弹，右击放下的炸弹可以将其拾取，","italic":false,"color":"gray"},{"text":"击杀炸弹实体可以阻止爆炸。","italic":false,"color":"gold"}]', '["",{"text":"快跑！求你了，快跑！快跑！！","italic":false,"color":"red"}]']}}`)
    if (serverPlayer.persistentData['NukeTick'] && serverPlayer.persistentData['NukeTick'].length > 0) {
        let nukePig = serverPlayer.block.createEntity('pig')
        nukePig.persistentData['NukeCounting'] = serverPlayer.persistentData.get('NukeCounting').copy()
        nukePig.persistentData['NukeTick'] = []
        nukePig.persistentData['NukeTick'].push(serverPlayer.persistentData['NukeTick'][0])
        nukePig.hurtMarked = true
        nukePig.mergeNbt({
            CustomName: '[{"text":"云爆弹","color":"light_purple"}]', CustomNameVisible: true, Health: 100, Silent: true, Attributes: [{ Name: "generic.knockback_resistance", Base: 1 }, { Name: "generic.max_health", Base: 100 }]
        })
        delete serverPlayer.persistentData['NukeTick']
        delete serverPlayer.persistentData['NukeCounting']
        nukePig.spawn()


        let nukeTick = readPlayerNukeTick(nukePig)
        //item.shrink(1)
        server.scheduleRepeatingInTicks(1, callback => {
            callback.repeating = true
            //server.tell(nukeTick)
            //server.tell(nuke)
            if (nukeTick.length == 0 || nukePig.removed) {
                callback.repeating = false
                nukePig.persistentData['NukeCounting'] = false
            }
            for (let i = 0; i < nukeTick.length; i++) {

                nukeTick[i] -= 1
                server.runCommandSilent(`playsound minecraft:block.note_block.harp block @a ${nukePig.x} ${nukePig.y} ${nukePig.z} 2 ${2 - nukeTick[i] / maxNukeTick * 2} 0.8`)
                server.runCommandSilent(`playsound minecraft:block.note_block.harp block @a ${nukePig.x} ${nukePig.y} ${nukePig.z} 2 ${1.7 - nukeTick[i] / maxNukeTick * 2} 0.8`)
                //server.tell(nukeTick[i] + 'pig')
                if (nukeTick[i] <= 0) {
                    let explosion = nukePig.block.createExplosion()
                    //explosion.exploder(serverPlayer)
                    explosion.strength(20.0)
                    explosion.explosionMode('mob');
                    //explosion.causesFire(true);
                    // 引爆
                    explosion.explode();
                    server.runCommandSilent(`particle createbigcannons:shell_explosion_cloud 20 false ${explosion.x} ${explosion.y} ${explosion.z} 0 0 0 0 5 force`)
                    server.runCommandSilent(`particle minecraft:explosion ${explosion.x} ${explosion.y} ${explosion.z} 10 5 10 35 100 force`)
                    server.runCommandSilent(`playsound createbigcannons:shell_explosion block @a ${explosion.x} ${explosion.y} ${explosion.z} 5 1 0.8`)
                    delete nukeTick[i];
                }
            }
        })
    }
})

//玩家与猪交互获得物品，并将炸弹转移回玩家

ItemEvents.entityInteracted(event => {
    const { player, target, server } = event
    //server.tell(target.persistentData)
    if (target.persistentData['NukeTick'] && target.persistentData['NukeTick'].length > 0) {
        let serverPlayer = /** @type {Internal.ServerPlayer} */(player)
        let playerName = serverPlayer.username

        let nukeTick = readPlayerNukeTick(serverPlayer)
        for (let i = 0; i < target.persistentData['NukeTick'].length; i++) {
            nukeTick.push(target.persistentData['NukeTick'][i])
            serverPlayer.give(Item.of('create:creative_blaze_cake').withNBT({
                display: {
                    Name: '["",{"text":"已激活的单兵云爆弹","italic":false,"color":"red"}]',
                    Lore: ['["",{"text":"右键使用已激活的云爆弹以放下炸弹，右击放下的炸弹可以将其拾取，","italic":false,"color":"gray"},{"text":"击杀炸弹实体可以阻止爆炸。","italic":false,"color":"gold"}]', '["",{"text":"快跑！求你了，快跑！快跑！！","italic":false,"color":"red"}]']
                }
            }))
        }

        if (!serverPlayer.persistentData['NukeCounting']) {
            //server.tell(nukeTick)
            serverPlayer.persistentData['NukeCounting'] = true
            //nukeTick.push(200)
            server.scheduleRepeatingInTicks(1, callback => {
                callback.repeating = true
                //server.tell(nukeTick)
                //server.tell(nukeTick.length)
                if (!serverPlayer.persistentData['NukeCounting'] || nukeTick.length == 0) {
                    callback.repeating = false
                    serverPlayer.persistentData['NukeCounting'] = false
                }
                for (let i = 0; i < nukeTick.length; i++) {

                    nukeTick[i] -= 1
                    server.runCommandSilent(`playsound minecraft:block.note_block.harp block @a ${serverPlayer.x} ${serverPlayer.y} ${serverPlayer.z} 2 ${2 - nukeTick[i] / maxNukeTick * 2} 0.8`)
                    server.runCommandSilent(`playsound minecraft:block.note_block.harp block @a ${serverPlayer.x} ${serverPlayer.y} ${serverPlayer.z} 2 ${1.7 - nukeTick[i] / maxNukeTick * 2} 0.8`)
                    //server.tell(nukeTick[i] + 'player')
                    if (nukeTick[i] <= 0) {
                        let explosion = serverPlayer.block.createExplosion()
                        //explosion.exploder(player)
                        explosion.strength(20.0);
                        explosion.explosionMode('mob')
                        //explosion.causesFire(true);
                        // 引爆
                        server.runCommandSilent(`particle createbigcannons:shell_explosion_cloud 20 false ${explosion.x} ${explosion.y} ${explosion.z} 0 0 0 0 5 force`)
                        server.runCommandSilent(`particle minecraft:explosion ${explosion.x} ${explosion.y} ${explosion.z} 10 5 10 35 100 force`)
                        server.runCommandSilent(`playsound createbigcannons:shell_explosion block @a ${explosion.x} ${explosion.y} ${explosion.z} 5 1 0.8`)
                        server.runCommandSilent(`clear ${playerName} create:creative_blaze_cake{display: {Name: '["",{"text":"已激活的单兵云爆弹","italic":false,"color":"red"}]',Lore: ['["",{"text":"右键使用已激活的云爆弹以放下炸弹，右击放下的炸弹可以将其拾取，","italic":false,"color":"gray"},{"text":"击杀炸弹实体可以阻止爆炸。","italic":false,"color":"gold"}]', '["",{"text":"快跑！求你了，快跑！快跑！！","italic":false,"color":"red"}]']}} 1`)
                        explosion.explode();

                        delete nukeTick[i];
                    }
                    if (nukeTick[i] % 20 == 0) {
                        server.runCommandSilent(`title ${playerName} title ${nukeTick[i] / 20}`)
                    }
                }
            })
        }
        delete target.persistentData['NukeTick']
        delete target.persistentData['NukeCounting']
        target.kill()
    }
})

//玩家使用物品生成一个携带炸弹的猪
ItemEvents.rightClicked('create:creative_blaze_cake', event => {
    const { player, item, server } = event
    if (item.withNBT({
        display: {
            Name: '["",{"text":"已激活的单兵云爆弹","italic":false,"color":"red"}]',
            Lore: ['["",{"text":"右键使用已激活的云爆弹以放下炸弹，右击放下的炸弹可以将其拾取，","italic":false,"color":"gray"},{"text":"击杀炸弹实体可以阻止爆炸。","italic":false,"color":"gold"}]', '["",{"text":"快跑！求你了，快跑！快跑！！","italic":false,"color":"red"}]']
        }
    })) {
        let serverPlayer = /** @type {Internal.ServerPlayer} */(player)
        if (serverPlayer.persistentData['NukeTick'] && serverPlayer.persistentData['NukeTick'].length > 0) {
            let nukePig = serverPlayer.block.createEntity('pig')
            nukePig.persistentData['NukeCounting'] = serverPlayer.persistentData.get('NukeCounting').copy()
            nukePig.persistentData['NukeTick'] = []
            nukePig.persistentData['NukeTick'].push(serverPlayer.persistentData['NukeTick'][0])
            nukePig.mergeNbt({
                CustomName: '[{"text":"云爆弹","color":"light_purple"}]', CustomNameVisible: true, Health: 100, Silent: true, Attributes: [{ Name: "generic.knockback_resistance", Base: 1 }, { Name: "generic.max_health", Base: 100 }]
            })
            delete serverPlayer.persistentData['NukeTick'][0]
            delete serverPlayer.persistentData['NukeCounting'][0]
            nukePig.spawn()

            let nukeTick = readPlayerNukeTick(nukePig)
            item.shrink(1)
            server.scheduleRepeatingInTicks(1, callback => {
                callback.repeating = true
                //server.tell(nukePig)
                //server.tell(nuke)
                if (nukeTick.length == 0 || nukePig.removed) {
                    callback.repeating = false
                    nukePig.persistentData['NukeCounting'] = false
                }
                for (let i = 0; i < nukeTick.length; i++) {

                    nukeTick[i] -= 1
                    server.runCommandSilent(`playsound minecraft:block.note_block.harp block @a ${nukePig.x} ${nukePig.y} ${nukePig.z} 2 ${2 - nukeTick[i] / maxNukeTick * 2} 0.8`)
                    server.runCommandSilent(`playsound minecraft:block.note_block.harp block @a ${nukePig.x} ${nukePig.y} ${nukePig.z} 2 ${1.7 - nukeTick[i] / maxNukeTick * 2} 0.8`)
                    //server.tell(nukeTick[i] + 'pig')
                    if (nukeTick[i] <= 0) {
                        let explosion = nukePig.block.createExplosion()
                        //explosion.exploder(serverPlayer)
                        explosion.strength(20.0)
                        explosion.explosionMode('mob');
                        //explosion.causesFire(true);
                        // 引爆
                        explosion.explode();
                        server.runCommandSilent(`particle createbigcannons:shell_explosion_cloud 20 false ${explosion.x} ${explosion.y} ${explosion.z} 0 0 0 0 5 force`)
                        server.runCommandSilent(`particle minecraft:explosion ${explosion.x} ${explosion.y} ${explosion.z} 10 5 10 35 100 force`)
                        server.runCommandSilent(`playsound createbigcannons:shell_explosion block @a ${explosion.x} ${explosion.y} ${explosion.z} 5 1 0.8`)
                        delete nukeTick[i];
                    }
                }

            })
        }
    }
})

ItemEvents.dropped('create:creative_blaze_cake', event => {
    const { player, item, server } = event
    if (item.withNBT({
        display: {
            Name: '["",{"text":"已激活的单兵云爆弹","italic":false,"color":"red"}]',
            Lore: ['["",{"text":"右键使用已激活的云爆弹以放下炸弹，右击放下的炸弹可以将其拾取，","italic":false,"color":"gray"},{"text":"击杀炸弹实体可以阻止爆炸。","italic":false,"color":"gold"}]', '["",{"text":"快跑！求你了，快跑！快跑！！","italic":false,"color":"red"}]']
        }
    })) {
        let serverPlayer = /** @type {Internal.ServerPlayer} */(player)
        if (serverPlayer.persistentData['NukeTick'] && serverPlayer.persistentData['NukeTick'].length > 0) {
            let nukePig = serverPlayer.block.createEntity('pig')
            nukePig.persistentData['NukeCounting'] = serverPlayer.persistentData.get('NukeCounting').copy()
            nukePig.persistentData['NukeTick'] = []
            nukePig.persistentData['NukeTick'].push(serverPlayer.persistentData['NukeTick'][0])
            nukePig.mergeNbt({
                CustomName: '[{"text":"云爆弹","color":"light_purple"}]', CustomNameVisible: true, Health: 100, Silent: true, Attributes: [{ Name: "generic.knockback_resistance", Base: 1 }, { Name: "generic.max_health", Base: 100 }]
            })
            delete serverPlayer.persistentData['NukeTick'][0]
            delete serverPlayer.persistentData['NukeCounting'][0]
            nukePig.spawn()

            let nukeTick = readPlayerNukeTick(nukePig)
            item.shrink(1)

            server.scheduleRepeatingInTicks(1, callback => {
                callback.repeating = true
                //server.tell(nukePig)
                //server.tell(nuke)
                if (nukeTick.length == 0 || nukePig.removed) {
                    callback.repeating = false
                    nukePig.persistentData['NukeCounting'] = false
                }
                for (let i = 0; i < nukeTick.length; i++) {

                    nukeTick[i] -= 1
                    server.runCommandSilent(`playsound minecraft:block.note_block.harp block @a ${nukePig.x} ${nukePig.y} ${nukePig.z} 2 ${2 - nukeTick[i] / maxNukeTick * 2} 0.8`)
                    server.runCommandSilent(`playsound minecraft:block.note_block.harp block @a ${nukePig.x} ${nukePig.y} ${nukePig.z} 2 ${1.7 - nukeTick[i] / maxNukeTick * 2} 0.8`)
                    //server.tell(nukeTick[i] + 'pig')
                    if (nukeTick[i] <= 0) {
                        let explosion = nukePig.block.createExplosion()
                        //explosion.exploder(serverPlayer)
                        explosion.strength(20.0)
                        explosion.explosionMode('mob');
                        //explosion.causesFire(true);
                        // 引爆
                        explosion.explode();
                        server.runCommandSilent(`particle createbigcannons:shell_explosion_cloud 20 false ${explosion.x} ${explosion.y} ${explosion.z} 0 0 0 0 5 force`)
                        server.runCommandSilent(`particle minecraft:explosion ${explosion.x} ${explosion.y} ${explosion.z} 10 5 10 35 100 force`)
                        server.runCommandSilent(`playsound createbigcannons:shell_explosion block @a ${explosion.x} ${explosion.y} ${explosion.z} 5 1 0.8`)
                        delete nukeTick[i];
                    }
                }

            })
            event.cancel()
        }
    }
})

function readPlayerNukeTick(player) {
    if (!player.persistentData['NukeTick']) {
        player.persistentData['NukeTick'] = []
    }
    return player.persistentData.NukeTick
}

