EntityEvents.death('player', event => {
    const { player, server } = event
    let serverPlayer = /** @type {Internal.ServerPlayer} */(player)
    //let playerName = serverPlayer.username
    if (serverPlayer.tags.contains('Explode')) {
        let explosion = serverPlayer.block.createExplosion()
        server.scheduleInTicks(20, callback => {

            explosion.exploder(player)
            explosion.strength(6.0);
            explosion.explosionMode('mob')
            //explosion.causesFire(true);
            // 引爆
            server.runCommandSilent(`particle createbigcannons:shell_explosion_cloud 3 false ${explosion.x} ${explosion.y} ${explosion.z} 0 0 0 0 5 force`)
            explosion.explode();
            //server.tell(2)
            //callback.repeating = true
            //callback.wait(1)
            //server.tell(3)
        })
    }
    //serverPlayer.addTag()
})
