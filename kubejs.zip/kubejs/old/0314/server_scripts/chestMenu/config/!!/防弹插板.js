const maxBulletproof = 3

ItemEvents.rightClicked('create:sturdy_sheet', event => {
    let { player, item, server } = event
    let serverPlayer = /** @type {Internal.ServerPlayer} */(player)
    let playerName = serverPlayer.username
    let playerCurrentShield = serverPlayer.getAbsorptionAmount()
    let playerBulletproof = getPlayerBulletproof(player)
    if (item.nbt['BulletproofCount']) {
        let bulletproofCount = item.nbt['BulletproofCount']
        //persistent刷新插板状态
        //server.tell(playerBulletproof)
        KJSsort(playerBulletproof)
        //server.tell(playerBulletproof)
        let playerSumedShield = sum(playerBulletproof)
        let damage = playerSumedShield - playerCurrentShield
        for (let i = 0; i < playerBulletproof.length; i++) {
            //server.tell(damage)
            if (damage >= playerBulletproof[i]) {
                damage -= playerBulletproof[i]
                playerBulletproof[i] = 0
            } else {
                playerBulletproof[i] -= damage
                //damage = 0
                break;
            }
        }
        let length = playerBulletproof.length
        let fixedCount = []
        for (let i = 0; i < length; i++) {
            //server.tell(length)
            if (playerBulletproof[0] <= 0) {
                delete playerBulletproof[0]
            }
        }
        for (let i = 0; i < playerBulletproof.length; i++) {
            fixedCount.push(playerBulletproof[i].toFixed(1))
        }
        //server.tell(playerBulletproof)
        if (playerBulletproof.length < maxBulletproof) {

            serverPlayer.addItemCooldown(item, 80)
            item.shrink(1)
            serverPlayer.potionEffects.add('slowness', 60, 2, false, true)
            server.runCommandSilent(`title ${playerName} title " "`)
            server.runCommandSilent(`title ${playerName} subtitle ["",{"text":"正在使用防弹插板，当前插板状态：${bulletproofCount}->","color":"gray"},{"text":"${'[' + fixedCount.toString().replace(/,/g, ' | ') + ']'}","color":"red"}]`)
            serverPlayer.playNotifySound('entity.armor_stand.break', 'ambient', 1, 1)
            server.scheduleInTicks(20, callback => {
                serverPlayer.playNotifySound('item.armor.equip_leather', 'ambient', 1, 0.5)
                server.scheduleInTicks(8, callback => {
                    serverPlayer.playNotifySound('item.bucket.empty_powder_snow', 'ambient', 1, 0.7)
                    server.scheduleInTicks(35, callback => {
                        serverPlayer.playNotifySound('item.armor.equip_iron', 'ambient', 1, 1)
                        serverPlayer.setAbsorptionAmount(serverPlayer.getAbsorptionAmount() + bulletproofCount)
                        playerBulletproof.push(bulletproofCount)
                    })
                })
            })

        } else if (playerBulletproof[0] < bulletproofCount) {

            serverPlayer.addItemCooldown(item, 80)
            item.shrink(1)
            serverPlayer.potionEffects.add('slowness', 60, 2, false, true)
            server.runCommandSilent(`title ${playerName} title " "`)
            server.runCommandSilent(`title ${playerName} subtitle ["",{"text":"正在更换防弹插板，当前插板状态：${bulletproofCount}->","color":"gray"},{"text":"${'[' + fixedCount.toString().replace(/,/g, ' | ') + ']'}","color":"red"}]`)
            serverPlayer.playNotifySound('entity.armor_stand.break', 'ambient', 1, 1)
            server.scheduleInTicks(20, callback => {
                serverPlayer.playNotifySound('item.armor.equip_leather', 'ambient', 1, 0.5)
                server.scheduleInTicks(8, callback => {
                    serverPlayer.playNotifySound('item.bucket.empty_powder_snow', 'ambient', 1, 0.7)
                    server.scheduleInTicks(35, callback => {
                        serverPlayer.playNotifySound('item.armor.equip_iron', 'ambient', 1, 1)
                        serverPlayer.setAbsorptionAmount(serverPlayer.getAbsorptionAmount() + bulletproofCount - playerBulletproof[0])
                        playerBulletproof[0] = bulletproofCount
                    })
                })
            })

        } else {
            server.runCommandSilent(`title ${playerName} title " "`)
            server.runCommandSilent(`title ${playerName} subtitle ["",{"text":"插板已满或者没有可替换的插板","color":"gray"},{"text":"${'[' + fixedCount.toString().replace(/,/g, ' | ') + ']'}","color":"red"}]`)
        }
        //server.tell(playerBulletproof)

        //排序之后第一个插板的数值最小，如果第一个小于插板值就换掉
    }
})


function getPlayerBulletproof(player) {
    if (!player.persistentData['Bulletproof']) {
        player.persistentData['Bulletproof'] = []
    }
    return player.persistentData.Bulletproof
}

function sum(arr) {
    var s = 0;
    for (var i = 0; i < arr.length; i++) {
        s += arr[i];
    }
    return s;
}

function KJSsort(arr) {
    for (let i = 0; i < arr.length; i++) {
        for (let j = 0; j < arr.length - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                let num = arr[j]
                arr[j] = arr[j + 1]
                arr[j + 1] = num
            }
        }
    }
    return arr
}
