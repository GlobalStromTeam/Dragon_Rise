/* const menuItemsBLUETP = {
    description: {
        index: "menuItemsBLUETP",
        type: "none",
        title: Text.black('『盟军传送菜单』'),
        leftButton: {
            icon: 'createdeco:decal_left',
            iconNbt: {
                display: {
                    Name: '{"text":"退出","color":"red","italic":"false"}',
                    Lore: ['{"text":"按esc有一样的效果","color":"gray","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "exit",
            }
        },

    },
    spawnPoint1: {
        index: "spawnPoint1",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点1","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 1,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['gamemode survival @s',
                'effect give @s minecraft:saturation 10 19', 'effect give @s minecraft:resistance 8 19',
                'effect give @s minecraft:absorption 3600 1 true',
                'execute if score 地图 Maps matches 0 run spreadplayers -956 -748 0 15 true @s',
                'execute if score 地图 Maps matches 1 run spreadplayers 1612 253 0 5 true @s',
                'execute if score 地图 Maps matches 2 run spreadplayers 1232 -383 0 8 true @s',
                'execute if score 地图 Maps matches 3 run spreadplayers -366 -2688 0 5 true @s',
                'execute if score 地图 Maps matches 4 run spreadplayers 1025 -1992 0 5 true @s',
                'clear @s minecraft:clock',
                'clear @s recovery_compass'
            ]
        }
    },
    spawnPoint2: {
        index: "spawnPoint2",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点2","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 3,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score 地图 Maps matches ..2 run gamemode survival @s',
                'effect give @s minecraft:saturation 10 19', 'effect give @s minecraft:resistance 8 19',
                'effect give @s minecraft:absorption 3600 1 true',
                'execute if score 地图 Maps matches 0 run spreadplayers -956 -648 0 15 true @s',
                'execute if score 地图 Maps matches 1 run spreadplayers 1605 387 0 5 true @s',
                'execute if score 地图 Maps matches 2 run spreadplayers 1549 -379 0 8 true @s',
                'execute if score 地图 Maps matches 3 run title "这个地图不存在出生点2"',
                'execute if score 地图 Maps matches 4 run title "这个地图不存在出生点2"',
                'execute if score 地图 Maps matches ..2 run clear @s minecraft:clock',
                'execute if score 地图 Maps matches ..2 run clear @s recovery_compass'
            ]
        }
    },
    spawnPoint3: {
        index: "spawnPoint3",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点3","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 5,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score 地图 Maps matches ..2 run gamemode survival @s',
                'effect give @s minecraft:saturation 10 19', 'effect give @s minecraft:resistance 8 19',
                'effect give @s minecraft:absorption 3600 1 true',
                'execute if score 地图 Maps matches 0 run spreadplayers -956 -528 0 15 true @s',
                'execute if score 地图 Maps matches 1 run spreadplayers 1546 521 0 5 true @s',
                'execute if score 地图 Maps matches 2 run spreadplayers 1735 -379 0 8 true @s',
                'execute if score 地图 Maps matches 3 run title @s title "这个地图不存在出生点3"',
                'execute if score 地图 Maps matches 4 run title @s title "这个地图不存在出生点3"',
                'execute if score 地图 Maps matches ..2 run clear @s minecraft:clock',
                'execute if score 地图 Maps matches ..2 run clear @s recovery_compass'
            ]
        }
    },
    PointA: {
        index: "PointA",
        icon: "minecraft:light_blue_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点A","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'bo', Color: 3 }] }
        },
        location: {
            x: 1,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'execute if score A点 DominationHide matches 0 run gamemode survival @s',
                'effect give @s minecraft:saturation 10 19',
                'effect give @s minecraft:absorption 3600 1 true',
                'execute if score 地图 Maps matches 0 if score A点 DominationHide matches 0 run tp @s -374 3 -566',
                'execute if score 地图 Maps matches 1 if score A点 DominationHide matches 0 run tp @s 872 13 358',
                'execute if score 地图 Maps matches 2 if score A点 DominationHide matches 0 run tp @s 1688 6 -584',
                'execute if score 地图 Maps matches 3 if score A点 DominationHide matches 0 run tp @s -381 240 -2606',
                'execute if score 地图 Maps matches 4 if score A点 DominationHide matches 0 run tp @s 1049 -13 -2118',
                'execute if score A点 DominationHide matches 0 run clear @s minecraft:clock',
                'execute if score A点 DominationHide matches 0 run clear @s minecraft:recovery_compass'
            ]
        }
    },
    PointB: {
        index: "PointB",
        icon: "minecraft:light_blue_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点B","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'cbo', Color: 3 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'bo', Color: 3 }] }
        },
        location: {
            x: 2,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score B点 DominationHide matches 0 run gamemode survival @s',
                'effect give @s minecraft:saturation 10 19',
                'effect give @s minecraft:absorption 3600 1 true',
                'execute if score 地图 Maps matches 0 if score B点 DominationHide matches 0 run tp @s -653 4 -588',
                'execute if score 地图 Maps matches 1 if score B点 DominationHide matches 0 run tp @s 962 16 170',
                'execute if score 地图 Maps matches 2 if score B点 DominationHide matches 0 run tp @s 1358 2 -900',
                'execute if score 地图 Maps matches 3 if score B点 DominationHide matches 0 run tp @s -360 183 -2347',
                'execute if score 地图 Maps matches 4 if score B点 DominationHide matches 0 run tp @s 1002 -6 -2119',
                'execute if score B点 DominationHide matches 0 run clear @s minecraft:clock',
                'execute if score B点 DominationHide matches 0 run clear @s minecraft:recovery_compass']
        }
    },
    PointC: {
        index: "PointC",
        icon: "minecraft:light_blue_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点C","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'ts', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'rs', Color: 0 }, { Pattern: 'ms', Color: 3 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'bo', Color: 3 }] }
        },
        location: {
            x: 3,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score C点 DominationHide matches 0 run gamemode survival @s',
                'effect give @s minecraft:saturation 10 19',
                'effect give @s minecraft:absorption 3600 1 true',
                'execute if score 地图 Maps matches 0 if score C点 DominationHide matches 0 run tp @s -780 16 -399',
                'execute if score 地图 Maps matches 1 if score C点 DominationHide matches 0 run tp @s 1288 19 287',
                'execute if score 地图 Maps matches 2 if score C点 DominationHide matches 0 run tp @s 1640 -5 -1270',
                'execute if score 地图 Maps matches 3 if score C点 DominationHide matches 0 run tp @s -727 247 -2294',
                'execute if score 地图 Maps matches 4 if score C点 DominationHide matches 0 run tp @s 986 -8 -2051',
                'execute if score C点 DominationHide matches 0 run clear @s minecraft:clock',
                'execute if score C点 DominationHide matches 0 run clear @s minecraft:recovery_compass']
        }
    },
    PointD: {
        index: "PointD",
        icon: "minecraft:light_blue_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点D","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'cbo', Color: 3 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'bo', Color: 3 }] }
        },
        location: {
            x: 4,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score D点 DominationHide matches 0 run gamemode survival @s',
                'effect give @s minecraft:saturation 10 19',
                'effect give @s minecraft:absorption 3600 1 true',
                'execute if score 地图 Maps matches 0 if score D点 DominationHide matches 0 run tp @s -287 2 -777',
                'execute if score 地图 Maps matches 1 if score D点 DominationHide matches 0 run tp @s 1173 19 466',
                'execute if score 地图 Maps matches 2 if score D点 DominationHide matches 0 run tp @s 1281 1 -535',
                'execute if score 地图 Maps matches 3 if score D点 DominationHide matches 0 run tp @s -365 189 -2455',
                'execute if score 地图 Maps matches 4 if score D点 DominationHide matches 0 run gamemode adventure @s',
                'execute if score 地图 Maps matches 4 if score D点 DominationHide matches 0 run title @s title "这个地图不存在D点"',
                'execute if score D点 DominationHide matches 0 unless score 地图 Maps matches 4 run clear @s minecraft:clock',
                'execute if score D点 DominationHide matches 0 unless score 地图 Maps matches 4 run clear @s minecraft:recovery_compass']
        }
    },
    PointE: {
        index: "PointE",
        icon: "minecraft:light_blue_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点E","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'ls', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'bo', Color: 3 }] }
        },
        location: {
            x: 5,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score E点 DominationHide matches 0 run gamemode survival @s',
                'effect give @s minecraft:saturation 10 19',
                'effect give @s minecraft:absorption 3600 1 true',
                'execute if score 地图 Maps matches 0 if score E点 DominationHide matches 0 run tp @s -133 2 -380',
                'execute if score 地图 Maps matches 1 if score E点 DominationHide matches 0 run tp @s 1138 18 160',
                'execute if score 地图 Maps matches 2 if score E点 DominationHide matches 0 run tp @s 1577 1 -886',
                'execute if score 地图 Maps matches 3 if score E点 DominationHide matches 0 run tp @s -553 123 -2407',
                'execute if score 地图 Maps matches 4 if score E点 DominationHide matches 0 run gamemode adventure @s',
                'execute if score 地图 Maps matches 4 if score E点 DominationHide matches 0 run title @s title "这个地图不存在E点"',
                'execute if score E点 DominationHide matches 0 unless score 地图 Maps matches 4 run clear @s minecraft:clock',
                'execute if score E点 DominationHide matches 0 unless score 地图 Maps matches 4 run clear @s minecraft:recovery_compass']
        }
    },
    RTP: {
        index: "RTP",
        icon: "spawner",
        iconNbt: {
            display: {
                Name: '{"text":"复活至随机队友","color":"gold","italic":"false"}',
                Lore: ['{"text":"对方必须允许自己成为随机传送目标，且周围没有敌人。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 1,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'execute if entity @a[team=WE,distance=200..,tag=RTP,tag=!RTP_Danger] run function teleport:tp_advance/rtp/rtp_tp_blue',
            ]
        }
    },
    allowRTP: {
        index: "allowRTP",
        icon: "minecraft:lime_stained_glass_pane",
        iconNbt: {
            display: {
                Name: '{"text":"允许成为随机传送目标","color":"gold","italic":"false"}',
                Lore: ['{"text":"默认为阻止","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 3,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'function teleport:tp_advance/rtp/rtp_allow',
            ]
        }
    },
    abandonRTP: {
        index: "abandonRTP",
        icon: "minecraft:red_stained_glass_pane",
        iconNbt: {
            display: {
                Name: '{"text":"阻止自己成为随机传送目标","color":"gold","italic":"false"}',
                Lore: ['{"text":"默认为阻止","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 4,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'function teleport:tp_advance/rtp/rtp_abandon',
            ]
        }
    },
    supportTP: {
        index: "supportTP",
        icon: "beacon",
        iconNbt: {
            display: {
                Name: '{"text":"复活至支援信标","color":"gold","italic":"false"}',
                Lore: ['{"text":"当场上存在支援信标时可用，信标提示见整备区标识。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 6,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'execute if entity @e[name="支援信标",team=WE,tag=RespawnSet] run function teleport:tp_advance/beacon/beacon_tp_blue',
            ]
        }
    },
} */