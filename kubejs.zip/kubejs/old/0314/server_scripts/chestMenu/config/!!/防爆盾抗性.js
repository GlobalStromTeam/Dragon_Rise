PlayerEvents.inventoryChanged('shield', event => {
    let { player, server } = event
    let serverPlayer = /** @type {Internal.ServerPlayer} */(player)
    if (serverPlayer.getOffHandItem() == Item.of('shield').withNBT({
        Unbreakable: true,
        BlockEntityTag: {
            Patterns: [{ Pattern: "hh", Color: 3 },
            { Pattern: "ms", Color: 15 },
            { Pattern: "ts", Color: 15 },
            { Pattern: "cbo", Color: 15 },
            { Pattern: 'bo', Color: 7 }], Base: 15
        },
        display: {
            Name: '["",{"text":"防爆盾","italic":false,"color":"gray"}]',
            Lore: ['["",{"text":"置于副手时提供","italic":false,"color":"white"},{"text":"抗性提升2","italic":false,"color":"green"},{"text":"效果，举盾可以挡住部分子弹。","italic":false,"color":"white"}]', '["",{"text":"而且不可破坏。","italic":false,"color":"gray"}]']
        }, HideFlags: 32
    })) {
        server.runCommandSilent(`effect give ${serverPlayer.username} minecraft:resistance infinite 1 true`)

    } else {
        server.runCommandSilent(`effect clear ${serverPlayer.username} minecraft:resistance`)
    }
})