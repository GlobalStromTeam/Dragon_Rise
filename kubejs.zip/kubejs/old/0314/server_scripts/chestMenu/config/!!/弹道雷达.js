EntityEvents.hurt('player',event => {
    const { entity, source } = event
    //server.tell(entity.tags.contains('Radar'))
    if ( entity.tags.contains('Radar')) {
        //let player = source.getPlayer()
        //let serverPlayer = /** @type {Internal.ServerPlayer} */ (player)
        try {
            source.actual.potionEffects.add('glowing', 80, 0, true, false)
        } catch (error) {

        }

    }
})
