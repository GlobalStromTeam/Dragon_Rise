const scoutRadius = 16
const scoutDistance = 320
const scoutGlowTime = 20

ItemEvents.rightClicked('spyglass', event => {
    let { player, server } = event
    let serverPlayer = /** @type {Internal.ServerPlayer} */(player)
    let playerTeam = serverPlayer.teamId
    //let hitPos = serverPlayer.rayTrace(scoutDistance).hit
    let hitPosX = serverPlayer.rayTrace(scoutDistance).hitX
    let hitPosY = serverPlayer.rayTrace(scoutDistance).hitY
    let hitPosZ = serverPlayer.rayTrace(scoutDistance).hitZ
    //server.tell(hitPosX)
    server.runCommandSilent(`execute positioned ${hitPosX} ${hitPosY} ${hitPosZ} run effect give @e[team=!${playerTeam},distance=..${scoutRadius}] minecraft:glowing ${scoutGlowTime} 0 true`)
    server.runCommandSilent(`execute positioned ${hitPosX} ${hitPosY} ${hitPosZ} if entity @e[team=!${playerTeam},distance=..${scoutRadius}] at ${serverPlayer.username} run playsound minecraft:entity.experience_orb.pickup player @a ~ ~ ~ 1 1`)
    /* server.entities.forEach(entity=>{
        //server.tell(hitPos)
        //server.tell(entity.position())
        if(entity.teamId != playerTeam && hitPos.distanceTo(entity.position()) <= scoutRadius){
            //server.tell(serverPlayer.rayTrace(scoutDistance).hit)
            try {
                entity.potionEffects.add('glowing', scoutGlowTime * 20, 0, true, false)
            entity.potionEffects.add('minecraft:mining_fatigue', scoutGlowTime * 20, 2, true, false)
            server.runCommandSilent(`execute as ${serverPlayer.username} at @s run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 1 1`)
            } catch (error) {
                
            }
            
        }
    }) */
    
})