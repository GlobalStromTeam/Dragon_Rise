const 东欧REDTP = {
    description: {
        index: "东欧REDTP",
        type: "none",
        title: Text.black('『东联传送菜单』'),
        leftButton: {
            icon: 'createdeco:decal_left',
            iconNbt: {
                display: {
                    Name: '{"text":"退出","color":"red","italic":"false"}',
                    Lore: ['{"text":"按esc有一样的效果","color":"gray","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "exit",
            }
        },

    },
    spawnPoint1: {
        index: "spawnPoint1",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点1","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 1,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function teleport:tp_spawn/tp_spawneffect',
                'spreadplayers 52 -548 0 15 true @s'
            ]
        }
    },
    spawnPoint2: {
        index: "spawnPoint2",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点2","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 3,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function teleport:tp_spawn/tp_spawneffect',
                'spreadplayers -249 -1074 0 15 true @s'
            ]
        }
    },
    spawnPoint3: {
        index: "spawnPoint3",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点3","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 5,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function teleport:tp_spawn/tp_spawneffect',
                'spreadplayers -280 -27 0 15 true @s'
            ]
        }
    },
    PointA: {
        index: "PointA",
        icon: "minecraft:red_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点A","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'bo', Color: 14 }] }
        },
        location: {
            x: 1,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score A点 DominationHide matches 1 run function teleport:tp_point/tp_pointeffect',
                'execute if score A点 DominationHide matches 1 run tp @s -374 3 -566'
            ]
        }
    },
    PointB: {
        index: "PointB",
        icon: "minecraft:red_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点B","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'cbo', Color: 14 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'bo', Color: 14 }] }
        },
        location: {
            x: 2,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score B点 DominationHide matches 1 run function teleport:tp_point/tp_pointeffect',
                'execute if score B点 DominationHide matches 1 run tp @s -653 4 -588'
            ]
        }
    },
    PointC: {
        index: "PointC",
        icon: "minecraft:red_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点C","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'ts', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'rs', Color: 0 }, { Pattern: 'ms', Color: 14 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'bo', Color: 14 }] }
        },
        location: {
            x: 3,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score C点 DominationHide matches 1 run function teleport:tp_point/tp_pointeffect',
                'execute if score C点 DominationHide matches 1 run tp @s -780 16 -399'
            ]
        }
    },
    PointD: {
        index: "PointD",
        icon: "minecraft:red_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点D","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'cbo', Color: 14 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'bo', Color: 14 }] }
        },
        location: {
            x: 4,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score D点 DominationHide matches 1 run function teleport:tp_point/tp_pointeffect',
                'execute if score D点 DominationHide matches 1 run tp @s -287 2 -777'
            ]
        }
    },
    PointE: {
        index: "PointE",
        icon: "minecraft:red_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点E","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'ls', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'bo', Color: 14 }] }
        },
        location: {
            x: 5,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score E点 DominationHide matches 1 run function teleport:tp_point/tp_pointeffect',
                'execute if score E点 DominationHide matches 1 run tp @s -133 2 -380'
            ]
        }
    },
    RTP: {
        index: "RTP",
        icon: "spawner",
        iconNbt: {
            display: {
                Name: '{"text":"复活至随机队友","color":"gold","italic":"false"}',
                Lore: ['{"text":"对方必须允许自己成为随机传送目标，且周围没有敌人。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 1,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'execute if entity @a[team=EA,distance=200..,tag=RTP,tag=!RTP_Danger] run function teleport:tp_advance/rtp/rtp_tp_red',
            ]
        }
    },
    allowRTP: {
        index: "allowRTP",
        icon: "minecraft:lime_stained_glass_pane",
        iconNbt: {
            display: {
                Name: '{"text":"允许成为随机传送目标","color":"gold","italic":"false"}',
                Lore: ['{"text":"默认为阻止","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 3,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'function teleport:tp_advance/rtp/rtp_allow',
            ]
        }
    },
    abandonRTP: {
        index: "abandonRTP",
        icon: "minecraft:red_stained_glass_pane",
        iconNbt: {
            display: {
                Name: '{"text":"阻止自己成为随机传送目标","color":"gold","italic":"false"}',
                Lore: ['{"text":"默认为阻止","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 4,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'function teleport:tp_advance/rtp/rtp_abandon',
            ]
        }
    },
    supportTP: {
        index: "supportTP",
        icon: "beacon",
        iconNbt: {
            display: {
                Name: '{"text":"复活至支援信标","color":"gold","italic":"false"}',
                Lore: ['{"text":"当场上存在支援信标时可用，信标提示见整备区标识。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 6,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'execute if entity @e[name="支援信标",team=EA,tag=RespawnSet] run function teleport:tp_advance/beacon/beacon_tp_red',
            ]
        }
    },
    vehicleTP: {
        index: "vehicleTP",
        icon: "beacon",
        iconNbt: {
            display: {
                Name: '{"text":"复活至步兵战车","color":"gold","italic":"false"}',
                Lore: ['{"text":"当场上存在可行动的步兵战车时可用。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 7,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'execute if entity @e[name="载具信标",team=EA] run function teleport:tp_advance/beacon/vehicle_tp_red',
            ]
        }
    },
}
const 海岛REDTP = {
    description: {
        index: "海岛REDTP",
        type: "none",
        title: Text.black('『东联传送菜单』'),
        leftButton: {
            icon: 'createdeco:decal_left',
            iconNbt: {
                display: {
                    Name: '{"text":"退出","color":"red","italic":"false"}',
                    Lore: ['{"text":"按esc有一样的效果","color":"gray","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "exit",
            }
        },

    },
    spawnPoint1: {
        index: "spawnPoint1",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点1","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 1,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function teleport:tp_spawn/tp_spawneffect',
                'spreadplayers 538 145 0 5 true @s'
            ]
        }
    },
    spawnPoint2: {
        index: "spawnPoint2",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点2","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 3,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function teleport:tp_spawn/tp_spawneffect',
                'spreadplayers 506 362 0 5 true @s'
            ]
        }
    },
    spawnPoint3: {
        index: "spawnPoint3",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点3","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 5,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function teleport:tp_spawn/tp_spawneffect',
                'spreadplayers 540 534 0 5 true @s'
            ]
        }
    },
    PointA: {
        index: "PointA",
        icon: "minecraft:red_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点A","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'bo', Color: 14 }] }
        },
        location: {
            x: 1,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score A点 DominationHide matches 1 run function teleport:tp_point/tp_pointeffect',
                'execute if score A点 DominationHide matches 1 run tp @s 872 13 358'
            ]
        }
    },
    PointB: {
        index: "PointB",
        icon: "minecraft:red_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点B","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'cbo', Color: 14 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'bo', Color: 14 }] }
        },
        location: {
            x: 2,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score B点 DominationHide matches 1 run function teleport:tp_point/tp_pointeffect',
                'execute if score B点 DominationHide matches 1 run tp @s 962 16 170'
            ]
        }
    },
    PointC: {
        index: "PointC",
        icon: "minecraft:red_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点C","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'ts', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'rs', Color: 0 }, { Pattern: 'ms', Color: 14 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'bo', Color: 14 }] }
        },
        location: {
            x: 3,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score C点 DominationHide matches 1 run function teleport:tp_point/tp_pointeffect',
                'execute if score C点 DominationHide matches 1 run tp @s 1288 19 287'
            ]
        }
    },
    PointD: {
        index: "PointD",
        icon: "minecraft:red_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点D","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'cbo', Color: 14 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'bo', Color: 14 }] }
        },
        location: {
            x: 4,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score D点 DominationHide matches 1 run function teleport:tp_point/tp_pointeffect',
                'execute if score D点 DominationHide matches 1 run tp @s 1173 19 466'
            ]
        }
    },
    PointE: {
        index: "PointE",
        icon: "minecraft:red_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点E","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'ls', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'bo', Color: 14 }] }
        },
        location: {
            x: 5,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score E点 DominationHide matches 1 run function teleport:tp_point/tp_pointeffect',
                'execute if score E点 DominationHide matches 1 run tp @s 1138 20 160'
            ]
        }
    },
    RTP: {
        index: "RTP",
        icon: "spawner",
        iconNbt: {
            display: {
                Name: '{"text":"复活至随机队友","color":"gold","italic":"false"}',
                Lore: ['{"text":"对方必须允许自己成为随机传送目标，且周围没有敌人。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 1,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'execute if entity @a[team=EA,distance=200..,tag=RTP,tag=!RTP_Danger] run function teleport:tp_advance/rtp/rtp_tp_red',
            ]
        }
    },
    allowRTP: {
        index: "allowRTP",
        icon: "minecraft:lime_stained_glass_pane",
        iconNbt: {
            display: {
                Name: '{"text":"允许成为随机传送目标","color":"gold","italic":"false"}',
                Lore: ['{"text":"默认为阻止","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 3,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'function teleport:tp_advance/rtp/rtp_allow',
            ]
        }
    },
    abandonRTP: {
        index: "abandonRTP",
        icon: "minecraft:red_stained_glass_pane",
        iconNbt: {
            display: {
                Name: '{"text":"阻止自己成为随机传送目标","color":"gold","italic":"false"}',
                Lore: ['{"text":"默认为阻止","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 4,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'function teleport:tp_advance/rtp/rtp_abandon',
            ]
        }
    },
    supportTP: {
        index: "supportTP",
        icon: "beacon",
        iconNbt: {
            display: {
                Name: '{"text":"复活至支援信标","color":"gold","italic":"false"}',
                Lore: ['{"text":"当场上存在支援信标时可用，信标提示见整备区标识。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 6,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'execute if entity @e[name="支援信标",team=EA,tag=RespawnSet] run function teleport:tp_advance/beacon/beacon_tp_red',
            ]
        }
    },
    vehicleTP: {
        index: "vehicleTP",
        icon: "beacon",
        iconNbt: {
            display: {
                Name: '{"text":"复活至步兵战车","color":"gold","italic":"false"}',
                Lore: ['{"text":"当场上存在可行动的步兵战车时可用。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 7,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'execute if entity @e[name="载具信标",team=EA] run function teleport:tp_advance/beacon/vehicle_tp_red',
            ]
        }
    },
}
const 中东REDTP = {
    description: {
        index: "中东REDTP",
        type: "none",
        title: Text.black('『东联传送菜单』'),
        leftButton: {
            icon: 'createdeco:decal_left',
            iconNbt: {
                display: {
                    Name: '{"text":"退出","color":"red","italic":"false"}',
                    Lore: ['{"text":"按esc有一样的效果","color":"gray","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "exit",
            }
        },

    },
    spawnPoint1: {
        index: "spawnPoint1",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点1","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 1,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function teleport:tp_spawn/tp_spawneffect',
                'spreadplayers 1367 -1062 0 5 true @s'
            ]
        }
    },
    spawnPoint2: {
        index: "spawnPoint2",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点2","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 3,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function teleport:tp_spawn/tp_spawneffect',
                'spreadplayers 1412 -1354 0 15 true @s'
            ]
        }
    },
    spawnPoint3: {
        index: "spawnPoint3",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点3","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 5,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function teleport:tp_spawn/tp_spawneffect',
                'spreadplayers 1645 -1351 0 15 true @s'
            ]
        }
    },
    PointA: {
        index: "PointA",
        icon: "minecraft:red_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点A","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'bo', Color: 14 }] }
        },
        location: {
            x: 1,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score A点 DominationHide matches 1 run function teleport:tp_point/tp_pointeffect',
                'execute if score A点 DominationHide matches 1 run tp @s 1688 6 -584'
            ]
        }
    },
    PointB: {
        index: "PointB",
        icon: "minecraft:red_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点B","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'cbo', Color: 14 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'bo', Color: 14 }] }
        },
        location: {
            x: 2,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score B点 DominationHide matches 1 run function teleport:tp_point/tp_pointeffect',
                'execute if score B点 DominationHide matches 1 run tp @s 1358 235 -900'
            ]
        }
    },
    PointC: {
        index: "PointC",
        icon: "minecraft:red_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点C","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'ts', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'rs', Color: 0 }, { Pattern: 'ms', Color: 14 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'bo', Color: 14 }] }
        },
        location: {
            x: 3,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score C点 DominationHide matches 1 run function teleport:tp_point/tp_pointeffect',
                'execute if score C点 DominationHide matches 1 run tp @s 1640 -5 -1270'
            ]
        }
    },
    PointD: {
        index: "PointD",
        icon: "minecraft:red_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点D","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'cbo', Color: 14 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'bo', Color: 14 }] }
        },
        location: {
            x: 4,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score D点 DominationHide matches 1 run function teleport:tp_point/tp_pointeffect',
                'execute if score D点 DominationHide matches 1 run tp @s 1281 1 -535'
            ]
        }
    },
    PointE: {
        index: "PointE",
        icon: "minecraft:red_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点E","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'ls', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'bo', Color: 14 }] }
        },
        location: {
            x: 5,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score E点 DominationHide matches 1 run function teleport:tp_point/tp_pointeffect',
                'execute if score E点 DominationHide matches 1 run tp @s 1577 1 -886'
            ]
        }
    },
    RTP: {
        index: "RTP",
        icon: "spawner",
        iconNbt: {
            display: {
                Name: '{"text":"复活至随机队友","color":"gold","italic":"false"}',
                Lore: ['{"text":"对方必须允许自己成为随机传送目标，且周围没有敌人。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 1,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'execute if entity @a[team=EA,distance=200..,tag=RTP,tag=!RTP_Danger] run function teleport:tp_advance/rtp/rtp_tp_red',
            ]
        }
    },
    allowRTP: {
        index: "allowRTP",
        icon: "minecraft:lime_stained_glass_pane",
        iconNbt: {
            display: {
                Name: '{"text":"允许成为随机传送目标","color":"gold","italic":"false"}',
                Lore: ['{"text":"默认为阻止","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 3,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'function teleport:tp_advance/rtp/rtp_allow',
            ]
        }
    },
    abandonRTP: {
        index: "abandonRTP",
        icon: "minecraft:red_stained_glass_pane",
        iconNbt: {
            display: {
                Name: '{"text":"阻止自己成为随机传送目标","color":"gold","italic":"false"}',
                Lore: ['{"text":"默认为阻止","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 4,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'function teleport:tp_advance/rtp/rtp_abandon',
            ]
        }
    },
    supportTP: {
        index: "supportTP",
        icon: "beacon",
        iconNbt: {
            display: {
                Name: '{"text":"复活至支援信标","color":"gold","italic":"false"}',
                Lore: ['{"text":"当场上存在支援信标时可用，信标提示见整备区标识。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 6,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'execute if entity @e[name="支援信标",team=EA,tag=RespawnSet] run function teleport:tp_advance/beacon/beacon_tp_red',
            ]
        }
    },
    vehicleTP: {
        index: "vehicleTP",
        icon: "beacon",
        iconNbt: {
            display: {
                Name: '{"text":"复活至步兵战车","color":"gold","italic":"false"}',
                Lore: ['{"text":"当场上存在可行动的步兵战车时可用。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 7,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'execute if entity @e[name="载具信标",team=EA] run function teleport:tp_advance/beacon/vehicle_tp_red',
            ]
        }
    },
}
const 雪山REDTP = {
    description: {
        index: "雪山REDTP",
        type: "none",
        title: Text.black('『东联传送菜单』'),
        leftButton: {
            icon: 'createdeco:decal_left',
            iconNbt: {
                display: {
                    Name: '{"text":"退出","color":"red","italic":"false"}',
                    Lore: ['{"text":"按esc有一样的效果","color":"gray","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "exit",
            }
        },

    },
    spawnPoint1: {
        index: "spawnPoint1",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点1","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 1,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function teleport:tp_spawn/tp_spawneffect',
                'tp @s -756 300 -2303',
                'effect give @s slow_falling 7 0 true'
            ]
        }
    },
    /* spawnPoint2: {
        index: "spawnPoint2",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点2","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 3,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function teleport:tp_spawn/tp_spawneffect',
                'spreadplayers -249 -1074 0 15 true @s'
            ]
        }
    },
    spawnPoint3: {
        index: "spawnPoint3",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点3","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 5,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function teleport:tp_spawn/tp_spawneffect',
                'spreadplayers -280 -27 0 15 true @s'
            ]
        }
    }, */
    PointA: {
        index: "PointA",
        icon: "minecraft:red_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点A","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'bo', Color: 14 }] }
        },
        location: {
            x: 1,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score A点 DominationHide matches 1 run function teleport:tp_point/tp_pointeffect',
                'execute if score A点 DominationHide matches 1 run tp @s -381 240 -2606'
            ]
        }
    },
    PointB: {
        index: "PointB",
        icon: "minecraft:red_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点B","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'cbo', Color: 14 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'bo', Color: 14 }] }
        },
        location: {
            x: 2,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score B点 DominationHide matches 1 run function teleport:tp_point/tp_pointeffect',
                'execute if score B点 DominationHide matches 1 run tp @s -360 183 -2347'
            ]
        }
    },
    PointC: {
        index: "PointC",
        icon: "minecraft:red_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点C","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'ts', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'rs', Color: 0 }, { Pattern: 'ms', Color: 14 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'bo', Color: 14 }] }
        },
        location: {
            x: 3,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score C点 DominationHide matches 1 run function teleport:tp_point/tp_pointeffect',
                'execute if score C点 DominationHide matches 1 run tp @s -727 247 -2294'
            ]
        }
    },
    PointD: {
        index: "PointD",
        icon: "minecraft:red_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点D","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'cbo', Color: 14 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'bo', Color: 14 }] }
        },
        location: {
            x: 4,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score D点 DominationHide matches 1 run function teleport:tp_point/tp_pointeffect',
                'execute if score D点 DominationHide matches 1 run tp @s -365 189 -2455'
            ]
        }
    },
    PointE: {
        index: "PointE",
        icon: "minecraft:red_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点E","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'ls', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'bo', Color: 14 }] }
        },
        location: {
            x: 5,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score E点 DominationHide matches 1 run function teleport:tp_point/tp_pointeffect',
                'execute if score E点 DominationHide matches 1 run tp @s -553 123 -2407'
            ]
        }
    },
    RTP: {
        index: "RTP",
        icon: "spawner",
        iconNbt: {
            display: {
                Name: '{"text":"复活至随机队友","color":"gold","italic":"false"}',
                Lore: ['{"text":"对方必须允许自己成为随机传送目标，且周围没有敌人。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 1,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'execute if entity @a[team=EA,distance=200..,tag=RTP,tag=!RTP_Danger] run function teleport:tp_advance/rtp/rtp_tp_red',
            ]
        }
    },
    allowRTP: {
        index: "allowRTP",
        icon: "minecraft:lime_stained_glass_pane",
        iconNbt: {
            display: {
                Name: '{"text":"允许成为随机传送目标","color":"gold","italic":"false"}',
                Lore: ['{"text":"默认为阻止","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 3,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'function teleport:tp_advance/rtp/rtp_allow',
            ]
        }
    },
    abandonRTP: {
        index: "abandonRTP",
        icon: "minecraft:red_stained_glass_pane",
        iconNbt: {
            display: {
                Name: '{"text":"阻止自己成为随机传送目标","color":"gold","italic":"false"}',
                Lore: ['{"text":"默认为阻止","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 4,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'function teleport:tp_advance/rtp/rtp_abandon',
            ]
        }
    },
    supportTP: {
        index: "supportTP",
        icon: "beacon",
        iconNbt: {
            display: {
                Name: '{"text":"复活至支援信标","color":"gold","italic":"false"}',
                Lore: ['{"text":"当场上存在支援信标时可用，信标提示见整备区标识。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 6,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'execute if entity @e[name="支援信标",team=EA,tag=RespawnSet] run function teleport:tp_advance/beacon/beacon_tp_red',
            ]
        }
    },
    vehicleTP: {
        index: "vehicleTP",
        icon: "beacon",
        iconNbt: {
            display: {
                Name: '{"text":"复活至步兵战车","color":"gold","italic":"false"}',
                Lore: ['{"text":"当场上存在可行动的步兵战车时可用。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 7,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'execute if entity @e[name="载具信标",team=EA] run function teleport:tp_advance/beacon/vehicle_tp_red',
            ]
        }
    },
}
const 首府REDTP = {
    description: {
        index: "首府REDTP",
        type: "none",
        title: Text.black('『东联传送菜单』'),
        leftButton: {
            icon: 'createdeco:decal_left',
            iconNbt: {
                display: {
                    Name: '{"text":"退出","color":"red","italic":"false"}',
                    Lore: ['{"text":"按esc有一样的效果","color":"gray","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "exit",
            }
        },

    },
    spawnPoint1: {
        index: "spawnPoint1",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点1","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 1,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function teleport:tp_spawn/tp_spawneffect',
                'spreadplayers 1089 -2216 0 5 true @s'
            ]
        }
    },
    /* spawnPoint2: {
        index: "spawnPoint2",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点2","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 3,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function teleport:tp_spawn/tp_spawneffect',
                'spreadplayers -249 -1074 0 15 true @s'
            ]
        }
    },
    spawnPoint3: {
        index: "spawnPoint3",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点3","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 5,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function teleport:tp_spawn/tp_spawneffect',
                'spreadplayers -280 -27 0 15 true @s'
            ]
        }
    }, */
    PointA: {
        index: "PointA",
        icon: "minecraft:red_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点A","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'bo', Color: 14 }] }
        },
        location: {
            x: 1,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score A点 DominationHide matches 1 run function teleport:tp_point/tp_pointeffect',
                'execute if score A点 DominationHide matches 1 run tp @s 1049 -13 -2118'
            ]
        }
    },
    PointB: {
        index: "PointB",
        icon: "minecraft:red_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点B","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'cbo', Color: 14 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'bo', Color: 14 }] }
        },
        location: {
            x: 2,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score B点 DominationHide matches 1 run function teleport:tp_point/tp_pointeffect',
                'execute if score B点 DominationHide matches 1 run tp @s 1002 -6 -2119'
            ]
        }
    },
    PointC: {
        index: "PointC",
        icon: "minecraft:red_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点C","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'ts', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'rs', Color: 0 }, { Pattern: 'ms', Color: 14 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'bo', Color: 14 }] }
        },
        location: {
            x: 3,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score C点 DominationHide matches 1 run function teleport:tp_point/tp_pointeffect',
                'execute if score C点 DominationHide matches 1 run tp @s 986 -8 -2051'
            ]
        }
    },
    /* PointD: {
        index: "PointD",
        icon: "minecraft:red_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点D","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'cbo', Color: 14 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'bo', Color: 14 }] }
        },
        location: {
            x: 4,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score D点 DominationHide matches 1 run function teleport:tp_point/tp_pointeffect',
                'execute if score D点 DominationHide matches 1 run tp @s -287 2 -777'
            ]
        }
    },
    PointE: {
        index: "PointE",
        icon: "minecraft:red_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点E","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'ls', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'bo', Color: 14 }] }
        },
        location: {
            x: 5,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score E点 DominationHide matches 1 run function teleport:tp_point/tp_pointeffect',
                'execute if score E点 DominationHide matches 1 run tp @s -133 2 -380'
            ]
        }
    }, */
    RTP: {
        index: "RTP",
        icon: "spawner",
        iconNbt: {
            display: {
                Name: '{"text":"复活至随机队友","color":"gold","italic":"false"}',
                Lore: ['{"text":"对方必须允许自己成为随机传送目标，且周围没有敌人。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 1,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'execute if entity @a[team=EA,distance=200..,tag=RTP,tag=!RTP_Danger] run function teleport:tp_advance/rtp/rtp_tp_red',
            ]
        }
    },
    allowRTP: {
        index: "allowRTP",
        icon: "minecraft:lime_stained_glass_pane",
        iconNbt: {
            display: {
                Name: '{"text":"允许成为随机传送目标","color":"gold","italic":"false"}',
                Lore: ['{"text":"默认为阻止","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 3,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'function teleport:tp_advance/rtp/rtp_allow',
            ]
        }
    },
    abandonRTP: {
        index: "abandonRTP",
        icon: "minecraft:red_stained_glass_pane",
        iconNbt: {
            display: {
                Name: '{"text":"阻止自己成为随机传送目标","color":"gold","italic":"false"}',
                Lore: ['{"text":"默认为阻止","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 4,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'function teleport:tp_advance/rtp/rtp_abandon',
            ]
        }
    },
    supportTP: {
        index: "supportTP",
        icon: "beacon",
        iconNbt: {
            display: {
                Name: '{"text":"复活至支援信标","color":"gold","italic":"false"}',
                Lore: ['{"text":"当场上存在支援信标时可用，信标提示见整备区标识。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 6,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'execute if entity @e[name="支援信标",team=EA,tag=RespawnSet] run function teleport:tp_advance/beacon/beacon_tp_red',
            ]
        }
    },
    /* vehicleTP: {
        index: "vehicleTP",
        icon: "beacon",
        iconNbt: {
            display: {
                Name: '{"text":"复活至步兵战车","color":"gold","italic":"false"}',
                Lore: ['{"text":"当场上存在可行动的步兵战车时可用。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 7,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'execute if entity @e[name="载具信标",team=EA] run function teleport:tp_advance/beacon/vehicle_tp_red',
            ]
        }
    }, */
}
const 越南REDTP = {
    description: {
        index: "越南REDTP",
        type: "none",
        title: Text.black('『东联传送菜单』'),
        leftButton: {
            icon: 'createdeco:decal_left',
            iconNbt: {
                display: {
                    Name: '{"text":"退出","color":"red","italic":"false"}',
                    Lore: ['{"text":"按esc有一样的效果","color":"gray","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "exit",
            }
        },

    },
    spawnPoint1: {
        index: "spawnPoint1",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点1","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 1,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function teleport:tp_spawn/tp_spawneffect',
                'spreadplayers 4877 2764 0 15 true @s'
            ]
        }
    },
    spawnPoint2: {
        index: "spawnPoint2",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点2","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 3,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function teleport:tp_spawn/tp_spawneffect',
                'spreadplayers 4618 3149 0 15 true @s'
            ]
        }
    },
    /* spawnPoint3: {
        index: "spawnPoint3",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点3","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 5,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function teleport:tp_spawn/tp_spawneffect',
                'spreadplayers -280 -27 0 15 true @s'
            ]
        }
    }, */
    PointA: {
        index: "PointA",
        icon: "minecraft:red_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点A","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'bo', Color: 14 }] }
        },
        location: {
            x: 1,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score A点 DominationHide matches 1 run function teleport:tp_point/tp_pointeffect',
                'execute if score A点 DominationHide matches 1 run tp @s 3495 -42 2945'
            ]
        }
    },
    PointB: {
        index: "PointB",
        icon: "minecraft:red_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点B","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'cbo', Color: 14 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'bo', Color: 14 }] }
        },
        location: {
            x: 2,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score B点 DominationHide matches 1 run function teleport:tp_point/tp_pointeffect',
                'execute if score B点 DominationHide matches 1 run tp @s 3991 -44 2896'
            ]
        }
    },
    PointC: {
        index: "PointC",
        icon: "minecraft:red_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点C","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'ts', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'rs', Color: 0 }, { Pattern: 'ms', Color: 14 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'bo', Color: 14 }] }
        },
        location: {
            x: 3,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score C点 DominationHide matches 1 run function teleport:tp_point/tp_pointeffect',
                'execute if score C点 DominationHide matches 1 run tp @s 4471 -41 2695'
            ]
        }
    },
    PointD: {
        index: "PointD",
        icon: "minecraft:red_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点D","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'cbo', Color: 14 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'bo', Color: 14 }] }
        },
        location: {
            x: 4,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score D点 DominationHide matches 1 run function teleport:tp_point/tp_pointeffect',
                'execute if score D点 DominationHide matches 1 run tp @s 3713 -45 3193'
            ]
        }
    },
    PointE: {
        index: "PointE",
        icon: "minecraft:red_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点E","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'ls', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'bo', Color: 14 }] }
        },
        location: {
            x: 5,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score E点 DominationHide matches 1 run function teleport:tp_point/tp_pointeffect',
                'execute if score E点 DominationHide matches 1 run tp @s 4356 -45 3078'
            ]
        }
    },
    RTP: {
        index: "RTP",
        icon: "spawner",
        iconNbt: {
            display: {
                Name: '{"text":"复活至随机队友","color":"gold","italic":"false"}',
                Lore: ['{"text":"对方必须允许自己成为随机传送目标，且周围没有敌人。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 1,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'execute if entity @a[team=EA,distance=200..,tag=RTP,tag=!RTP_Danger] run function teleport:tp_advance/rtp/rtp_tp_red',
            ]
        }
    },
    allowRTP: {
        index: "allowRTP",
        icon: "minecraft:lime_stained_glass_pane",
        iconNbt: {
            display: {
                Name: '{"text":"允许成为随机传送目标","color":"gold","italic":"false"}',
                Lore: ['{"text":"默认为阻止","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 3,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'function teleport:tp_advance/rtp/rtp_allow',
            ]
        }
    },
    abandonRTP: {
        index: "abandonRTP",
        icon: "minecraft:red_stained_glass_pane",
        iconNbt: {
            display: {
                Name: '{"text":"阻止自己成为随机传送目标","color":"gold","italic":"false"}',
                Lore: ['{"text":"默认为阻止","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 4,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'function teleport:tp_advance/rtp/rtp_abandon',
            ]
        }
    },
    supportTP: {
        index: "supportTP",
        icon: "beacon",
        iconNbt: {
            display: {
                Name: '{"text":"复活至支援信标","color":"gold","italic":"false"}',
                Lore: ['{"text":"当场上存在支援信标时可用，信标提示见整备区标识。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 6,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'execute if entity @e[name="支援信标",team=EA,tag=RespawnSet] run function teleport:tp_advance/beacon/beacon_tp_red',
            ]
        }
    },
    vehicleTP: {
        index: "vehicleTP",
        icon: "beacon",
        iconNbt: {
            display: {
                Name: '{"text":"复活至步兵战车","color":"gold","italic":"false"}',
                Lore: ['{"text":"当场上存在可行动的步兵战车时可用。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 7,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'execute if entity @e[name="载具信标",team=EA] run function teleport:tp_advance/beacon/vehicle_tp_red',
            ]
        }
    },
}
const 白宫REDTP = {
    description: {
        index: "白宫REDTP",
        type: "none",
        title: Text.black('『东联传送菜单』'),
        leftButton: {
            icon: 'createdeco:decal_left',
            iconNbt: {
                display: {
                    Name: '{"text":"退出","color":"red","italic":"false"}',
                    Lore: ['{"text":"按esc有一样的效果","color":"gray","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "exit",
            }
        },

    },
    spawnPoint1: {
        index: "spawnPoint1",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点1","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 1,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function teleport:tp_spawn/tp_spawneffect',
                'spreadplayers 1365 -1945 0 5 true @s'
            ]
        }
    },
    spawnPoint2: {
        index: "spawnPoint2",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点2","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 3,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function teleport:tp_spawn/tp_spawneffect',
                'spreadplayers 1542 -1945 0 5 true @s'
            ]
        }
    },
    /* 
    spawnPoint3: {
        index: "spawnPoint3",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点3","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 5,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function teleport:tp_spawn/tp_spawneffect',
                'spreadplayers -280 -27 0 15 true @s'
            ]
        }
    }, */
    PointA: {
        index: "PointA",
        icon: "minecraft:red_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点A","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'bo', Color: 14 }] }
        },
        location: {
            x: 1,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score A点 DominationHide matches 1 run function teleport:tp_point/tp_pointeffect',
                'execute if score A点 DominationHide matches 1 run tp @s 1351 0 -2171'
            ]
        }
    },
    PointB: {
        index: "PointB",
        icon: "minecraft:red_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点B","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'cbo', Color: 14 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'bo', Color: 14 }] }
        },
        location: {
            x: 2,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score B点 DominationHide matches 1 run function teleport:tp_point/tp_pointeffect',
                'execute if score B点 DominationHide matches 1 run tp @s 1455 5 -2183'
            ]
        }
    },
    PointC: {
        index: "PointC",
        icon: "minecraft:red_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点C","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'ts', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'rs', Color: 0 }, { Pattern: 'ms', Color: 14 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'bo', Color: 14 }] }
        },
        location: {
            x: 3,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score C点 DominationHide matches 1 run function teleport:tp_point/tp_pointeffect',
                'execute if score C点 DominationHide matches 1 run tp @s 1540 0 -2180'
            ]
        }
    },
    /* PointD: {
        index: "PointD",
        icon: "minecraft:red_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点D","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'cbo', Color: 14 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'bo', Color: 14 }] }
        },
        location: {
            x: 4,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score D点 DominationHide matches 1 run function teleport:tp_point/tp_pointeffect',
                'execute if score D点 DominationHide matches 1 run tp @s -287 2 -777'
            ]
        }
    },
    PointE: {
        index: "PointE",
        icon: "minecraft:red_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点E","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'ls', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'bo', Color: 14 }] }
        },
        location: {
            x: 5,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score E点 DominationHide matches 1 run function teleport:tp_point/tp_pointeffect',
                'execute if score E点 DominationHide matches 1 run tp @s -133 2 -380'
            ]
        }
    }, */
    RTP: {
        index: "RTP",
        icon: "spawner",
        iconNbt: {
            display: {
                Name: '{"text":"复活至随机队友","color":"gold","italic":"false"}',
                Lore: ['{"text":"对方必须允许自己成为随机传送目标，且周围没有敌人。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 1,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'execute if entity @a[team=EA,distance=200..,tag=RTP,tag=!RTP_Danger] run function teleport:tp_advance/rtp/rtp_tp_red',
            ]
        }
    },
    allowRTP: {
        index: "allowRTP",
        icon: "minecraft:lime_stained_glass_pane",
        iconNbt: {
            display: {
                Name: '{"text":"允许成为随机传送目标","color":"gold","italic":"false"}',
                Lore: ['{"text":"默认为阻止","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 3,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'function teleport:tp_advance/rtp/rtp_allow',
            ]
        }
    },
    abandonRTP: {
        index: "abandonRTP",
        icon: "minecraft:red_stained_glass_pane",
        iconNbt: {
            display: {
                Name: '{"text":"阻止自己成为随机传送目标","color":"gold","italic":"false"}',
                Lore: ['{"text":"默认为阻止","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 4,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'function teleport:tp_advance/rtp/rtp_abandon',
            ]
        }
    },
    supportTP: {
        index: "supportTP",
        icon: "beacon",
        iconNbt: {
            display: {
                Name: '{"text":"复活至支援信标","color":"gold","italic":"false"}',
                Lore: ['{"text":"当场上存在支援信标时可用，信标提示见整备区标识。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 6,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'execute if entity @e[name="支援信标",team=EA,tag=RespawnSet] run function teleport:tp_advance/beacon/beacon_tp_red',
            ]
        }
    },
    /* vehicleTP: {
        index: "vehicleTP",
        icon: "beacon",
        iconNbt: {
            display: {
                Name: '{"text":"复活至步兵战车","color":"gold","italic":"false"}',
                Lore: ['{"text":"当场上存在可行动的步兵战车时可用。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 7,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'execute if entity @e[name="载具信标",team=EA] run function teleport:tp_advance/beacon/vehicle_tp_red',
            ]
        }
    }, */
}
const 寺庙REDTP = {
    description: {
        index: "寺庙REDTP",
        type: "none",
        title: Text.black('『东联传送菜单』'),
        leftButton: {
            icon: 'createdeco:decal_left',
            iconNbt: {
                display: {
                    Name: '{"text":"退出","color":"red","italic":"false"}',
                    Lore: ['{"text":"按esc有一样的效果","color":"gray","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "exit",
            }
        },

    },
    spawnPoint1: {
        index: "spawnPoint1",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点1","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 1,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function teleport:tp_spawn/tp_spawneffect',
                'spreadplayers 4366 2464 0 100 true @s'
            ]
        }
    },
/*     spawnPoint2: {
        index: "spawnPoint2",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点2","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 3,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function teleport:tp_spawn/tp_spawneffect',
                'spreadplayers 1542 -1945 0 5 true @s'
            ]
        }
    }, */
    /* 
    spawnPoint3: {
        index: "spawnPoint3",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点3","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 5,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function teleport:tp_spawn/tp_spawneffect',
                'spreadplayers -280 -27 0 15 true @s'
            ]
        }
    }, */
    /* PointA: {
        index: "PointA",
        icon: "minecraft:red_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点A","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'bo', Color: 14 }] }
        },
        location: {
            x: 1,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score A点 DominationHide matches 1 run function teleport:tp_point/tp_pointeffect',
                'execute if score A点 DominationHide matches 1 run tp @s 1351 0 -2171'
            ]
        }
    },
    PointB: {
        index: "PointB",
        icon: "minecraft:red_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点B","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'cbo', Color: 14 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'bo', Color: 14 }] }
        },
        location: {
            x: 2,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score B点 DominationHide matches 1 run function teleport:tp_point/tp_pointeffect',
                'execute if score B点 DominationHide matches 1 run tp @s 1455 5 -2183'
            ]
        }
    },
    PointC: {
        index: "PointC",
        icon: "minecraft:red_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点C","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'ts', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'rs', Color: 0 }, { Pattern: 'ms', Color: 14 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'bo', Color: 14 }] }
        },
        location: {
            x: 3,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score C点 DominationHide matches 1 run function teleport:tp_point/tp_pointeffect',
                'execute if score C点 DominationHide matches 1 run tp @s 1540 0 -2180'
            ]
        }
    }, */
    /* PointD: {
        index: "PointD",
        icon: "minecraft:red_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点D","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'cbo', Color: 14 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'bo', Color: 14 }] }
        },
        location: {
            x: 4,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score D点 DominationHide matches 1 run function teleport:tp_point/tp_pointeffect',
                'execute if score D点 DominationHide matches 1 run tp @s -287 2 -777'
            ]
        }
    },
    PointE: {
        index: "PointE",
        icon: "minecraft:red_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点E","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'ls', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'bo', Color: 14 }] }
        },
        location: {
            x: 5,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score E点 DominationHide matches 1 run function teleport:tp_point/tp_pointeffect',
                'execute if score E点 DominationHide matches 1 run tp @s -133 2 -380'
            ]
        }
    }, */
    RTP: {
        index: "RTP",
        icon: "spawner",
        iconNbt: {
            display: {
                Name: '{"text":"复活至随机队友","color":"gold","italic":"false"}',
                Lore: ['{"text":"对方必须允许自己成为随机传送目标，且周围没有敌人。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 1,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'execute if entity @a[team=EA,distance=200..,tag=RTP,tag=!RTP_Danger] run function teleport:tp_advance/rtp/rtp_tp_red',
            ]
        }
    },
    allowRTP: {
        index: "allowRTP",
        icon: "minecraft:lime_stained_glass_pane",
        iconNbt: {
            display: {
                Name: '{"text":"允许成为随机传送目标","color":"gold","italic":"false"}',
                Lore: ['{"text":"默认为阻止","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 3,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'function teleport:tp_advance/rtp/rtp_allow',
            ]
        }
    },
    abandonRTP: {
        index: "abandonRTP",
        icon: "minecraft:red_stained_glass_pane",
        iconNbt: {
            display: {
                Name: '{"text":"阻止自己成为随机传送目标","color":"gold","italic":"false"}',
                Lore: ['{"text":"默认为阻止","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 4,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'function teleport:tp_advance/rtp/rtp_abandon',
            ]
        }
    },
    supportTP: {
        index: "supportTP",
        icon: "beacon",
        iconNbt: {
            display: {
                Name: '{"text":"复活至支援信标","color":"gold","italic":"false"}',
                Lore: ['{"text":"当场上存在支援信标时可用，信标提示见整备区标识。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 6,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'execute if entity @e[name="支援信标",team=EA,tag=RespawnSet] run function teleport:tp_advance/beacon/beacon_tp_red',
            ]
        }
    },
    /* vehicleTP: {
        index: "vehicleTP",
        icon: "beacon",
        iconNbt: {
            display: {
                Name: '{"text":"复活至步兵战车","color":"gold","italic":"false"}',
                Lore: ['{"text":"当场上存在可行动的步兵战车时可用。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 7,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'execute if entity @e[name="载具信标",team=EA] run function teleport:tp_advance/beacon/vehicle_tp_red',
            ]
        }
    }, */
}
//--------------------------------
const 东欧BLUETP = {
    description: {
        index: "东欧BLUETP",
        type: "none",
        title: Text.black('『盟军传送菜单』'),
        leftButton: {
            icon: 'createdeco:decal_left',
            iconNbt: {
                display: {
                    Name: '{"text":"退出","color":"red","italic":"false"}',
                    Lore: ['{"text":"按esc有一样的效果","color":"gray","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "exit",
            }
        },

    },
    spawnPoint1: {
        index: "spawnPoint1",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点1","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 1,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function teleport:tp_spawn/tp_spawneffect',
                'spreadplayers -956 -748 0 15 true @s'
            ]
        }
    },
    spawnPoint2: {
        index: "spawnPoint2",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点2","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 3,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function teleport:tp_spawn/tp_spawneffect',
                'spreadplayers -956 -648 0 15 true @s'
            ]
        }
    },
    spawnPoint3: {
        index: "spawnPoint3",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点3","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 5,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function teleport:tp_spawn/tp_spawneffect',
                'spreadplayers -956 -528 0 15 true @s'
            ]
        }
    },
    PointA: {
        index: "PointA",
        icon: "minecraft:light_blue_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点A","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'bo', Color: 3 }] }
        },
        location: {
            x: 1,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score A点 DominationHide matches 0 run function teleport:tp_point/tp_pointeffect',
                'execute if score A点 DominationHide matches 0 run tp @s -374 3 -566'
            ]
        }
    },
    PointB: {
        index: "PointB",
        icon: "minecraft:light_blue_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点B","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'cbo', Color: 3 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'bo', Color: 3 }] }
        },
        location: {
            x: 2,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score B点 DominationHide matches 0 run function teleport:tp_point/tp_pointeffect',
                'execute if score B点 DominationHide matches 0 run tp @s -653 4 -588'
            ]
        }
    },
    PointC: {
        index: "PointC",
        icon: "minecraft:light_blue_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点C","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'ts', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'rs', Color: 0 }, { Pattern: 'ms', Color: 3 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'bo', Color: 3 }] }
        },
        location: {
            x: 3,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score C点 DominationHide matches 0 run function teleport:tp_point/tp_pointeffect',
                'execute if score C点 DominationHide matches 0 run tp @s -780 16 -399'
            ]
        }
    },
    PointD: {
        index: "PointD",
        icon: "minecraft:light_blue_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点D","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'cbo', Color: 3 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'bo', Color: 3 }] }
        },
        location: {
            x: 4,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score D点 DominationHide matches 0 run function teleport:tp_point/tp_pointeffect',
                'execute if score D点 DominationHide matches 0 run tp @s -287 2 -777'
            ]
        }
    },
    PointE: {
        index: "PointE",
        icon: "minecraft:light_blue_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点E","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'ls', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'bo', Color: 3 }] }
        },
        location: {
            x: 5,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score E点 DominationHide matches 0 run function teleport:tp_point/tp_pointeffect',
                'execute if score E点 DominationHide matches 0 run tp @s -133 2 -380'
            ]
        }
    },
    RTP: {
        index: "RTP",
        icon: "spawner",
        iconNbt: {
            display: {
                Name: '{"text":"复活至随机队友","color":"gold","italic":"false"}',
                Lore: ['{"text":"对方必须允许自己成为随机传送目标，且周围没有敌人。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 1,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'execute if entity @a[team=WE,distance=200..,tag=RTP,tag=!RTP_Danger] run function teleport:tp_advance/rtp/rtp_tp_blue',
            ]
        }
    },
    allowRTP: {
        index: "allowRTP",
        icon: "minecraft:lime_stained_glass_pane",
        iconNbt: {
            display: {
                Name: '{"text":"允许成为随机传送目标","color":"gold","italic":"false"}',
                Lore: ['{"text":"默认为阻止","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 3,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'function teleport:tp_advance/rtp/rtp_allow',
            ]
        }
    },
    abandonRTP: {
        index: "abandonRTP",
        icon: "minecraft:red_stained_glass_pane",
        iconNbt: {
            display: {
                Name: '{"text":"阻止自己成为随机传送目标","color":"gold","italic":"false"}',
                Lore: ['{"text":"默认为阻止","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 4,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'function teleport:tp_advance/rtp/rtp_abandon',
            ]
        }
    },
    supportTP: {
        index: "supportTP",
        icon: "beacon",
        iconNbt: {
            display: {
                Name: '{"text":"复活至支援信标","color":"gold","italic":"false"}',
                Lore: ['{"text":"当场上存在支援信标时可用，信标提示见整备区标识。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 6,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'execute if entity @e[name="支援信标",team=WE,tag=RespawnSet] run function teleport:tp_advance/beacon/beacon_tp_blue',
            ]
        }
    },
    vehicleTP: {
        index: "vehicleTP",
        icon: "beacon",
        iconNbt: {
            display: {
                Name: '{"text":"复活至步兵战车","color":"gold","italic":"false"}',
                Lore: ['{"text":"当场上存在可行动的步兵战车时可用。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 7,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'execute if entity @e[name="载具信标",team=WE] run function teleport:tp_advance/beacon/vehicle_tp_blue',
            ]
        }
    },
}
const 海岛BLUETP = {
    description: {
        index: "海岛BLUETP",
        type: "none",
        title: Text.black('『盟军传送菜单』'),
        leftButton: {
            icon: 'createdeco:decal_left',
            iconNbt: {
                display: {
                    Name: '{"text":"退出","color":"red","italic":"false"}',
                    Lore: ['{"text":"按esc有一样的效果","color":"gray","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "exit",
            }
        },

    },
    spawnPoint1: {
        index: "spawnPoint1",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点1","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 1,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function teleport:tp_spawn/tp_spawneffect',
                'spreadplayers 1612 253 0 5 true @s'
            ]
        }
    },
    spawnPoint2: {
        index: "spawnPoint2",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点2","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 3,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function teleport:tp_spawn/tp_spawneffect',
                'spreadplayers 1605 387 0 5 true @s'
            ]
        }
    },
    spawnPoint3: {
        index: "spawnPoint3",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点3","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 5,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function teleport:tp_spawn/tp_spawneffect',
                'spreadplayers 1546 521 0 5 true @s'
            ]
        }
    },
    PointA: {
        index: "PointA",
        icon: "minecraft:light_blue_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点A","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'bo', Color: 3 }] }
        },
        location: {
            x: 1,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score A点 DominationHide matches 0 run function teleport:tp_point/tp_pointeffect',
                'execute if score A点 DominationHide matches 0 run tp @s 872 13 358'
            ]
        }
    },
    PointB: {
        index: "PointB",
        icon: "minecraft:light_blue_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点B","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'cbo', Color: 3 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'bo', Color: 3 }] }
        },
        location: {
            x: 2,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score B点 DominationHide matches 0 run function teleport:tp_point/tp_pointeffect',
                'execute if score B点 DominationHide matches 0 run tp @s 962 16 170'
            ]
        }
    },
    PointC: {
        index: "PointC",
        icon: "minecraft:light_blue_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点C","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'ts', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'rs', Color: 0 }, { Pattern: 'ms', Color: 3 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'bo', Color: 3 }] }
        },
        location: {
            x: 3,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score C点 DominationHide matches 0 run function teleport:tp_point/tp_pointeffect',
                'execute if score C点 DominationHide matches 0 run tp @s 1288 19 287'
            ]
        }
    },
    PointD: {
        index: "PointD",
        icon: "minecraft:light_blue_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点D","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'cbo', Color: 3 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'bo', Color: 3 }] }
        },
        location: {
            x: 4,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score D点 DominationHide matches 0 run function teleport:tp_point/tp_pointeffect',
                'execute if score D点 DominationHide matches 0 run tp @s 1173 19 466'
            ]
        }
    },
    PointE: {
        index: "PointE",
        icon: "minecraft:light_blue_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点E","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'ls', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'bo', Color: 3 }] }
        },
        location: {
            x: 5,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score E点 DominationHide matches 0 run function teleport:tp_point/tp_pointeffect',
                'execute if score E点 DominationHide matches 0 run tp @s 1138 20 160'
            ]
        }
    },
    RTP: {
        index: "RTP",
        icon: "spawner",
        iconNbt: {
            display: {
                Name: '{"text":"复活至随机队友","color":"gold","italic":"false"}',
                Lore: ['{"text":"对方必须允许自己成为随机传送目标，且周围没有敌人。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 1,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'execute if entity @a[team=WE,distance=200..,tag=RTP,tag=!RTP_Danger] run function teleport:tp_advance/rtp/rtp_tp_blue',
            ]
        }
    },
    allowRTP: {
        index: "allowRTP",
        icon: "minecraft:lime_stained_glass_pane",
        iconNbt: {
            display: {
                Name: '{"text":"允许成为随机传送目标","color":"gold","italic":"false"}',
                Lore: ['{"text":"默认为阻止","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 3,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'function teleport:tp_advance/rtp/rtp_allow',
            ]
        }
    },
    abandonRTP: {
        index: "abandonRTP",
        icon: "minecraft:red_stained_glass_pane",
        iconNbt: {
            display: {
                Name: '{"text":"阻止自己成为随机传送目标","color":"gold","italic":"false"}',
                Lore: ['{"text":"默认为阻止","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 4,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'function teleport:tp_advance/rtp/rtp_abandon',
            ]
        }
    },
    supportTP: {
        index: "supportTP",
        icon: "beacon",
        iconNbt: {
            display: {
                Name: '{"text":"复活至支援信标","color":"gold","italic":"false"}',
                Lore: ['{"text":"当场上存在支援信标时可用，信标提示见整备区标识。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 6,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'execute if entity @e[name="支援信标",team=WE,tag=RespawnSet] run function teleport:tp_advance/beacon/beacon_tp_blue',
            ]
        }
    },
    vehicleTP: {
        index: "vehicleTP",
        icon: "beacon",
        iconNbt: {
            display: {
                Name: '{"text":"复活至步兵战车","color":"gold","italic":"false"}',
                Lore: ['{"text":"当场上存在可行动的步兵战车时可用。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 7,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'execute if entity @e[name="载具信标",team=WE] run function teleport:tp_advance/beacon/vehicle_tp_blue',
            ]
        }
    },
}
const 中东BLUETP = {
    description: {
        index: "中东BLUETP",
        type: "none",
        title: Text.black('『盟军传送菜单』'),
        leftButton: {
            icon: 'createdeco:decal_left',
            iconNbt: {
                display: {
                    Name: '{"text":"退出","color":"red","italic":"false"}',
                    Lore: ['{"text":"按esc有一样的效果","color":"gray","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "exit",
            }
        },

    },
    spawnPoint1: {
        index: "spawnPoint1",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点1","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 1,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function teleport:tp_spawn/tp_spawneffect',
                'spreadplayers 1232 -383 0 8 true @s'
            ]
        }
    },
    spawnPoint2: {
        index: "spawnPoint2",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点2","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 3,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function teleport:tp_spawn/tp_spawneffect',
                'spreadplayers 1549 -379 0 8 true @s'
            ]
        }
    },
    spawnPoint3: {
        index: "spawnPoint3",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点3","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 5,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function teleport:tp_spawn/tp_spawneffect',
                'spreadplayers 1735 -379 0 8 true @s'
            ]
        }
    },
    PointA: {
        index: "PointA",
        icon: "minecraft:light_blue_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点A","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'bo', Color: 3 }] }
        },
        location: {
            x: 1,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score A点 DominationHide matches 0 run function teleport:tp_point/tp_pointeffect',
                'execute if score A点 DominationHide matches 0 run tp @s 1688 6 -584'
            ]
        }
    },
    PointB: {
        index: "PointB",
        icon: "minecraft:light_blue_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点B","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'cbo', Color: 3 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'bo', Color: 3 }] }
        },
        location: {
            x: 2,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score B点 DominationHide matches 0 run function teleport:tp_point/tp_pointeffect',
                'execute if score B点 DominationHide matches 0 run tp @s 1358 235 -900'
            ]
        }
    },
    PointC: {
        index: "PointC",
        icon: "minecraft:light_blue_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点C","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'ts', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'rs', Color: 0 }, { Pattern: 'ms', Color: 3 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'bo', Color: 3 }] }
        },
        location: {
            x: 3,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score C点 DominationHide matches 0 run function teleport:tp_point/tp_pointeffect',
                'execute if score C点 DominationHide matches 0 run tp @s 1640 -5 -1270'
            ]
        }
    },
    PointD: {
        index: "PointD",
        icon: "minecraft:light_blue_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点D","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'cbo', Color: 3 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'bo', Color: 3 }] }
        },
        location: {
            x: 4,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score D点 DominationHide matches 0 run function teleport:tp_point/tp_pointeffect',
                'execute if score D点 DominationHide matches 0 run tp @s 1281 1 -535'
            ]
        }
    },
    PointE: {
        index: "PointE",
        icon: "minecraft:light_blue_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点E","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'ls', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'bo', Color: 3 }] }
        },
        location: {
            x: 5,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score E点 DominationHide matches 0 run function teleport:tp_point/tp_pointeffect',
                'execute if score E点 DominationHide matches 0 run tp @s 1577 1 -886'
            ]
        }
    },
    RTP: {
        index: "RTP",
        icon: "spawner",
        iconNbt: {
            display: {
                Name: '{"text":"复活至随机队友","color":"gold","italic":"false"}',
                Lore: ['{"text":"对方必须允许自己成为随机传送目标，且周围没有敌人。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 1,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'execute if entity @a[team=WE,distance=200..,tag=RTP,tag=!RTP_Danger] run function teleport:tp_advance/rtp/rtp_tp_blue',
            ]
        }
    },
    allowRTP: {
        index: "allowRTP",
        icon: "minecraft:lime_stained_glass_pane",
        iconNbt: {
            display: {
                Name: '{"text":"允许成为随机传送目标","color":"gold","italic":"false"}',
                Lore: ['{"text":"默认为阻止","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 3,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'function teleport:tp_advance/rtp/rtp_allow',
            ]
        }
    },
    abandonRTP: {
        index: "abandonRTP",
        icon: "minecraft:red_stained_glass_pane",
        iconNbt: {
            display: {
                Name: '{"text":"阻止自己成为随机传送目标","color":"gold","italic":"false"}',
                Lore: ['{"text":"默认为阻止","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 4,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'function teleport:tp_advance/rtp/rtp_abandon',
            ]
        }
    },
    supportTP: {
        index: "supportTP",
        icon: "beacon",
        iconNbt: {
            display: {
                Name: '{"text":"复活至支援信标","color":"gold","italic":"false"}',
                Lore: ['{"text":"当场上存在支援信标时可用，信标提示见整备区标识。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 6,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'execute if entity @e[name="支援信标",team=WE,tag=RespawnSet] run function teleport:tp_advance/beacon/beacon_tp_blue',
            ]
        }
    },
    vehicleTP: {
        index: "vehicleTP",
        icon: "beacon",
        iconNbt: {
            display: {
                Name: '{"text":"复活至步兵战车","color":"gold","italic":"false"}',
                Lore: ['{"text":"当场上存在可行动的步兵战车时可用。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 7,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'execute if entity @e[name="载具信标",team=WE] run function teleport:tp_advance/beacon/vehicle_tp_blue',
            ]
        }
    },
}
const 雪山BLUETP = {
    description: {
        index: "雪山BLUETP",
        type: "none",
        title: Text.black('『盟军传送菜单』'),
        leftButton: {
            icon: 'createdeco:decal_left',
            iconNbt: {
                display: {
                    Name: '{"text":"退出","color":"red","italic":"false"}',
                    Lore: ['{"text":"按esc有一样的效果","color":"gray","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "exit",
            }
        },

    },
    spawnPoint1: {
        index: "spawnPoint1",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点1","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 1,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function teleport:tp_spawn/tp_spawneffect',
                'spreadplayers -366 -2688 0 5 true @s'
            ]
        }
    },
    /* spawnPoint2: {
        index: "spawnPoint2",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点2","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 3,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function teleport:tp_spawn/tp_spawneffect',
                'spreadplayers -249 -1074 0 15 true @s'
            ]
        }
    },
    spawnPoint3: {
        index: "spawnPoint3",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点3","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 5,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function teleport:tp_spawn/tp_spawneffect',
                'spreadplayers -280 -27 0 15 true @s'
            ]
        }
    }, */
    PointA: {
        index: "PointA",
        icon: "minecraft:light_blue_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点A","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'bo', Color: 3 }] }
        },
        location: {
            x: 1,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score A点 DominationHide matches 0 run function teleport:tp_point/tp_pointeffect',
                'execute if score A点 DominationHide matches 0 run tp @s -381 240 -2606'
            ]
        }
    },
    PointB: {
        index: "PointB",
        icon: "minecraft:light_blue_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点B","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'cbo', Color: 3 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'bo', Color: 3 }] }
        },
        location: {
            x: 2,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score B点 DominationHide matches 0 run function teleport:tp_point/tp_pointeffect',
                'execute if score B点 DominationHide matches 0 run tp @s -360 183 -2347'
            ]
        }
    },
    PointC: {
        index: "PointC",
        icon: "minecraft:light_blue_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点C","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'ts', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'rs', Color: 0 }, { Pattern: 'ms', Color: 3 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'bo', Color: 3 }] }
        },
        location: {
            x: 3,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score C点 DominationHide matches 0 run function teleport:tp_point/tp_pointeffect',
                'execute if score C点 DominationHide matches 0 run tp @s -727 247 -2294'
            ]
        }
    },
    PointD: {
        index: "PointD",
        icon: "minecraft:light_blue_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点D","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'cbo', Color: 3 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'bo', Color: 3 }] }
        },
        location: {
            x: 4,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score D点 DominationHide matches 0 run function teleport:tp_point/tp_pointeffect',
                'execute if score D点 DominationHide matches 0 run tp @s -365 189 -2455'
            ]
        }
    },
    PointE: {
        index: "PointE",
        icon: "minecraft:light_blue_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点E","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'ls', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'bo', Color: 3 }] }
        },
        location: {
            x: 5,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score E点 DominationHide matches 0 run function teleport:tp_point/tp_pointeffect',
                'execute if score E点 DominationHide matches 0 run tp @s -553 123 -2407'
            ]
        }
    },
    RTP: {
        index: "RTP",
        icon: "spawner",
        iconNbt: {
            display: {
                Name: '{"text":"复活至随机队友","color":"gold","italic":"false"}',
                Lore: ['{"text":"对方必须允许自己成为随机传送目标，且周围没有敌人。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 1,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'execute if entity @a[team=WE,distance=200..,tag=RTP,tag=!RTP_Danger] run function teleport:tp_advance/rtp/rtp_tp_blue',
            ]
        }
    },
    allowRTP: {
        index: "allowRTP",
        icon: "minecraft:lime_stained_glass_pane",
        iconNbt: {
            display: {
                Name: '{"text":"允许成为随机传送目标","color":"gold","italic":"false"}',
                Lore: ['{"text":"默认为阻止","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 3,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'function teleport:tp_advance/rtp/rtp_allow',
            ]
        }
    },
    abandonRTP: {
        index: "abandonRTP",
        icon: "minecraft:red_stained_glass_pane",
        iconNbt: {
            display: {
                Name: '{"text":"阻止自己成为随机传送目标","color":"gold","italic":"false"}',
                Lore: ['{"text":"默认为阻止","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 4,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'function teleport:tp_advance/rtp/rtp_abandon',
            ]
        }
    },
    supportTP: {
        index: "supportTP",
        icon: "beacon",
        iconNbt: {
            display: {
                Name: '{"text":"复活至支援信标","color":"gold","italic":"false"}',
                Lore: ['{"text":"当场上存在支援信标时可用，信标提示见整备区标识。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 6,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'execute if entity @e[name="支援信标",team=WE,tag=RespawnSet] run function teleport:tp_advance/beacon/beacon_tp_blue',
            ]
        }
    },
    vehicleTP: {
        index: "vehicleTP",
        icon: "beacon",
        iconNbt: {
            display: {
                Name: '{"text":"复活至步兵战车","color":"gold","italic":"false"}',
                Lore: ['{"text":"当场上存在可行动的步兵战车时可用。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 7,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'execute if entity @e[name="载具信标",team=WE] run function teleport:tp_advance/beacon/vehicle_tp_blue',
            ]
        }
    },
}
const 首府BLUETP = {
    description: {
        index: "首府BLUETP",
        type: "none",
        title: Text.black('『盟军传送菜单』'),
        leftButton: {
            icon: 'createdeco:decal_left',
            iconNbt: {
                display: {
                    Name: '{"text":"退出","color":"red","italic":"false"}',
                    Lore: ['{"text":"按esc有一样的效果","color":"gray","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "exit",
            }
        },

    },
    spawnPoint1: {
        index: "spawnPoint1",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点1","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 1,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function teleport:tp_spawn/tp_spawneffect',
                'spreadplayers 1025 -1992 0 5 true @s'
            ]
        }
    },
    /* spawnPoint2: {
        index: "spawnPoint2",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点2","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 3,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function teleport:tp_spawn/tp_spawneffect',
                'spreadplayers -249 -1074 0 15 true @s'
            ]
        }
    },
    spawnPoint3: {
        index: "spawnPoint3",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点3","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 5,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function teleport:tp_spawn/tp_spawneffect',
                'spreadplayers -280 -27 0 15 true @s'
            ]
        }
    }, */
    PointA: {
        index: "PointA",
        icon: "minecraft:light_blue_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点A","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'bo', Color: 3 }] }
        },
        location: {
            x: 1,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score A点 DominationHide matches 0 run function teleport:tp_point/tp_pointeffect',
                'execute if score A点 DominationHide matches 0 run tp @s 1049 -13 -2118'
            ]
        }
    },
    PointB: {
        index: "PointB",
        icon: "minecraft:light_blue_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点B","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'cbo', Color: 3 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'bo', Color: 3 }] }
        },
        location: {
            x: 2,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score B点 DominationHide matches 0 run function teleport:tp_point/tp_pointeffect',
                'execute if score B点 DominationHide matches 0 run tp @s 1002 -6 -2119'
            ]
        }
    },
    PointC: {
        index: "PointC",
        icon: "minecraft:light_blue_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点C","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'ts', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'rs', Color: 0 }, { Pattern: 'ms', Color: 3 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'bo', Color: 3 }] }
        },
        location: {
            x: 3,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score C点 DominationHide matches 0 run function teleport:tp_point/tp_pointeffect',
                'execute if score C点 DominationHide matches 0 run tp @s 986 -8 -2051'
            ]
        }
    },
    /* PointD: {
        index: "PointD",
        icon: "minecraft:light_blue_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点D","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'cbo', Color: 3 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'bo', Color: 3 }] }
        },
        location: {
            x: 4,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score D点 DominationHide matches 0 run function teleport:tp_point/tp_pointeffect',
                'execute if score D点 DominationHide matches 0 run tp @s -287 2 -777'
            ]
        }
    },
    PointE: {
        index: "PointE",
        icon: "minecraft:light_blue_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点E","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'ls', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'bo', Color: 3 }] }
        },
        location: {
            x: 5,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score E点 DominationHide matches 0 run function teleport:tp_point/tp_pointeffect',
                'execute if score E点 DominationHide matches 0 run tp @s -133 2 -380'
            ]
        }
    }, */
    RTP: {
        index: "RTP",
        icon: "spawner",
        iconNbt: {
            display: {
                Name: '{"text":"复活至随机队友","color":"gold","italic":"false"}',
                Lore: ['{"text":"对方必须允许自己成为随机传送目标，且周围没有敌人。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 1,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'execute if entity @a[team=WE,distance=200..,tag=RTP,tag=!RTP_Danger] run function teleport:tp_advance/rtp/rtp_tp_blue',
            ]
        }
    },
    allowRTP: {
        index: "allowRTP",
        icon: "minecraft:lime_stained_glass_pane",
        iconNbt: {
            display: {
                Name: '{"text":"允许成为随机传送目标","color":"gold","italic":"false"}',
                Lore: ['{"text":"默认为阻止","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 3,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'function teleport:tp_advance/rtp/rtp_allow',
            ]
        }
    },
    abandonRTP: {
        index: "abandonRTP",
        icon: "minecraft:red_stained_glass_pane",
        iconNbt: {
            display: {
                Name: '{"text":"阻止自己成为随机传送目标","color":"gold","italic":"false"}',
                Lore: ['{"text":"默认为阻止","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 4,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'function teleport:tp_advance/rtp/rtp_abandon',
            ]
        }
    },
    supportTP: {
        index: "supportTP",
        icon: "beacon",
        iconNbt: {
            display: {
                Name: '{"text":"复活至支援信标","color":"gold","italic":"false"}',
                Lore: ['{"text":"当场上存在支援信标时可用，信标提示见整备区标识。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 6,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'execute if entity @e[name="支援信标",team=WE,tag=RespawnSet] run function teleport:tp_advance/beacon/beacon_tp_blue',
            ]
        }
    },
}
const 越南BLUETP = {
    description: {
        index: "越南BLUETP",
        type: "none",
        title: Text.black('『盟军传送菜单』'),
        leftButton: {
            icon: 'createdeco:decal_left',
            iconNbt: {
                display: {
                    Name: '{"text":"退出","color":"red","italic":"false"}',
                    Lore: ['{"text":"按esc有一样的效果","color":"gray","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "exit",
            }
        },

    },
    spawnPoint1: {
        index: "spawnPoint1",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点1","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 1,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function teleport:tp_spawn/tp_spawneffect',
                'spreadplayers 2990 2771 0 15 true @s'
            ]
        }
    },
    spawnPoint2: {
        index: "spawnPoint2",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点2","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 3,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function teleport:tp_spawn/tp_spawneffect',
                'spreadplayers 3200 3420 0 15 true @s'
            ]
        }
    },
    spawnPoint3: {
        index: "spawnPoint3",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点3","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 5,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function teleport:tp_spawn/tp_spawneffect',
                'spreadplayers -280 -27 0 15 true @s'
            ]
        }
    },
    PointA: {
        index: "PointA",
        icon: "minecraft:light_blue_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点A","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'bo', Color: 3 }] }
        },
        location: {
            x: 1,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score A点 DominationHide matches 0 run function teleport:tp_point/tp_pointeffect',
                'execute if score A点 DominationHide matches 0 run tp @s 3495 -42 2945'
            ]
        }
    },
    PointB: {
        index: "PointB",
        icon: "minecraft:light_blue_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点B","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'cbo', Color: 3 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'bo', Color: 3 }] }
        },
        location: {
            x: 2,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score B点 DominationHide matches 0 run function teleport:tp_point/tp_pointeffect',
                'execute if score B点 DominationHide matches 0 run tp @s 3991 -44 2896'
            ]
        }
    },
    PointC: {
        index: "PointC",
        icon: "minecraft:light_blue_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点C","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'ts', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'rs', Color: 0 }, { Pattern: 'ms', Color: 3 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'bo', Color: 3 }] }
        },
        location: {
            x: 3,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score C点 DominationHide matches 0 run function teleport:tp_point/tp_pointeffect',
                'execute if score C点 DominationHide matches 0 run tp @s 4471 -41 2695'
            ]
        }
    },
    PointD: {
        index: "PointD",
        icon: "minecraft:light_blue_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点D","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'cbo', Color: 3 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'bo', Color: 3 }] }
        },
        location: {
            x: 4,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score D点 DominationHide matches 0 run function teleport:tp_point/tp_pointeffect',
                'execute if score D点 DominationHide matches 0 run tp @s 3713 -45 3193'
            ]
        }
    },
    PointE: {
        index: "PointE",
        icon: "minecraft:light_blue_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点E","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'ls', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'bo', Color: 3 }] }
        },
        location: {
            x: 5,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score E点 DominationHide matches 0 run function teleport:tp_point/tp_pointeffect',
                'execute if score E点 DominationHide matches 0 run tp @s 4356 -45 3078'
            ]
        }
    },
    RTP: {
        index: "RTP",
        icon: "spawner",
        iconNbt: {
            display: {
                Name: '{"text":"复活至随机队友","color":"gold","italic":"false"}',
                Lore: ['{"text":"对方必须允许自己成为随机传送目标，且周围没有敌人。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 1,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'execute if entity @a[team=WE,distance=200..,tag=RTP,tag=!RTP_Danger] run function teleport:tp_advance/rtp/rtp_tp_blue',
            ]
        }
    },
    allowRTP: {
        index: "allowRTP",
        icon: "minecraft:lime_stained_glass_pane",
        iconNbt: {
            display: {
                Name: '{"text":"允许成为随机传送目标","color":"gold","italic":"false"}',
                Lore: ['{"text":"默认为阻止","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 3,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'function teleport:tp_advance/rtp/rtp_allow',
            ]
        }
    },
    abandonRTP: {
        index: "abandonRTP",
        icon: "minecraft:red_stained_glass_pane",
        iconNbt: {
            display: {
                Name: '{"text":"阻止自己成为随机传送目标","color":"gold","italic":"false"}',
                Lore: ['{"text":"默认为阻止","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 4,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'function teleport:tp_advance/rtp/rtp_abandon',
            ]
        }
    },
    supportTP: {
        index: "supportTP",
        icon: "beacon",
        iconNbt: {
            display: {
                Name: '{"text":"复活至支援信标","color":"gold","italic":"false"}',
                Lore: ['{"text":"当场上存在支援信标时可用，信标提示见整备区标识。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 6,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'execute if entity @e[name="支援信标",team=WE,tag=RespawnSet] run function teleport:tp_advance/beacon/beacon_tp_blue',
            ]
        }
    },
    vehicleTP: {
        index: "vehicleTP",
        icon: "beacon",
        iconNbt: {
            display: {
                Name: '{"text":"复活至步兵战车","color":"gold","italic":"false"}',
                Lore: ['{"text":"当场上存在可行动的步兵战车时可用。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 7,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'execute if entity @e[name="载具信标",team=WE] run function teleport:tp_advance/beacon/vehicle_tp_blue',
            ]
        }
    },
}
const 白宫BLUETP = {
    description: {
        index: "白宫BLUETP",
        type: "none",
        title: Text.black('『盟军传送菜单』'),
        leftButton: {
            icon: 'createdeco:decal_left',
            iconNbt: {
                display: {
                    Name: '{"text":"退出","color":"red","italic":"false"}',
                    Lore: ['{"text":"按esc有一样的效果","color":"gray","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "exit",
            }
        },

    },
    spawnPoint1: {
        index: "spawnPoint1",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点1","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 1,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function teleport:tp_spawn/tp_spawneffect',
                'spreadplayers 1371 -2407 0 5 true @s'
            ]
        }
    },
    spawnPoint2: {
        index: "spawnPoint2",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点2","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 3,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function teleport:tp_spawn/tp_spawneffect',
                'spreadplayers 1539 -2407 0 5 true @s'
            ]
        }
    },
    /* 
    spawnPoint3: {
        index: "spawnPoint3",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点3","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 5,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function teleport:tp_spawn/tp_spawneffect',
                'spreadplayers -280 -27 0 15 true @s'
            ]
        }
    }, */
    PointA: {
        index: "PointA",
        icon: "minecraft:light_blue_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点A","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'bo', Color: 3 }] }
        },
        location: {
            x: 1,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score A点 DominationHide matches 0 run function teleport:tp_point/tp_pointeffect',
                'execute if score A点 DominationHide matches 0 run tp @s 1351 0 -2171'
            ]
        }
    },
    PointB: {
        index: "PointB",
        icon: "minecraft:light_blue_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点B","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'cbo', Color: 3 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'bo', Color: 3 }] }
        },
        location: {
            x: 2,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score B点 DominationHide matches 0 run function teleport:tp_point/tp_pointeffect',
                'execute if score B点 DominationHide matches 0 run tp @s 1455 5 -2183'
            ]
        }
    },
    PointC: {
        index: "PointC",
        icon: "minecraft:light_blue_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点C","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'ts', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'rs', Color: 0 }, { Pattern: 'ms', Color: 3 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'bo', Color: 3 }] }
        },
        location: {
            x: 3,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score C点 DominationHide matches 0 run function teleport:tp_point/tp_pointeffect',
                'execute if score C点 DominationHide matches 0 run tp @s 1540 0 -2180'
            ]
        }
    },
    /* PointD: {
        index: "PointD",
        icon: "minecraft:light_blue_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点D","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'cbo', Color: 3 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'bo', Color: 3 }] }
        },
        location: {
            x: 4,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score D点 DominationHide matches 0 run function teleport:tp_point/tp_pointeffect',
                'execute if score D点 DominationHide matches 0 run tp @s -287 2 -777'
            ]
        }
    },
    PointE: {
        index: "PointE",
        icon: "minecraft:light_blue_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点E","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'ls', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'bo', Color: 3 }] }
        },
        location: {
            x: 5,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score E点 DominationHide matches 0 run function teleport:tp_point/tp_pointeffect',
                'execute if score E点 DominationHide matches 0 run tp @s -133 2 -380'
            ]
        }
    }, */
    RTP: {
        index: "RTP",
        icon: "spawner",
        iconNbt: {
            display: {
                Name: '{"text":"复活至随机队友","color":"gold","italic":"false"}',
                Lore: ['{"text":"对方必须允许自己成为随机传送目标，且周围没有敌人。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 1,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'execute if entity @a[team=WE,distance=200..,tag=RTP,tag=!RTP_Danger] run function teleport:tp_advance/rtp/rtp_tp_blue',
            ]
        }
    },
    allowRTP: {
        index: "allowRTP",
        icon: "minecraft:lime_stained_glass_pane",
        iconNbt: {
            display: {
                Name: '{"text":"允许成为随机传送目标","color":"gold","italic":"false"}',
                Lore: ['{"text":"默认为阻止","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 3,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'function teleport:tp_advance/rtp/rtp_allow',
            ]
        }
    },
    abandonRTP: {
        index: "abandonRTP",
        icon: "minecraft:red_stained_glass_pane",
        iconNbt: {
            display: {
                Name: '{"text":"阻止自己成为随机传送目标","color":"gold","italic":"false"}',
                Lore: ['{"text":"默认为阻止","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 4,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'function teleport:tp_advance/rtp/rtp_abandon',
            ]
        }
    },
    supportTP: {
        index: "supportTP",
        icon: "beacon",
        iconNbt: {
            display: {
                Name: '{"text":"复活至支援信标","color":"gold","italic":"false"}',
                Lore: ['{"text":"当场上存在支援信标时可用，信标提示见整备区标识。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 6,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'execute if entity @e[name="支援信标",team=WE,tag=RespawnSet] run function teleport:tp_advance/beacon/beacon_tp_blue',
            ]
        }
    },
/*     vehicleTP: {
        index: "vehicleTP",
        icon: "beacon",
        iconNbt: {
            display: {
                Name: '{"text":"复活至步兵战车","color":"gold","italic":"false"}',
                Lore: ['{"text":"当场上存在可行动的步兵战车时可用。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 7,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'execute if entity @e[name="载具信标",team=WE] run function teleport:tp_advance/beacon/vehicle_tp_blue',
            ]
        }
    }, */
}
const 寺庙BLUETP = {
    description: {
        index: "寺庙BLUETP",
        type: "none",
        title: Text.black('『盟军传送菜单』'),
        leftButton: {
            icon: 'createdeco:decal_left',
            iconNbt: {
                display: {
                    Name: '{"text":"退出","color":"red","italic":"false"}',
                    Lore: ['{"text":"按esc有一样的效果","color":"gray","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "exit",
            }
        },

    },
    spawnPoint1: {
        index: "spawnPoint1",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点1","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 1,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function teleport:tp_spawn/tp_spawneffect',
                'spreadplayers 4366 2464 0 100 true @s'
            ]
        }
    },
/*     spawnPoint2: {
        index: "spawnPoint2",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点2","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 3,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function teleport:tp_spawn/tp_spawneffect',
                'spreadplayers 1542 -1945 0 5 true @s'
            ]
        }
    }, */
    /* 
    spawnPoint3: {
        index: "spawnPoint3",
        icon: "clock",
        iconNbt: {
            display: {
                Name: '{"text":"出生点3","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 5,
            y: 2
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['function teleport:tp_spawn/tp_spawneffect',
                'spreadplayers -280 -27 0 15 true @s'
            ]
        }
    }, */
    /* PointA: {
        index: "PointA",
        icon: "minecraft:red_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点A","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'bo', Color: 14 }] }
        },
        location: {
            x: 1,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score A点 DominationHide matches 1 run function teleport:tp_point/tp_pointeffect',
                'execute if score A点 DominationHide matches 1 run tp @s 1351 0 -2171'
            ]
        }
    },
    PointB: {
        index: "PointB",
        icon: "minecraft:red_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点B","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'cbo', Color: 14 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'bo', Color: 14 }] }
        },
        location: {
            x: 2,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score B点 DominationHide matches 1 run function teleport:tp_point/tp_pointeffect',
                'execute if score B点 DominationHide matches 1 run tp @s 1455 5 -2183'
            ]
        }
    },
    PointC: {
        index: "PointC",
        icon: "minecraft:red_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点C","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'ts', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'rs', Color: 0 }, { Pattern: 'ms', Color: 14 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'bo', Color: 14 }] }
        },
        location: {
            x: 3,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score C点 DominationHide matches 1 run function teleport:tp_point/tp_pointeffect',
                'execute if score C点 DominationHide matches 1 run tp @s 1540 0 -2180'
            ]
        }
    }, */
    /* PointD: {
        index: "PointD",
        icon: "minecraft:red_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点D","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'rs', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'cbo', Color: 14 }, { Pattern: 'ls', Color: 0 }, { Pattern: 'bo', Color: 14 }] }
        },
        location: {
            x: 4,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score D点 DominationHide matches 1 run function teleport:tp_point/tp_pointeffect',
                'execute if score D点 DominationHide matches 1 run tp @s -287 2 -777'
            ]
        }
    },
    PointE: {
        index: "PointE",
        icon: "minecraft:red_banner",
        iconNbt: {
            display: {
                Name: '{"text":"目标点E","color":"gold","italic":"false"}',
                Lore: ['{"text":"","color":"gray","italic":"false"}'],
            },
            BlockEntityTag: { Patterns: [{ Pattern: 'ls', Color: 0 }, { Pattern: 'ts', Color: 0 }, { Pattern: 'ms', Color: 0 }, { Pattern: 'bs', Color: 0 }, { Pattern: 'bo', Color: 14 }] }
        },
        location: {
            x: 5,
            y: 3
        },
        leftClickAction: {
            type: "runCommand",
            commands: ['execute if score E点 DominationHide matches 1 run function teleport:tp_point/tp_pointeffect',
                'execute if score E点 DominationHide matches 1 run tp @s -133 2 -380'
            ]
        }
    }, */
    RTP: {
        index: "RTP",
        icon: "spawner",
        iconNbt: {
            display: {
                Name: '{"text":"复活至随机队友","color":"gold","italic":"false"}',
                Lore: ['{"text":"对方必须允许自己成为随机传送目标，且周围没有敌人。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 1,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'execute if entity @a[team=WE,distance=200..,tag=RTP,tag=!RTP_Danger] run function teleport:tp_advance/rtp/rtp_tp_blue',
            ]
        }
    },
    allowRTP: {
        index: "allowRTP",
        icon: "minecraft:lime_stained_glass_pane",
        iconNbt: {
            display: {
                Name: '{"text":"允许成为随机传送目标","color":"gold","italic":"false"}',
                Lore: ['{"text":"默认为阻止","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 3,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'function teleport:tp_advance/rtp/rtp_allow',
            ]
        }
    },
    abandonRTP: {
        index: "abandonRTP",
        icon: "minecraft:red_stained_glass_pane",
        iconNbt: {
            display: {
                Name: '{"text":"阻止自己成为随机传送目标","color":"gold","italic":"false"}',
                Lore: ['{"text":"默认为阻止","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 4,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'function teleport:tp_advance/rtp/rtp_abandon',
            ]
        }
    },
    supportTP: {
        index: "supportTP",
        icon: "beacon",
        iconNbt: {
            display: {
                Name: '{"text":"复活至支援信标","color":"gold","italic":"false"}',
                Lore: ['{"text":"当场上存在支援信标时可用，信标提示见整备区标识。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 6,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'execute if entity @e[name="支援信标",team=WE,tag=RespawnSet] run function teleport:tp_advance/beacon/beacon_tp_blue',
            ]
        }
    },
/*     vehicleTP: {
        index: "vehicleTP",
        icon: "beacon",
        iconNbt: {
            display: {
                Name: '{"text":"复活至步兵战车","color":"gold","italic":"false"}',
                Lore: ['{"text":"当场上存在可行动的步兵战车时可用。","color":"gray","italic":"false"}'],
            }
        },
        location: {
            x: 7,
            y: 4
        },
        leftClickAction: {
            type: "runCommand",
            commands: [
                'execute if entity @e[name="载具信标",team=WE] run function teleport:tp_advance/beacon/vehicle_tp_blue',
            ]
        }
    }, */
}


