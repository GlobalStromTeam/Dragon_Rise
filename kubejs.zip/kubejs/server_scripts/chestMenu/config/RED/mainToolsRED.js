/*
菜单类型：
    展示物品类：

    选择类（不可重复）：
        往下可分为选择物品id类和选择nbt类

    选择类（可重复）：


*/


/*
格式：
const xxx={
    description: {
    //index和对象名相同，用来索引
        index:"xxx"
        name: "xxx",
        //type决定显示方式
        type: "showSelection",
        //title是菜单标题
        title: Text.black('『配装菜单』'),
        //左按钮
        leftButton: {
        //按钮的图标对应物
            icon: 'createdeco:decal_left',
            name: "退出",
            lore: "按esc有一样的效果",
            //点击物品的行为
            leftClickAction: {
            //type决定点击之后的结果
                type: "exit",
            }
        },
        rightButton: {
            icon: 'minecraft:diamond_sword',
            name: "部署",
            lore: "一旦确定部署就不能重置！",
            leftClickAction: {
                type: "deploy"
            },
        }
    },
    aaa: {
        index:""
        icon: "",
        name: "aaa",
        lore: "",
        //location的x取值1-7，y取值1-4，是物品在
        菜单的位置
        location: {
            x: 1,
            y: 2
        },
        leftClickAction: {
        //changeMenu必须接它接下来去的菜单界面
            type: "changeMenu",
            get nextMenu() {
                return mainWeapons
            }
        },
    },
    bbb: {
        index:""
        icon: "",
        name: "bbb",
        lore: "",
        location: {
            x: 3,
            y: 2
        },
        leftClickAction: {
            type: "changeMenu",
            get nextMenu() {
                return subWeapons
            }
        }
    },
}
*/

const mainToolsRED = {
    description: {
        index: "mainToolsRED",
        type: "conductSelect",
        maxSelect: 1,
        title: Text.black('『主道具菜单』'),
        leftButton: {
            icon: 'createdeco:decal_left',
            iconNbt: {
                display: {
                    Name: '{"text":"返回","color":"gold","italic":"false"}',
                    Lore: ['{"text":"回到上一界面","color":"white","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "changeMenu",
                get nextMenu() {
                    return menuItemsRED
                }
            }
        },
        leftTopButton: {
            icon: 'createdeco:decal_warning',
            iconNbt: {
                display: {
                    Name: '{"text":"重置","color":"red","italic":"false"}',
                    Lore: ['{"text":"重置当前页面下的选择","color":"white","italic":"false"}'],
                }
            },
            leftClickAction: {
                type: "reset"
            },
        }
    },

    shield: {
        index: "shield",
        icon: 'minecraft:shield',
        iconNbt: {

            BlockEntityTag: {
                Patterns: [{ Pattern: "hh", Color: 3 },
                { Pattern: "ms", Color: 15 },
                { Pattern: "ts", Color: 15 },
                { Pattern: "cbo", Color: 15 },
                { Pattern: 'bo', Color: 7 }], Base: 15
            },
            display: {
                Name: '["",{"text":"防爆盾","italic":false,"color":"gray"}]',
                Lore: ['["",{"text":"置于副手时提供","italic":false,"color":"white"},{"text":"抗性提升2","italic":false,"color":"green"},{"text":"效果，举盾可以挡住部分子弹。","italic":false,"color":"white"}]', '["",{"text":"而且不可破坏。","italic":false,"color":"gray"}]']
            }, HideFlags: 32
        },
        location: {
            x: 1,
            y: 2
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                shield_1: {
                    id: 'minecraft:shield',
                    count: 1,
                    nbt: {
                        Unbreakable: true,
                        BlockEntityTag: {
                            Patterns: [{ Pattern: "hh", Color: 3 },
                            { Pattern: "ms", Color: 15 },
                            { Pattern: "ts", Color: 15 },
                            { Pattern: "cbo", Color: 15 },
                            { Pattern: 'bo', Color: 7 }], Base: 15
                        },
                        display: {
                            Name: '["",{"text":"防爆盾","italic":false,"color":"gray"}]',
                            Lore: ['["",{"text":"置于副手时提供","italic":false,"color":"white"},{"text":"抗性提升2","italic":false,"color":"green"},{"text":"效果，举盾可以挡住部分子弹。","italic":false,"color":"white"}]', '["",{"text":"而且不可破坏。","italic":false,"color":"gray"}]']
                        }, HideFlags: 32
                    }
                },
                shield_2: {
                    id: 'create:sturdy_sheet',
                    count: 1,
                    nbt: {
                        BulletproofCount: 12,
                        display: {
                            Name: '["",{"text":"强化防弹插板","italic":false,"color":"yellow"}]',
                            Lore: ['["",{"text":"插板护甲：12.0","italic":false,"color":"aqua"}]', '["",{"text":"插板上限为3个，使用时优先覆盖剩余护甲最低的插板。","italic":false,"color":"dark_aqua"}]']
                        }
                    }
                },
            }
        }
    },
    scout: {
        index: "scout",
        icon: 'minecraft:spyglass',
        iconNbt: {
            display: {
                Name: '["",{"text":"侦察","italic":false,"color":"blue"}]',
                Lore: [`["",{"text":"右键点亮视线指向的目标，使其和周围${scoutRadius}格目标发光","italic":false,"color":"white"},{"text":"${scoutGlowTime}s","italic":false,"color":"green"},{"text":"，距离不超过","italic":false,"color":"white"},{"text":"${scoutDistance}格","italic":false,"color":"green"},{"text":"，","italic":false,"color":"white"},{"text":"可以在一定程度上","italic":false,"color":"blue"},{"text":"穿墙点亮。","italic":false,"color":"white"}]`, '["",{"text":"可以重复点亮一个人，听到叮的一声就是点亮成功了。","italic":false,"color":"gray"}]']
            }
        },
        location: {
            x: 2,
            y: 2
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "single",
                id: 'minecraft:spyglass',
                count: 1,
                nbt: {
                    RayItem: Integer.parseInt('1'),
                    display: {
                        Name: '["",{"text":"侦察","italic":false,"color":"blue"}]',
                        Lore: [`["",{"text":"右键点亮视线指向的目标，使其和周围${scoutRadius}格目标发光","italic":false,"color":"white"},{"text":"${scoutGlowTime}s","italic":false,"color":"green"},{"text":"，距离不超过","italic":false,"color":"white"},{"text":"${scoutDistance}格","italic":false,"color":"green"},{"text":"，","italic":false,"color":"white"},{"text":"可以在一定程度上","italic":false,"color":"blue"},{"text":"穿墙点亮。","italic":false,"color":"white"}]`, '["",{"text":"可以重复点亮一个人，听到叮的一声就是点亮成功了。","italic":false,"color":"gray"}]']
                    }
                }
            }
        }
    },
    /* guardianRED: {
        index: "guardianRED",
        icon: 'minecraft:villager_spawn_egg',
        iconNbt: {
            display: {
                Name: '[{"text":"自动炮塔 Red","italic":false,"color":"red"}]',
                Lore: ['[{"text":"放置一个向30格内敌方单位攻击的村民，具有50点血量，可以占点。","italic":false,"color":"dark_green"},{"text":"","italic":false,"color":"dark_purple"}]', '[{"text":"（为什么是哈基民？）","italic":false,"color":"dark_red"}]']
            }
        },
        location: {
            x: 3,
            y: 2
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "single",
                id: 'minecraft:villager_spawn_egg',
                count: 3,
                nbt: {
                    EntityTag: {
                        id: "villager",
                        CustomName: '[{"text":"自动炮塔","color":"red"}]',
                        CustomNameVisible: true,
                        Health: 50,
                        Tags: ["archer"],
                        Silent: true,
                        Team: "EA",
                        ArmorItems: [{}, {}, {}, { id: 'red_banner', Count: 1 }],
                        ArmorDropChances: [0, 0, 0, 0],
                        Attributes: [
                            { Name: "generic.max_health", Base: 50 },
                            { Name: "generic.knockback_resistance", Base: 1 },
                            { Name: "generic.movement_speed", Base: -1 }
                        ]
                    },
                    display: {
                        Name: '[{"text":"自动炮塔 Red","italic":false,"color":"red"}]',
                        Lore: ['[{"text":"放置一个向30格内敌方单位攻击的村民，具有50点血量，可以占点。","italic":false,"color":"dark_green"},{"text":"","italic":false,"color":"dark_purple"}]', '[{"text":"（为什么是哈基民？）","italic":false,"color":"dark_red"}]']
                    }
                }
            }
        }
    }, */
    ammoBoxRED: {
        index: "ammoBoxRED",
        icon: 'minecraft:red_shulker_box',
        iconNbt: {
            display: {
                Name: '["",{"text":"补给箱 Red","italic":false,"color":"gold"}]',
                Lore: ['["",{"text":"绍伊古，格拉西莫夫！","italic":false,"color":"white"}]']
            }
        },
        location: {
            x: 4,
            y: 2
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "single",
                id: 'minecraft:red_shulker_box',
                count: 1,
                nbt: {
                    BlockEntityTag: {
                        Items: [{
                            Slot: 0, id: 'tacz:ammo', Count: 60, tag: {
                                AmmoId: "tacz:58x42"
                            }
                        },
                        {
                            Slot: 1, id: 'tacz:ammo', Count: 60, tag: {
                                AmmoId: "tacz:58x42"
                            }
                        },
                        {
                            Slot: 2, id: 'tacz:ammo', Count: 60, tag: {
                                AmmoId: "tacz:58x42"
                            }
                        },
                        {
                            Slot: 3, id: 'tacz:ammo', Count: 60, tag: {
                                AmmoId: "tacz:58x42"
                            }
                        },

                        {
                            Slot: 4, id: 'tacz:ammo', Count: 60, tag: {
                                AmmoId: "tacz:58x42"
                            }
                        },
                        {
                            Slot: 5, id: 'tacz:ammo', Count: 60, tag: {
                                AmmoId: "tacz:58x42"
                            }
                        },
                        //------------------
                        {
                            Slot: 6, id: 'tacz:ammo', Count: 60, tag: {
                                AmmoId: "tacz:762x39"
                            }
                        },
                        {
                            Slot: 7, id: 'tacz:ammo', Count: 60, tag: {
                                AmmoId: "tacz:762x39"
                            }
                        },
                        //---
                        {
                            Slot: 8, id: 'tacz:ammo', Count: 60, tag: {
                                AmmoId: "tacz:762x39"
                            }
                        },

                        {
                            Slot: 9, id: 'tacz:ammo', Count: 60, tag: {
                                AmmoId: "tacz:762x39"
                            }
                        },
                        {
                            Slot: 10, id: 'tacz:ammo', Count: 60, tag: {
                                AmmoId: "tacz:762x39"
                            }
                        },
                        //---
                        {
                            Slot: 11, id: 'tacz:ammo', Count: 60, tag: {
                                AmmoId: "tacz:762x39"
                            }
                        },
                        {
                            Slot: 12, id: 'tacz:ammo', Count: 60, tag: {
                                AmmoId: "tacz:545x39"
                            }
                        },
                        {
                            Slot: 13, id: 'tacz:ammo', Count: 60, tag: {
                                AmmoId: "tacz:545x39"
                            }
                        },
                        //---
                        {
                            Slot: 14, id: 'tacz:ammo', Count: 60, tag: {
                                AmmoId: "tacz:545x39"
                            }
                        },
                        {
                            Slot: 15, id: 'tacz:ammo', Count: 60, tag: {
                                AmmoId: "tacz:545x39"
                            }
                        },
                        {
                            Slot: 16, id: 'tacz:ammo', Count: 60, tag: {
                                AmmoId: "tacz:9x39"
                            }
                        },
                        {
                            Slot: 17, id: 'tacz:ammo', Count: 60, tag: {
                                AmmoId: "tacz:9x39"
                            }
                        },
                        {
                            Slot: 18, id: 'tacz:ammo', Count: 60, tag: {
                                AmmoId: "tacz:9x39"
                            }
                        },
                        {
                            Slot: 19, id: 'tacz:ammo', Count: 60, tag: {
                                AmmoId: "tacz:762x54"
                            }
                        },
                        {
                            Slot: 20, id: 'tacz:ammo', Count: 36, tag: {
                                AmmoId: "tacz:12g"
                            }
                        },
                        {
                            Slot: 21, id: 'tacz:ammo', Count: 36, tag: {
                                AmmoId: "tacz:12g"
                            }
                        },
                        {
                            Slot: 22, id: 'tacz:ammo', Count: 30, tag: {
                                AmmoId: "tacz:50bmg"
                            }
                        },
                        { Slot: 23, id: "pointblank:grenade40mm", Count: 12 },
                        { Slot: 24, id: "pointblank:javelin_rocket", Count: 3 },
                        {
                            Slot: 25, id: 'cooked_beef', Count: 32, tag: {
                                display: {
                                    Name: '["",{"text":"干粮","italic":false,"color":"yellow"}]',
                                    Lore: ['["",{"text":"最普遍的食物","italic":false,"color":"white"}]']
                                }
                            }
                        },
                        {
                            Slot: 26, id: 'create:sturdy_sheet',
                            Count: 6,
                            tag: {
                                BulletproofCount: 6,
                                display: {
                                    Name: '["",{"text":"防弹插板","italic":false,"color":"gray"}]',
                                    Lore: ['["",{"text":"插板护甲：6.0","italic":false,"color":"aqua"}]', '["",{"text":"插板上限为3个，使用时优先覆盖剩余护甲最低的插板。","italic":false,"color":"dark_aqua"}]']
                                }
                            }
                        }]
                    },
                    display: {
                        Name: '["",{"text":"补给箱 Red","italic":false,"color":"gold"}]',
                        Lore: ['["",{"text":"绍伊古，格拉西莫夫！","italic":false,"color":"white"}]']
                    }
                }
            }
        }
    },
    ATMissile: {
        index: "ATMissile",
        icon: 'pointblank:smaw',
        iconNbt: {
            display: {
                Name: '["",{"text":"反坦克导弹","italic":false,"color":"dark_purple"}]',
                Lore: ['["",{"text":"不能补充弹药，打完就没了","italic":false,"color":"gray"}]']
            },
        },
        location: {
            x: 5,
            y: 2
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                smaw: {
                    id: 'pointblank:smaw',
                    count: 1,
                    nbt: {
                    }
                },
                rockets: {
                    id: 'pointblank:smaw_rocket',
                    count: 5,
                    nbt: {
                    }
                },

            }
        }
    },
    B100: {
        index: "B100",
        icon: 'create:blaze_cake',
        iconNbt: {
            display: {
                Name: '["",{"text":"单兵云爆弹","italic":false,"color":"aqua"}]',
                Lore: ['["",{"text":"请确保自己能跑出爆炸范围","italic":false,"color":"gray"}]']
            },
        },
        location: {
            x: 6,
            y: 2
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "multiple",
                bomb: {
                    id: 'create:blaze_cake',
                    count: 1,
                    nbt: {
                        display: {
                            Name: '["",{"text":"单兵云爆弹","italic":false,"color":"aqua"}]',
                            Lore: ['["",{"text":"右键使用激活云爆弹，并开始","italic":false,"color":"gray"},{"text":"不可中断的10秒","italic":false,"color":"red"},{"text":"倒计时，倒计时结束时产生巨大爆炸。","italic":false,"color":"gray"}]', '["",{"text":"右键使用已激活的云爆弹以放下炸弹，右击放下的炸弹实体可以将其拾取，","italic":false,"color":"gray"},{"text":"击杀炸弹实体可以阻止爆炸。","italic":false,"color":"gold"}]']
                        }
                    }
                },
            }
        }
    },
    MGSentryRED: {
        index: "MGSentryRED",
        icon: 'minecraft:villager_spawn_egg',
        iconNbt: {
            display: {
                Name: '[{"text":"哨戒机枪 Red","italic":false,"color":"red"}]',
                Lore: ['[{"text":"放置一个向50格内敌方单位攻击的村民，具有50点血量，可以占点。","italic":false,"color":"dark_green"},{"text":"","italic":false,"color":"dark_purple"}]', '[{"text":"超级哈基民来向玩家复仇了","italic":false,"color":"dark_red"}]']
            }
        },
        location: {
            x: 3,
            y: 1
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "single",
                id: 'minecraft:villager_spawn_egg',
                count: 1,
                nbt: {
                    EntityTag: {
                        id: "villager",
                        CustomName: '[{"text":"哨戒机枪","color":"red"}]',
                        CustomNameVisible: true,
                        Health: 50,
                        //Tags: ["archer"],
                        Silent: true,
                        Team: "EA",
                        ArmorItems: [{}, {}, {}, { id: 'red_banner', Count: 1 }],
                        ArmorDropChances: [0, 0, 0, 0],
                        Attributes: [
                            { Name: "generic.max_health", Base: 50 },
                            { Name: "generic.armor", Base: 20 },
                            { Name: "generic.knockback_resistance", Base: 1 },
                            { Name: "generic.movement_speed", Base: -1 }
                        ]
                    },
                    display: {
                        Name: '[{"text":"哨戒机枪 Red","italic":false,"color":"red"}]',
                        Lore: ['[{"text":"放置一个向50格内敌方单位攻击的村民，具有50点血量，可以占点。","italic":false,"color":"dark_green"},{"text":"","italic":false,"color":"dark_purple"}]', '[{"text":"超级哈基民来向玩家复仇了","italic":false,"color":"dark_red"}]']
                    }
                }
            }
        }
    },
    /*  GatSentryRED: {
        index: "GatSentryRED",
        icon: 'minecraft:villager_spawn_egg',
        iconNbt: {
            display: {
                Name: '[{"text":"哨戒加特林 Red","italic":false,"color":"red"}]',
                Lore: ['[{"text":"放置一个向50格内敌方单位攻击的村民，具有50点血量，可以占点。","italic":false,"color":"dark_green"},{"text":"","italic":false,"color":"dark_purple"}]', '[{"text":"超级哈基民来向玩家复仇了","italic":false,"color":"dark_red"}]']
            }
        },
        location: {
            x: 3,
            y: 2
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "single",
                id: 'minecraft:villager_spawn_egg',
                count: 1,
                nbt: {
                    EntityTag: {
                        id: "villager",
                        CustomName: '[{"text":"哨戒加特林","color":"red"}]',
                        CustomNameVisible: true,
                        Health: 50,
                        //Tags: ["archer"],
                        Silent: true,
                        Team: "EA",
                        ArmorItems: [{}, {}, {}, { id: 'red_banner', Count: 1 }],
                        ArmorDropChances: [0, 0, 0, 0],
                        Attributes: [
                            { Name: "generic.max_health", Base: 50 },
                            { Name: "generic.armor", Base: 20 },
                            { Name: "generic.knockback_resistance", Base: 1 },
                            { Name: "generic.movement_speed", Base: -1 }
                        ]
                    },
                    display: {
                        Name: '[{"text":"哨戒加特林 Red","italic":false,"color":"red"}]',
                        Lore: ['[{"text":"放置一个向50格内敌方单位攻击的村民，具有50点血量，可以占点。","italic":false,"color":"dark_green"},{"text":"","italic":false,"color":"dark_purple"}]', '[{"text":"超级哈基民来向玩家复仇了","italic":false,"color":"dark_red"}]']
                    }
                }
            }
        }
    }, */
    ACSentryRED: {
        index: "ACSentryRED",
        icon: 'minecraft:villager_spawn_egg',
        iconNbt: {
            display: {
                Name: '[{"text":"哨戒机炮 Red","italic":false,"color":"red"}]',
                Lore: ['[{"text":"放置一个向50格内敌方单位攻击的村民，具有50点血量，可以占点。","italic":false,"color":"dark_green"},{"text":"","italic":false,"color":"dark_purple"}]', '[{"text":"超级哈基民来向玩家复仇了","italic":false,"color":"dark_red"}]']
            }
        },
        location: {
            x: 3,
            y: 2
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "single",
                id: 'minecraft:villager_spawn_egg',
                count: 1,
                nbt: {
                    EntityTag: {
                        id: "villager",
                        CustomName: '[{"text":"哨戒机炮","color":"red"}]',
                        CustomNameVisible: true,
                        Health: 50,
                        //Tags: ["archer"],
                        Silent: true,
                        Team: "EA",
                        ArmorItems: [{}, {}, {}, { id: 'red_banner', Count: 1 }],
                        ArmorDropChances: [0, 0, 0, 0],
                        Attributes: [
                            { Name: "generic.max_health", Base: 50 },
                            { Name: "generic.armor", Base: 20 },
                            { Name: "generic.knockback_resistance", Base: 1 },
                            { Name: "generic.movement_speed", Base: -1 }
                        ]
                    },
                    display: {
                        Name: '[{"text":"哨戒机炮 Red","italic":false,"color":"red"}]',
                        Lore: ['[{"text":"放置一个向50格内敌方单位攻击的村民，具有50点血量，可以占点。","italic":false,"color":"dark_green"},{"text":"","italic":false,"color":"dark_purple"}]', '[{"text":"超级哈基民来向玩家复仇了","italic":false,"color":"dark_red"}]']
                    }
                }
            }
        }
    },
    /*MortarSentryRED: {
        index: "MortarSentryRED",
        icon: 'minecraft:villager_spawn_egg',
        iconNbt: {
            display: {
                Name: '[{"text":"哨戒迫击炮 Red","italic":false,"color":"red"}]',
                Lore: ['[{"text":"放置一个向50格内敌方单位攻击的村民，具有50点血量，可以占点。","italic":false,"color":"dark_green"},{"text":"","italic":false,"color":"dark_purple"}]', '[{"text":"超级哈基民来向玩家复仇了","italic":false,"color":"dark_red"}]']
            }
        },
        location: {
            x: 3,
            y: 4
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "single",
                id: 'minecraft:villager_spawn_egg',
                count: 1,
                nbt: {
                    EntityTag: {
                        id: "villager",
                        CustomName: '[{"text":"哨戒迫击炮","color":"red"}]',
                        CustomNameVisible: true,
                        Health: 50,
                        //Tags: ["archer"],
                        Silent: true,
                        Team: "EA",
                        ArmorItems: [{}, {}, {}, { id: 'red_banner', Count: 1 }],
                        ArmorDropChances: [0, 0, 0, 0],
                        Attributes: [
                            { Name: "generic.max_health", Base: 50 },
                            { Name: "generic.armor", Base: 20 },
                            { Name: "generic.knockback_resistance", Base: 1 },
                            { Name: "generic.movement_speed", Base: -1 }
                        ]
                    },
                    display: {
                        Name: '[{"text":"哨戒迫击炮 Red","italic":false,"color":"red"}]',
                        Lore: ['[{"text":"放置一个向50格内敌方单位攻击的村民，具有50点血量，可以占点。","italic":false,"color":"dark_green"},{"text":"","italic":false,"color":"dark_purple"}]', '[{"text":"超级哈基民来向玩家复仇了","italic":false,"color":"dark_red"}]']
                    }
                }
            }
        }
    },
    RocketSentryRED: {
        index: "RocketSentryRED",
        icon: 'minecraft:villager_spawn_egg',
        iconNbt: {
            display: {
                Name: '[{"text":"哨戒火箭炮 Red","italic":false,"color":"red"}]',
                Lore: ['[{"text":"放置一个向50格内敌方单位攻击的村民，具有50点血量，可以占点。","italic":false,"color":"dark_green"},{"text":"","italic":false,"color":"dark_purple"}]', '[{"text":"超级哈基民来向玩家复仇了","italic":false,"color":"dark_red"}]']
            }
        },
        location: {
            x: 4,
            y: 4
        },
        leftClickAction: {
            type: "simpleSelect",
            items: {
                type: "single",
                id: 'minecraft:villager_spawn_egg',
                count: 1,
                nbt: {
                    EntityTag: {
                        id: "villager",
                        CustomName: '[{"text":"哨戒火箭炮","color":"red"}]',
                        CustomNameVisible: true,
                        Health: 50,
                        //Tags: ["archer"],
                        Silent: true,
                        Team: "EA",
                        ArmorItems: [{}, {}, {}, { id: 'red_banner', Count: 1 }],
                        ArmorDropChances: [0, 0, 0, 0],
                        Attributes: [
                            { Name: "generic.max_health", Base: 50 },
                            { Name: "generic.armor", Base: 20 },
                            { Name: "generic.knockback_resistance", Base: 1 },
                            { Name: "generic.movement_speed", Base: -1 }
                        ]
                    },
                    display: {
                        Name: '[{"text":"哨戒火箭炮 Red","italic":false,"color":"red"}]',
                        Lore: ['[{"text":"放置一个向50格内敌方单位攻击的村民，具有50点血量，可以占点。","italic":false,"color":"dark_green"},{"text":"","italic":false,"color":"dark_purple"}]', '[{"text":"超级哈基民来向玩家复仇了","italic":false,"color":"dark_red"}]']
                    }
                }
            }
        }
    }, */
}
